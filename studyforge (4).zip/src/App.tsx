//created by Abhijit samal
import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';

import { Shell } from '@/components/layout/Shell';
import { Dashboard } from '@/pages/Dashboard';
import { Onboarding } from '@/pages/Onboarding';
import { Notes } from '@/pages/Notes';
import { Tasks } from '@/pages/Tasks';
import { FocusRoom } from '@/pages/FocusRoom';
import { Workspace } from '@/pages/Workspace';
import { Settings } from '@/pages/Settings';
import { Library } from '@/pages/Library';
import { Subjects } from '@/pages/Subjects';
import { Calendar } from '@/pages/Calendar';
import { Flashcards } from '@/pages/Flashcards';
import { SimulationLab } from '@/pages/SimulationLab';
import { ThreeDLab } from '@/pages/ThreeDLab';

import { MyLearning } from '@/pages/MyLearning';
import { Curriculum } from '@/pages/Curriculum';
import { StudySessions } from '@/pages/StudySessions';
import { Revision } from '@/pages/Revision';
import { Quizzes } from '@/pages/Quizzes';
import { Analytics } from '@/pages/Analytics';
import { KnowledgeMap } from '@/pages/KnowledgeMap';
import { Tools } from '@/pages/Tools';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { ToastAndConfirm } from '@/components/ToastAndConfirm';

export default function App() {
  const profiles = useLiveQuery(() => db.profile.toArray());
  const profile = profiles?.[0];
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Non-fatal logging for background promise errors (prevents crashing React tree with [object Object])
    const handleRejection = (event: PromiseRejectionEvent) => {
      console.warn('Background promise rejection handled:', event.reason);
    };

    window.addEventListener('unhandledrejection', handleRejection);
    return () => {
      window.removeEventListener('unhandledrejection', handleRejection);
    };
  }, []);

  useEffect(() => {
    if (profiles !== undefined) {
      setLoading(false);
      
      // Apply theme
      const root = window.document.documentElement;
      root.classList.remove('dark', 'theme-paper', 'theme-forgedark', 'theme-midnight', 'theme-arctic');
      
      if (profile?.theme) {
        const theme = profile.theme.toLowerCase().replace(' ', '');
        if (theme === 'forgedark' || theme === 'midnight') {
          root.classList.add('dark');
        }
        root.classList.add(`theme-${theme}`);
      }
    }
  }, [profiles, profile]);

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-stone-50 dark:bg-zinc-950">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-lg bg-indigo-200 dark:bg-indigo-900/50"></div>
          <div className="h-4 w-32 bg-stone-200 dark:bg-zinc-800 rounded"></div>
        </div>
      </div>
    );
  }

  // Very simple initialization logic:
  // If no profile or not onboarded, show onboarding.
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          {!profile?.onboarded ? (
            <Route path="*" element={<Onboarding />} />
          ) : (
            <Route path="/" element={<Shell />}>
              <Route index element={<Dashboard />} />
              <Route path="learning" element={<MyLearning />} />
              <Route path="curriculum" element={<Curriculum />} />
              <Route path="library" element={<Library />} />
              
              <Route path="workspace" element={<Workspace />} />
              <Route path="sessions" element={<StudySessions />} />
              <Route path="tasks" element={<Tasks />} />
              <Route path="calendar" element={<Calendar />} />
              <Route path="revision" element={<Revision />} />
              
              <Route path="quizzes" element={<Quizzes />} />
              <Route path="flashcards" element={<Flashcards />} />
              <Route path="simulations" element={<SimulationLab />} />
              <Route path="3d-lab" element={<ThreeDLab />} />
              
              <Route path="analytics" element={<Analytics />} />
              <Route path="knowledge-map" element={<KnowledgeMap />} />
              
              <Route path="tools" element={<Tools />} />
              <Route path="settings" element={<Settings />} />
              
              {/* Kept notes and focus room just in case, though they might be migrated */}
              <Route path="notes" element={<Notes />} />
              <Route path="focus" element={<FocusRoom />} />
              <Route path="subjects" element={<Subjects />} />
              
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          )}
        </Routes>
      </BrowserRouter>
      <ToastAndConfirm />
    </ErrorBoundary>
  );
}


import Dexie, { type EntityTable } from 'dexie';

export interface Profile {
  id: number;
  name: string;
  nickname: string;
  avatar?: string;
  theme: string;
  performanceMode: boolean;
  reduceMotion?: boolean;
  highContrast?: boolean;
  onboarded: boolean;
  accentColor: string;
  curriculum?: string;
  examDate?: string;
  examName?: string;
  targetDailyMinutes?: number;
  autoSave?: boolean;
}

export interface Subject {
  id?: number;
  name: string;
  code?: string;
  color: string;
  icon: string;
  description?: string;
  createdAt: number;
}

export interface Chapter {
  id?: number;
  subjectId: number;
  name: string;
  chapterNumber?: number;
  description?: string;
  estimatedHours?: number;
  completed?: boolean;
  confidenceLevel?: number; // 1 to 5
  createdAt: number;
}

export interface Goal {
  id?: number;
  subjectId: number;
  chapterId?: number;
  title: string;
  deadline?: number;
  completed: boolean;
  createdAt: number;
}

export interface StudySession {
  id?: number;
  subjectId: number;
  chapterId?: number;
  goalId?: number;
  startTime: number;
  endTime: number;
  durationMinutes: number;
  completed: boolean;
  resourceUsed?: string;
  pdfReadingTime?: number;
  videoWatchingTime?: number;
  topic?: string;
  notes?: string;
}

export interface Note {
  id?: number;
  subjectId?: number;
  chapterId?: number;
  title: string;
  content: string;
  tags: string[];
  isPinned: boolean;
  templateType?: 'blank' | 'cornell' | 'feynman' | 'active_recall';
  createdAt: number;
  updatedAt: number;
}

export interface Task {
  id?: number;
  subjectId?: number;
  title: string;
  completed: boolean;
  dueDate?: number;
  priority: 'low' | 'medium' | 'high';
  createdAt: number;
}

export interface Deck {
  id?: number;
  subjectId?: number;
  name: string;
  color?: string;
  createdAt: number;
}

export interface Flashcard {
  id?: number;
  deckId: number;
  front: string;
  back: string;
  nextReview: number;
  easeFactor: number;
  interval: number;
  repetitions: number;
  createdAt: number;
}

export interface DocumentBookmark {
  id: string;
  page: number;
  title: string;
  note?: string;
  createdAt: number;
}

export interface LibraryFile {
  id?: number;
  subjectId?: number;
  title: string;
  type: 'pdf' | 'video' | 'image' | '3d' | 'other';
  fileData?: Blob;
  size: number;
  createdAt: number;
  lastAccessedAt?: number;
  pageCount?: number;
  lastReadPage?: number;
  readingTimeMinutes?: number;
  bookmarks?: DocumentBookmark[];
  keywords?: string[];
  outline?: Array<{ title: string; page: number }>;
  author?: string;
}

export interface FocusSession {
  id?: number;
  durationMinutes: number;
  subjectId?: number;
  completedAt: number;
  mode?: 'pomodoro' | 'deep_work' | 'quick_review';
}

export interface QuizAttempt {
  id?: number;
  subjectId?: number;
  quizTitle: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  completedAt: number;
  timeSpentSeconds: number;
  topic?: string;
}

export interface WeakTopic {
  id?: number;
  subjectId: number;
  chapterName: string;
  topicName: string;
  notes?: string;
  severity: 'low' | 'medium' | 'high';
  resolved: boolean;
  createdAt: number;
}

export interface User3DModel {
  id?: number;
  name: string;
  fileName: string;
  fileType: 'obj' | 'stl' | 'glb' | 'gltf';
  fileSize: number;
  fileData?: Blob;
  importedAt: number;
  lastOpenedAt?: number;
  favorite?: boolean;
  tags?: string[];
  meshCount?: number;
  vertexCount?: number;
  triangleCount?: number;
  dimensions?: { x: number; y: number; z: number };
}

class StudyForgeDatabase extends Dexie {
  profile!: EntityTable<Profile, 'id'>;
  subjects!: EntityTable<Subject, 'id'>;
  chapters!: EntityTable<Chapter, 'id'>;
  goals!: EntityTable<Goal, 'id'>;
  studySessions!: EntityTable<StudySession, 'id'>;
  notes!: EntityTable<Note, 'id'>;
  tasks!: EntityTable<Task, 'id'>;
  decks!: EntityTable<Deck, 'id'>;
  flashcards!: EntityTable<Flashcard, 'id'>;
  library!: EntityTable<LibraryFile, 'id'>;
  focusSessions!: EntityTable<FocusSession, 'id'>;
  quizAttempts!: EntityTable<QuizAttempt, 'id'>;
  weakTopics!: EntityTable<WeakTopic, 'id'>;
  user3DModels!: EntityTable<User3DModel, 'id'>;

  constructor() {
    super('StudyForgeDB');
    
    this.version(1).stores({
      profile: 'id',
      subjects: '++id, name',
      notes: '++id, subjectId, title, isPinned, updatedAt',
      tasks: '++id, subjectId, completed, dueDate, priority',
      decks: '++id, subjectId, name',
      flashcards: '++id, deckId, nextReview',
      library: '++id, subjectId, type, title',
      focusSessions: '++id, subjectId, completedAt'
    });

    this.version(2).stores({
      profile: 'id',
      subjects: '++id, name',
      chapters: '++id, subjectId, name',
      goals: '++id, subjectId, chapterId, completed',
      studySessions: '++id, subjectId, chapterId, startTime',
      notes: '++id, subjectId, title, isPinned, updatedAt',
      tasks: '++id, subjectId, completed, dueDate, priority',
      decks: '++id, subjectId, name',
      flashcards: '++id, deckId, nextReview',
      library: '++id, subjectId, type, title',
      focusSessions: '++id, subjectId, completedAt'
    });

    this.version(3).stores({
      profile: 'id',
      subjects: '++id, name',
      chapters: '++id, subjectId, name',
      goals: '++id, subjectId, chapterId, completed',
      studySessions: '++id, subjectId, chapterId, startTime',
      notes: '++id, subjectId, title, isPinned, updatedAt',
      tasks: '++id, subjectId, completed, dueDate, priority',
      decks: '++id, subjectId, name',
      flashcards: '++id, deckId, nextReview',
      library: '++id, subjectId, type, title',
      focusSessions: '++id, subjectId, completedAt'
    });

    this.version(4).stores({
      profile: 'id',
      subjects: '++id, name',
      chapters: '++id, subjectId, name',
      goals: '++id, subjectId, chapterId, completed',
      studySessions: '++id, subjectId, chapterId, startTime',
      notes: '++id, subjectId, title, isPinned, updatedAt',
      tasks: '++id, subjectId, completed, dueDate, priority',
      decks: '++id, subjectId, name',
      flashcards: '++id, deckId, nextReview',
      library: '++id, subjectId, type, title',
      focusSessions: '++id, subjectId, completedAt'
    });

    // Version 5: Added quizAttempts, weakTopics, and expanded chapter indexes
    this.version(5).stores({
      profile: 'id',
      subjects: '++id, name',
      chapters: '++id, subjectId, name, completed',
      goals: '++id, subjectId, chapterId, completed',
      studySessions: '++id, subjectId, chapterId, startTime',
      notes: '++id, subjectId, title, isPinned, updatedAt',
      tasks: '++id, subjectId, completed, dueDate, priority',
      decks: '++id, subjectId, name',
      flashcards: '++id, deckId, nextReview',
      library: '++id, subjectId, type, title',
      focusSessions: '++id, subjectId, completedAt',
      quizAttempts: '++id, subjectId, completedAt',
      weakTopics: '++id, subjectId, severity, resolved'
    });

    // Version 6: Added user3DModels table for local offline 3D model import
    this.version(6).stores({
      profile: 'id',
      subjects: '++id, name',
      chapters: '++id, subjectId, name, completed',
      goals: '++id, subjectId, chapterId, completed',
      studySessions: '++id, subjectId, chapterId, startTime',
      notes: '++id, subjectId, title, isPinned, updatedAt',
      tasks: '++id, subjectId, completed, dueDate, priority',
      decks: '++id, subjectId, name',
      flashcards: '++id, deckId, nextReview',
      library: '++id, subjectId, type, title',
      focusSessions: '++id, subjectId, completedAt',
      quizAttempts: '++id, subjectId, completedAt',
      weakTopics: '++id, subjectId, severity, resolved',
      user3DModels: '++id, name, fileType, importedAt, favorite'
    });
  }
}

export const db = new StudyForgeDatabase();

db.open().catch(err => {
  console.error('Dexie open error:', err);
  if (err.name === 'UpgradeError' || err.name === 'VersionError' || err.name === 'OpenFailedError') {
    db.delete().then(() => {
      console.log('Database deleted due to upgrade error. Reloading...');
      window.location.reload();
    });
  }
});

// Standard CBSE Class 10 NCERT Curriculum Seeder
export async function seedClass10Curriculum(force = false) {
  const existingCount = await db.subjects.count();
  if (existingCount > 0 && !force) return;

  if (force) {
    await db.chapters.clear();
    await db.subjects.clear();
    await db.decks.clear();
    await db.flashcards.clear();
  }

  // 1. Science - Physics
  const physId = await db.subjects.add({
    name: 'Physics (Class 10)',
    code: 'SCI-PHY',
    color: '#0284c7', // cerulean
    icon: 'Atom',
    description: 'Light Reflection & Refraction, Human Eye, Electricity, and Magnetic Effects of Electric Current.',
    createdAt: Date.now()
  });

  await db.chapters.bulkAdd([
    { subjectId: Number(physId), chapterNumber: 9, name: 'Light – Reflection and Refraction', description: 'Spherical mirrors, mirror formula, refraction through glass slab, lens formula, power of lens.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(physId), chapterNumber: 10, name: 'The Human Eye and Colourful World', description: 'Structure of human eye, defects of vision, atmospheric refraction, dispersion through prism, scattering.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(physId), chapterNumber: 11, name: 'Electricity', description: 'Electric current and potential difference, Ohm\'s law, resistance, series and parallel circuits, Joule\'s law of heating.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(physId), chapterNumber: 12, name: 'Magnetic Effects of Electric Current', description: 'Magnetic field lines, right-hand thumb rule, solenoid, Fleming\'s left-hand rule, domestic electric circuits.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
  ]);

  // 2. Science - Chemistry
  const chemId = await db.subjects.add({
    name: 'Chemistry (Class 10)',
    code: 'SCI-CHE',
    color: '#059669', // emerald
    icon: 'FlaskConical',
    description: 'Chemical Reactions, Acids, Bases, Salts, Metals and Non-Metals, Carbon Compounds.',
    createdAt: Date.now()
  });

  await db.chapters.bulkAdd([
    { subjectId: Number(chemId), chapterNumber: 1, name: 'Chemical Reactions and Equations', description: 'Balancing chemical equations, combination, decomposition, displacement, double displacement, redox, rancidity.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(chemId), chapterNumber: 2, name: 'Acids, Bases and Salts', description: 'pH scale, indicator testing, neutralization, preparation of sodium hydroxide, bleaching powder, baking soda, plaster of Paris.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(chemId), chapterNumber: 3, name: 'Metals and Non-metals', description: 'Physical and chemical properties, reactivity series, ionic bonding, metallurgy and extraction, corrosion prevention.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(chemId), chapterNumber: 4, name: 'Carbon and its Compounds', description: 'Covalent bonding, homologous series, functional groups, combustion, oxidation, addition reactions, soaps and detergents.', confidenceLevel: 2, completed: false, createdAt: Date.now() },
  ]);

  // 3. Science - Biology
  const bioId = await db.subjects.add({
    name: 'Biology (Class 10)',
    code: 'SCI-BIO',
    color: '#d97706', // amber
    icon: 'Leaf',
    description: 'Life Processes, Control & Coordination, Reproduction, Heredity and Evolution.',
    createdAt: Date.now()
  });

  await db.chapters.bulkAdd([
    { subjectId: Number(bioId), chapterNumber: 5, name: 'Life Processes', description: 'Nutrition (autotrophic & heterotrophic), respiration, circulation in humans (double circulation), excretion and nephron structure.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(bioId), chapterNumber: 6, name: 'Control and Coordination', description: 'Nervous system, reflex arc, human brain structure, plant hormones (auxins, gibberellins), endocrine glands and hormones.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(bioId), chapterNumber: 7, name: 'How do Organisms Reproduce?', description: 'Asexual reproduction modes, sexual reproduction in flowering plants, human male and female reproductive systems.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(bioId), chapterNumber: 8, name: 'Heredity and Evolution', description: 'Mendelian genetics, monohybrid and dihybrid cross, sex determination in humans.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
  ]);

  // 4. Mathematics
  const mathId = await db.subjects.add({
    name: 'Mathematics (Class 10)',
    code: 'MATH-10',
    color: '#7c3aed', // violet
    icon: 'Calculator',
    description: 'Algebra, Coordinate Geometry, Trigonometry, Circles, Statistics and Probability.',
    createdAt: Date.now()
  });

  await db.chapters.bulkAdd([
    { subjectId: Number(mathId), chapterNumber: 1, name: 'Real Numbers', description: 'Fundamental theorem of arithmetic, proofs of irrationality of √2, √3, √5.', confidenceLevel: 5, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 2, name: 'Polynomials', description: 'Zeros of polynomial, relationship between zeros and coefficients of quadratic polynomials.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 3, name: 'Pair of Linear Equations in Two Variables', description: 'Graphical method, substitution method, elimination method, conditions for consistency.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 4, name: 'Quadratic Equations', description: 'Standard form, factorization, quadratic formula, nature of roots (discriminant).', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 5, name: 'Arithmetic Progressions', description: 'nth term formula an = a + (n-1)d, sum of first n terms Sn = n/2[2a + (n-1)d].', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 6, name: 'Triangles', description: 'Basic proportionality theorem (Thales theorem), criteria for similarity of triangles (AAA, SSS, SAS).', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 7, name: 'Coordinate Geometry', description: 'Distance formula, section formula (internal division).', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 8, name: 'Introduction to Trigonometry', description: 'Trigonometric ratios of acute angles, values at 0°, 30°, 45°, 60°, 90°, trigonometric identities (sin²θ + cos²θ = 1).', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 9, name: 'Some Applications of Trigonometry', description: 'Heights and distances, angle of elevation, angle of depression problems.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 10, name: 'Circles', description: 'Tangent to a circle at point of contact, tangents drawn from an external point are equal.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 12, name: 'Surface Areas and Volumes', description: 'Surface areas and volumes of combinations of cubes, cuboids, spheres, hemispheres, cylinders, cones.', confidenceLevel: 3, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 13, name: 'Statistics', description: 'Mean of grouped data (direct & assumed mean), mode of grouped data, median of grouped data.', confidenceLevel: 4, completed: false, createdAt: Date.now() },
    { subjectId: Number(mathId), chapterNumber: 14, name: 'Probability', description: 'Classical definition of probability, simple problems on single events.', confidenceLevel: 5, completed: false, createdAt: Date.now() }
  ]);

  // Seed initial revision flashcard decks
  const physDeck = await db.decks.add({ subjectId: Number(physId), name: 'Physics - Core Formulas & Laws', color: '#0284c7', createdAt: Date.now() });
  await db.flashcards.bulkAdd([
    { deckId: Number(physDeck), front: 'Mirror Formula (relationship between u, v, f)', back: '1/f = 1/v + 1/u\n\n(Sign convention: focal length of concave mirror is negative; convex mirror is positive)', easeFactor: 2.5, interval: 1, repetitions: 0, nextReview: Date.now(), createdAt: Date.now() },
    { deckId: Number(physDeck), front: 'Ohm\'s Law Formula and Statement', back: 'V = I × R\n\nPotential difference across a conductor is directly proportional to the current flowing through it, provided temperature remains constant.', easeFactor: 2.5, interval: 1, repetitions: 0, nextReview: Date.now(), createdAt: Date.now() },
    { deckId: Number(physDeck), front: 'Joule\'s Law of Heating', back: 'H = I²Rt\n\nHeat produced is proportional to square of current, resistance, and time of flow.', easeFactor: 2.5, interval: 1, repetitions: 0, nextReview: Date.now(), createdAt: Date.now() },
    { deckId: Number(physDeck), front: 'Power of a Lens formula and unit', back: 'P = 1 / f (where f is in metres)\nUnit: Dioptre (D). Convex lens has positive power, concave lens has negative power.', easeFactor: 2.5, interval: 1, repetitions: 0, nextReview: Date.now(), createdAt: Date.now() }
  ]);

  const chemDeck = await db.decks.add({ subjectId: Number(chemId), name: 'Chemistry - Reactions & Equations', color: '#059669', createdAt: Date.now() });
  await db.flashcards.bulkAdd([
    { deckId: Number(chemDeck), front: 'Chemical formula of Plaster of Paris and reaction to form Gypsum', back: 'CaSO4 · ½H2O (Calcium sulphate hemihydrate)\n\nCaSO4 · ½H2O + 1½H2O → CaSO4 · 2H2O (Gypsum)', easeFactor: 2.5, interval: 1, repetitions: 0, nextReview: Date.now(), createdAt: Date.now() },
    { deckId: Number(chemDeck), front: 'Reactivity Series of Metals (Top to Bottom)', back: 'K > Na > Ca > Mg > Al > Zn > Fe > Pb > [H] > Cu > Hg > Ag > Au\n\n(Mnemonic: Please Stop Calling Me A Zebra In Class - He Can’t Manage Silver Gold)', easeFactor: 2.5, interval: 1, repetitions: 0, nextReview: Date.now(), createdAt: Date.now() }
  ]);
}

import React, { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import * as THREE from 'three';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { 
  Box, Eye, Layers, RotateCcw, Upload, 
  Sparkles, Maximize2, Minimize2, Cpu, Search, 
  Filter, Star, Clock, Trash2, Edit2, Check,
  Atom, ShieldCheck, Compass, Grid, AlertTriangle,
  FolderOpen, Info, ChevronRight, RefreshCw, X, FileX
} from 'lucide-react';
import { useUIStore } from '@/store/uiStore';
import { db, User3DModel } from '@/db/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { FIRST_30_ELEMENTS, ElementData } from '@/lib/elementData';
import { cn } from '@/lib/utils';

type ViewMode = 'atom3d' | 'config' | 'info';
type BackgroundTheme = 'dark' | 'black' | 'gray' | 'light';

export function ThreeDLab() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { performanceMode, showToast, askConfirmation } = useUIStore();

  // Active Selection State
  const [selectedType, setSelectedType] = useState<'element' | 'userModel' | 'preset'>('element');
  const [selectedElementNumber, setSelectedElementNumber] = useState<number>(26); // Default: Iron (Fe-26)
  const [selectedUserModelId, setSelectedUserModelId] = useState<number | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<'dna' | 'solenoid'>('dna');
  
  // Element Detail View Sub-Mode
  const [elementViewMode, setElementViewMode] = useState<ViewMode>('atom3d');

  // Library / Navigation State
  const [libraryTab, setLibraryTab] = useState<'elements' | 'userModels' | 'recent' | 'favorites'>('elements');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'number' | 'name'>('number');

  // Viewer Display Controls
  const [wireframe, setWireframe] = useState<boolean>(false);
  const [autoRotate, setAutoRotate] = useState<boolean>(true);
  const [rotationSpeed, setRotationSpeed] = useState<number>(0.8);
  const [showGrid, setShowGrid] = useState<boolean>(true);
  const [showAxes, setShowAxes] = useState<boolean>(false);
  const [bgTheme, setBgTheme] = useState<BackgroundTheme>('dark');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // User Model Stats
  const [modelStats, setModelStats] = useState<{
    meshCount: number;
    vertexCount: number;
    triangleCount: number;
    dimensions: { x: number; y: number; z: number };
  } | null>(null);

  // Model Error State
  const [loadError, setLoadError] = useState<{
    message: string;
    causes: string[];
    technical?: string;
  } | null>(null);

  // User 3D Models from Dexie
  const userModels = useLiveQuery(() => db.user3DModels.toArray()) || [];

  // Favorites & Recents in local state
  const [recentElementNumbers, setRecentElementNumbers] = useState<number[]>([26, 6, 8, 1, 29]);
  const [favoriteElementNumbers, setFavoriteElementNumbers] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('studyforge_3d_favs');
      return saved ? JSON.parse(saved) : [26, 6, 1];
    } catch {
      return [26, 6, 1];
    }
  });

  // Three.js Runtime References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const modelGroupRef = useRef<THREE.Group | null>(null);
  const gridHelperRef = useRef<THREE.GridHelper | null>(null);
  const axesHelperRef = useRef<THREE.AxesHelper | null>(null);
  const reqAnimRef = useRef<number | null>(null);
  const currentObjectUrlRef = useRef<string | null>(null);

  // Electron shell rotation angles
  const shellAnglesRef = useRef<number[]>([0, 0, 0, 0]);

  // Selected element data
  const currentElement = useMemo(() => {
    return FIRST_30_ELEMENTS.find(e => e.number === selectedElementNumber) || FIRST_30_ELEMENTS[25]; // Fe default
  }, [selectedElementNumber]);

  // Save favorites to localStorage
  const toggleFavorite = (num: number) => {
    let updated: number[];
    if (favoriteElementNumbers.includes(num)) {
      updated = favoriteElementNumbers.filter(n => n !== num);
      showToast(`Removed ${FIRST_30_ELEMENTS.find(e => e.number === num)?.name} from favorites`, 'info');
    } else {
      updated = [...favoriteElementNumbers, num];
      showToast(`Added ${FIRST_30_ELEMENTS.find(e => e.number === num)?.name} to favorites`, 'success');
    }
    setFavoriteElementNumbers(updated);
    localStorage.setItem('studyforge_3d_favs', JSON.stringify(updated));
  };

  // Add to recents
  const markRecent = useCallback((num: number) => {
    setRecentElementNumbers(prev => {
      const filtered = prev.filter(n => n !== num);
      return [num, ...filtered].slice(0, 10);
    });
  }, []);

  // Set Background Color
  useEffect(() => {
    if (!sceneRef.current) return;
    const bgColors = {
      dark: 0x0f172a,   // Slate 900
      black: 0x050505,  // Pure black
      gray: 0x1e293b,   // Slate 800 studio
      light: 0xf1f5f9   // Slate 100
    };
    sceneRef.current.background = new THREE.Color(bgColors[bgTheme]);
  }, [bgTheme]);

  // Toggle Grid and Axes Helpers
  useEffect(() => {
    if (gridHelperRef.current) gridHelperRef.current.visible = showGrid;
    if (axesHelperRef.current) axesHelperRef.current.visible = showAxes;
  }, [showGrid, showAxes]);

  // Helper to dispose all meshes inside a group to prevent memory leaks on low-end hardware
  const disposeGroup = (group: THREE.Group) => {
    while (group.children.length > 0) {
      const obj: any = group.children[0];
      group.remove(obj);
      if (obj.geometry) obj.geometry.dispose();
      if (obj.material) {
        if (Array.isArray(obj.material)) {
          obj.material.forEach((m: any) => m.dispose());
        } else {
          obj.material.dispose();
        }
      }
    }
  };

  // 1. BUILD BOHR ATOM 3D MODEL FOR ANY OF THE 30 ELEMENTS
  const buildAtomModel = useCallback((elem: ElementData, group: THREE.Group, isWire: boolean) => {
    disposeGroup(group);
    setLoadError(null);
    setModelStats(null);

    const sphereDetail = performanceMode ? 10 : 16;

    // A. Nucleus Cluster (Protons & Neutrons)
    const nucleusGroup = new THREE.Group();
    const protonMat = new THREE.MeshStandardMaterial({ 
      color: 0xef4444, // Red for protons
      roughness: 0.35, 
      metalness: 0.2,
      wireframe: isWire 
    });
    const neutronMat = new THREE.MeshStandardMaterial({ 
      color: 0x3b82f6, // Blue for neutrons
      roughness: 0.35, 
      metalness: 0.2,
      wireframe: isWire 
    });

    const protonCount = elem.protons;
    const neutronCount = elem.neutrons;
    const totalNucleons = Math.min(protonCount + neutronCount, performanceMode ? 28 : 45);
    const nucleusRadius = 0.5 + Math.cbrt(elem.number) * 0.35;

    for (let i = 0; i < totalNucleons; i++) {
      const isProton = i % 2 === 0 && i / 2 < protonCount;
      const sphereGeom = new THREE.SphereGeometry(0.38, sphereDetail, sphereDetail);
      const mesh = new THREE.Mesh(sphereGeom, isProton ? protonMat : neutronMat);

      // Fibonacci sphere distribution for uniform spherical clustering
      const phi = Math.acos(-1 + (2 * i) / totalNucleons);
      const theta = Math.sqrt(totalNucleons * Math.PI) * phi;
      const dist = (Math.random() * 0.4 + 0.6) * nucleusRadius;

      mesh.position.set(
        dist * Math.cos(theta) * Math.sin(phi),
        dist * Math.sin(theta) * Math.sin(phi),
        dist * Math.cos(phi)
      );
      nucleusGroup.add(mesh);
    }
    group.add(nucleusGroup);

    // B. Electron Shells and Orbiting Electrons
    // Shell Radii: K=3.6, L=5.8, M=8.2, N=10.6
    const baseRadii = [3.6, 5.8, 8.2, 10.6];
    const ringMat = new THREE.MeshBasicMaterial({ 
      color: 0x64748b, 
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45 
    });

    const electronMat = new THREE.MeshStandardMaterial({ 
      color: 0xfacc15, // Golden Amber
      emissive: 0xf59e0b, 
      emissiveIntensity: 0.6,
      roughness: 0.2,
      wireframe: isWire
    });

    elem.shells.forEach((electronCountInShell, shellIdx) => {
      const radius = baseRadii[shellIdx] || (3.6 + shellIdx * 2.2);

      // Orbital Ring Tube/Torus
      const ringGeom = new THREE.RingGeometry(radius - 0.03, radius + 0.03, performanceMode ? 32 : 64);
      const ringMesh = new THREE.Mesh(ringGeom, ringMat);
      // Inclined orbital planes for aesthetic educational 3D depth
      ringMesh.rotation.x = Math.PI / 2 + (shellIdx * 0.15);
      ringMesh.rotation.y = shellIdx * 0.2;
      group.add(ringMesh);

      // Electron Spheres
      for (let eIdx = 0; eIdx < electronCountInShell; eIdx++) {
        const elGeom = new THREE.SphereGeometry(0.24, sphereDetail, sphereDetail);
        const electron = new THREE.Mesh(elGeom, electronMat);
        electron.name = `electron_shell_${shellIdx}_${eIdx}`;
        electron.userData = {
          shellIdx,
          eIdx,
          totalInShell: electronCountInShell,
          radius,
          tiltX: ringMesh.rotation.x,
          tiltY: ringMesh.rotation.y
        };
        group.add(electron);
      }
    });

    // Reset camera focus for atom
    if (cameraRef.current) {
      cameraRef.current.position.set(0, 7, 24);
      cameraRef.current.lookAt(0, 0, 0);
    }
  }, [performanceMode]);

  // 2. BUILD PRESET MODELS (DNA, SOLENOID)
  const buildPresetModel = useCallback((type: 'dna' | 'solenoid', group: THREE.Group, isWire: boolean) => {
    disposeGroup(group);
    setLoadError(null);
    setModelStats(null);

    if (type === 'dna') {
      const segments = performanceMode ? 16 : 28;
      const radius = 3.2;
      const heightStep = 0.65;

      for (let i = -segments / 2; i < segments / 2; i++) {
        const angle = i * 0.42;
        const y = i * heightStep;
        const x1 = radius * Math.cos(angle);
        const z1 = radius * Math.sin(angle);
        const x2 = radius * Math.cos(angle + Math.PI);
        const z2 = radius * Math.sin(angle + Math.PI);

        // Strand Spheres
        const b1 = new THREE.Mesh(
          new THREE.SphereGeometry(0.42, 12, 12), 
          new THREE.MeshStandardMaterial({ color: 0x38bdf8, wireframe: isWire })
        );
        b1.position.set(x1, y, z1);
        group.add(b1);

        const b2 = new THREE.Mesh(
          new THREE.SphereGeometry(0.42, 12, 12), 
          new THREE.MeshStandardMaterial({ color: 0x818cf8, wireframe: isWire })
        );
        b2.position.set(x2, y, z2);
        group.add(b2);

        // Base pair rung
        const rungMat = new THREE.MeshStandardMaterial({ 
          color: i % 2 === 0 ? 0x22c55e : 0xf97316, 
          wireframe: isWire 
        });
        const rung = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, radius * 2, 8), rungMat);
        rung.position.set(0, y, 0);
        rung.rotation.z = Math.PI / 2;
        rung.rotation.y = -angle;
        group.add(rung);
      }
    } else if (type === 'solenoid') {
      const turns = 10;
      const coilRadius = 2.8;
      const totalPoints = performanceMode ? 100 : 200;
      const curvePoints: THREE.Vector3[] = [];

      for (let i = 0; i <= totalPoints; i++) {
        const t = i / totalPoints;
        const theta = t * turns * Math.PI * 2;
        const x = coilRadius * Math.cos(theta);
        const z = coilRadius * Math.sin(theta);
        const y = (t - 0.5) * 14;
        curvePoints.push(new THREE.Vector3(x, y, z));
      }

      const curve = new THREE.CatmullRomCurve3(curvePoints);
      const tubeGeom = new THREE.TubeGeometry(curve, totalPoints, 0.18, 8, false);
      const tubeMat = new THREE.MeshStandardMaterial({ 
        color: 0xf59e0b, 
        metalness: 0.8, 
        roughness: 0.3,
        wireframe: isWire 
      });
      group.add(new THREE.Mesh(tubeGeom, tubeMat));

      // Magnetic field core arrow
      const arrowMat = new THREE.MeshStandardMaterial({ color: 0x06b6d4, emissive: 0x0284c7 });
      const coreCyl = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 16, 8), arrowMat);
      group.add(coreCyl);
    }
  }, [performanceMode]);

  // 3. LOAD USER IMPORTED 3D MODEL
  const loadUser3DModel = useCallback(async (modelRecord: User3DModel, group: THREE.Group, isWire: boolean) => {
    disposeGroup(group);
    setLoadError(null);

    if (!modelRecord.fileData) {
      setLoadError({
        message: 'Unable to load 3D model data.',
        causes: ['Model data was not found in local IndexedDB storage.']
      });
      return;
    }

    try {
      const arrayBuffer = await modelRecord.fileData.arrayBuffer();
      const ext = modelRecord.fileType.toLowerCase();

      let loadedObject: THREE.Object3D | null = null;

      if (ext === 'stl') {
        const loader = new STLLoader();
        const geometry = loader.parse(arrayBuffer);
        const material = new THREE.MeshStandardMaterial({ 
          color: 0x94a3b8, 
          roughness: 0.4,
          metalness: 0.3,
          wireframe: isWire 
        });
        loadedObject = new THREE.Mesh(geometry, material);
      } else if (ext === 'obj') {
        const text = new TextDecoder().decode(arrayBuffer);
        const loader = new OBJLoader();
        loadedObject = loader.parse(text);
        if (isWire) {
          loadedObject.traverse((child: any) => {
            if (child.isMesh && child.material) child.material.wireframe = true;
          });
        }
      } else if (ext === 'glb' || ext === 'gltf') {
        const loader = new GLTFLoader();
        const gltf = await new Promise<any>((resolve, reject) => {
          loader.parse(arrayBuffer, '', resolve, reject);
        });
        loadedObject = gltf.scene;
        if (isWire) {
          loadedObject.traverse((child: any) => {
            if (child.isMesh && child.material) child.material.wireframe = true;
          });
        }
      }

      if (!loadedObject) {
        throw new Error('Unsupported 3D model parser format.');
      }

      // Compute statistics and normalize bounding box
      let meshCount = 0;
      let vertexCount = 0;
      let triangleCount = 0;

      const box = new THREE.Box3().setFromObject(loadedObject);
      const size = new THREE.Vector3();
      box.getSize(size);
      const center = new THREE.Vector3();
      box.getCenter(center);

      // Auto-center and normalize scale to fit viewer comfortably (target size ~12 units)
      const maxDim = Math.max(size.x, size.y, size.z) || 1;
      const scaleFactor = 12 / maxDim;
      loadedObject.position.sub(center.clone().multiplyScalar(scaleFactor));
      loadedObject.scale.set(scaleFactor, scaleFactor, scaleFactor);

      loadedObject.traverse((child: any) => {
        if (child.isMesh) {
          meshCount++;
          const geom = child.geometry;
          if (geom) {
            if (geom.attributes.position) {
              vertexCount += geom.attributes.position.count;
            }
            if (geom.index) {
              triangleCount += geom.index.count / 3;
            } else if (geom.attributes.position) {
              triangleCount += geom.attributes.position.count / 3;
            }
          }
        }
      });

      setModelStats({
        meshCount,
        vertexCount,
        triangleCount: Math.round(triangleCount),
        dimensions: {
          x: parseFloat(size.x.toFixed(2)),
          y: parseFloat(size.y.toFixed(2)),
          z: parseFloat(size.z.toFixed(2))
        }
      });

      group.add(loadedObject);

      // Focus camera on model
      if (cameraRef.current) {
        cameraRef.current.position.set(0, 8, 22);
        cameraRef.current.lookAt(0, 0, 0);
      }
    } catch (err: any) {
      console.error('Failed to parse 3D model:', err);
      setLoadError({
        message: `Unable to open 3D model "${modelRecord.name}".`,
        technical: err?.message || String(err),
        causes: [
          'The file geometry format might be invalid or corrupted.',
          'Missing embedded textures or vertex coordinates.',
          'Insufficient GPU WebGL memory to render high-polygon mesh.',
          'The file format is unsupported by local Three.js loaders.'
        ]
      });
    }
  }, []);

  // Initialize Three.js Scene and Renderer
  useEffect(() => {
    if (!containerRef.current) return;

    const width = containerRef.current.clientWidth || 800;
    const height = containerRef.current.clientHeight || 550;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 7, 24);
    cameraRef.current = camera;

    // 3. Renderer with low-end optimizations
    const renderer = new THREE.WebGLRenderer({ 
      antialias: !performanceMode,
      powerPreference: 'default'
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(performanceMode ? 1 : Math.min(window.devicePixelRatio || 1, 1.5));
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x6366f1, 1.4);
    dirLight1.position.set(15, 25, 20);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x38bdf8, 0.9);
    dirLight2.position.set(-15, -15, -15);
    scene.add(dirLight2);

    // 5. Helpers (Grid and Axes)
    const gridHelper = new THREE.GridHelper(24, 24, 0x4f46e5, 0x334155);
    gridHelper.position.y = -6;
    gridHelper.visible = showGrid;
    scene.add(gridHelper);
    gridHelperRef.current = gridHelper;

    const axesHelper = new THREE.AxesHelper(8);
    axesHelper.visible = showAxes;
    scene.add(axesHelper);
    axesHelperRef.current = axesHelper;

    // 6. Model Root Group
    const modelGroup = new THREE.Group();
    scene.add(modelGroup);
    modelGroupRef.current = modelGroup;

    // Build Initial Selection
    if (selectedType === 'element') {
      buildAtomModel(currentElement, modelGroup, wireframe);
    }

    // Interactive Drag Orbit & Wheel Controls
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    const dom = renderer.domElement;

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging || !modelGroupRef.current) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      modelGroupRef.current.rotation.y += deltaX * 0.008;
      modelGroupRef.current.rotation.x += deltaY * 0.008;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onMouseUp = () => { isDragging = false; };

    const onWheel = (e: WheelEvent) => {
      if (!cameraRef.current) return;
      cameraRef.current.position.z = Math.max(6, Math.min(60, cameraRef.current.position.z + e.deltaY * 0.025));
      e.preventDefault();
    };

    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('wheel', onWheel, { passive: false });

    // Animation Loop
    const animate = () => {
      // Auto-rotation of root model group
      if (autoRotate && modelGroupRef.current) {
        modelGroupRef.current.rotation.y += 0.004 * rotationSpeed;
      }

      // Orbital electron dynamics for Bohr atom model
      if (selectedType === 'element' && modelGroupRef.current) {
        // Inner shells orbit faster than outer shells
        shellAnglesRef.current[0] += 0.045; // K shell (fastest)
        shellAnglesRef.current[1] += 0.030; // L shell
        shellAnglesRef.current[2] += 0.022; // M shell
        shellAnglesRef.current[3] += 0.016; // N shell

        modelGroupRef.current.children.forEach(child => {
          if (child.name.startsWith('electron_shell_')) {
            const data = child.userData;
            const shellIdx = data.shellIdx || 0;
            const eIdx = data.eIdx || 0;
            const total = data.totalInShell || 1;
            const radius = data.radius || 4;
            const angleOffset = (eIdx / total) * Math.PI * 2;
            const currentAngle = shellAnglesRef.current[shellIdx] + angleOffset;

            // Compute local orbit coordinate
            const localX = radius * Math.cos(currentAngle);
            const localZ = radius * Math.sin(currentAngle);

            // Apply shell orbital plane tilt
            child.position.x = localX;
            child.position.y = -localZ * Math.sin(data.tiltX || 0);
            child.position.z = localZ * Math.cos(data.tiltX || 0);
          }
        });
      }

      renderer.render(scene, camera);
      reqAnimRef.current = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      if (reqAnimRef.current) cancelAnimationFrame(reqAnimRef.current);
      window.removeEventListener('resize', handleResize);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('wheel', onWheel);
      if (modelGroupRef.current) disposeGroup(modelGroupRef.current);
      renderer.dispose();
    };
  }, [performanceMode]);

  // Update Model when Selection changes
  useEffect(() => {
    if (!modelGroupRef.current) return;

    if (selectedType === 'element') {
      buildAtomModel(currentElement, modelGroupRef.current, wireframe);
      markRecent(currentElement.number);
    } else if (selectedType === 'preset') {
      buildPresetModel(selectedPreset, modelGroupRef.current, wireframe);
    } else if (selectedType === 'userModel' && selectedUserModelId) {
      const record = userModels.find(m => m.id === selectedUserModelId);
      if (record) {
        loadUser3DModel(record, modelGroupRef.current, wireframe);
      }
    }
  }, [
    selectedType, 
    selectedElementNumber, 
    selectedPreset, 
    selectedUserModelId, 
    wireframe, 
    currentElement, 
    userModels, 
    buildAtomModel, 
    buildPresetModel, 
    loadUser3DModel, 
    markRecent
  ]);

  // Reset Camera Position
  const handleResetCamera = () => {
    if (!cameraRef.current || !modelGroupRef.current) return;
    cameraRef.current.position.set(0, 7, 24);
    cameraRef.current.lookAt(0, 0, 0);
    modelGroupRef.current.rotation.set(0, 0, 0);
    showToast('Camera reset to default position', 'info');
  };

  // Import User 3D Model Handler (OBJ, STL, GLB, GLTF)
  const handleFileImport = async (file: File) => {
    const extMatch = file.name.match(/\.(obj|stl|glb|gltf)$/i);
    if (!extMatch) {
      showToast('Unsupported 3D format. Supported formats: OBJ, STL, GLB, GLTF.', 'warning');
      return;
    }

    const ext = extMatch[1].toLowerCase() as 'obj' | 'stl' | 'glb' | 'gltf';

    try {
      const id = await db.user3DModels.add({
        name: file.name.replace(/\.[^/.]+$/, ''),
        fileName: file.name,
        fileType: ext,
        fileSize: file.size,
        fileData: file,
        importedAt: Date.now(),
        favorite: false
      });

      setSelectedType('userModel');
      setSelectedUserModelId(id as number);
      setLibraryTab('userModels');
      showToast(`Imported ${file.name} successfully`, 'success');
    } catch (err) {
      console.error('Import error:', err);
      showToast('Failed to save 3D model into local storage.', 'error');
    }
  };

  // Delete User Model
  const handleDeleteUserModel = (id: number, name: string) => {
    askConfirmation({
      title: 'Delete 3D Model',
      message: `Are you sure you want to delete "${name}" from your local 3D library?`,
      confirmLabel: 'Delete',
      isDestructive: true,
      onConfirm: async () => {
        await db.user3DModels.delete(id);
        if (selectedUserModelId === id) {
          setSelectedType('element');
          setSelectedElementNumber(26);
        }
        showToast('Model removed from library.', 'info');
      }
    });
  };

  // Toggle Fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Filtered & Sorted Elements for Library Sidebar
  const filteredElements = useMemo(() => {
    return FIRST_30_ELEMENTS.filter(elem => {
      // Tab filter
      if (libraryTab === 'favorites' && !favoriteElementNumbers.includes(elem.number)) return false;
      if (libraryTab === 'recent' && !recentElementNumbers.includes(elem.number)) return false;
      // Category filter
      if (selectedCategory !== 'all' && elem.category !== selectedCategory) return false;
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = elem.name.toLowerCase().includes(q);
        const matchesSymbol = elem.symbol.toLowerCase() === q || elem.symbol.toLowerCase().includes(q);
        const matchesNum = String(elem.number) === q;
        if (!matchesName && !matchesSymbol && !matchesNum) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return a.number - b.number;
    });
  }, [libraryTab, favoriteElementNumbers, recentElementNumbers, selectedCategory, searchQuery, sortBy]);

  return (
    <div className="flex flex-col h-full w-full max-w-[1900px] mx-auto animate-in fade-in duration-300 pb-2 select-none">
      
      {/* Top Professional Toolbar */}
      <header className="h-12 flex items-center justify-between gap-4 mb-2 shrink-0 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-lg px-3 shadow-xs">
        
        {/* Left: Branding & Active Model Label */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 border-r border-stone-200 dark:border-stone-800 pr-3">
            <div className="w-7 h-7 bg-indigo-100 dark:bg-indigo-950/60 rounded flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold leading-none text-stone-900 dark:text-white">3D Learning Lab</div>
              <div className="text-[10px] text-stone-400">Offline WebGL Renderer</div>
            </div>
          </div>

          {/* Active Model Indicator */}
          <div className="flex items-center gap-2 text-xs">
            {selectedType === 'element' && (
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-indigo-600 text-white font-bold text-[11px] flex items-center justify-center">
                  {currentElement.symbol}
                </span>
                <span className="font-semibold text-stone-800 dark:text-stone-200">
                  {currentElement.name} (#{currentElement.number})
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-500 font-medium">
                  {currentElement.category}
                </span>
              </div>
            )}

            {selectedType === 'userModel' && (
              <div className="flex items-center gap-1.5 font-semibold text-stone-800 dark:text-stone-200">
                <Layers className="w-3.5 h-3.5 text-sky-500" />
                <span>{userModels.find(m => m.id === selectedUserModelId)?.name || 'Custom Model'}</span>
              </div>
            )}

            {selectedType === 'preset' && (
              <span className="font-semibold text-stone-800 dark:text-stone-200 uppercase tracking-wider text-[11px]">
                Preset: {selectedPreset}
              </span>
            )}
          </div>
        </div>

        {/* Right: Import Model & Global Action */}
        <div className="flex items-center gap-2">
          {/* Windows File Picker for 3D Models */}
          <label 
            className="cursor-pointer bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
            title="Import OBJ, STL, GLB, or GLTF 3D model"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import 3D Model</span>
            <input 
              type="file" 
              accept=".obj,.stl,.glb,.gltf" 
              className="hidden" 
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFileImport(file);
              }} 
            />
          </label>
        </div>
      </header>

      {/* Main Lab Layout: 3 Columns (Library Sidebar | 3D Viewport | Educational Inspector) */}
      <div className="flex-1 flex overflow-hidden rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-100 dark:bg-stone-950 relative shadow-inner">
        
        {/* ======================================================== */}
        {/* COLUMN 1: 3D MODEL & CHEMICAL ELEMENT LIBRARY SIDEBAR   */}
        {/* ======================================================== */}
        <aside className="w-80 bg-white dark:bg-stone-900 border-r border-stone-200 dark:border-stone-800 flex flex-col shrink-0 z-10">
          
          {/* Library Tabs */}
          <div className="h-10 flex border-b border-stone-200 dark:border-stone-800 shrink-0 text-xs">
            <button
              onClick={() => setLibraryTab('elements')}
              className={cn(
                "flex-1 font-semibold flex items-center justify-center gap-1 transition-colors border-b-2",
                libraryTab === 'elements' 
                  ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/30 dark:bg-indigo-950/20" 
                  : "border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200"
              )}
            >
              <Atom className="w-3.5 h-3.5" /> Elements (30)
            </button>
            <button
              onClick={() => setLibraryTab('userModels')}
              className={cn(
                "flex-1 font-semibold flex items-center justify-center gap-1 transition-colors border-b-2",
                libraryTab === 'userModels' 
                  ? "border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/30 dark:bg-indigo-950/20" 
                  : "border-transparent text-stone-500 hover:text-stone-800 dark:hover:text-stone-200"
              )}
            >
              <Box className="w-3.5 h-3.5" /> My Models ({userModels.length})
            </button>
            <button
              onClick={() => setLibraryTab('favorites')}
              className={cn(
                "px-3 flex items-center justify-center transition-colors border-b-2",
                libraryTab === 'favorites' 
                  ? "border-amber-500 text-amber-500 bg-amber-50/30 dark:bg-amber-950/20" 
                  : "border-transparent text-stone-400 hover:text-amber-500"
              )}
              title="Favorite Elements"
            >
              <Star className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Search & Filter Bar */}
          <div className="p-2 border-b border-stone-200 dark:border-stone-800 space-y-2 bg-stone-50/50 dark:bg-stone-900/50 shrink-0">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-2.5" />
              <input 
                type="text" 
                placeholder={libraryTab === 'elements' ? "Search Iron, Fe, 26..." : "Search user models..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md pl-8 pr-3 py-1.5 text-xs text-stone-900 dark:text-white"
              />
            </div>

            {libraryTab === 'elements' && (
              <div className="flex items-center justify-between text-[11px] text-stone-500">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="bg-transparent border border-stone-200 dark:border-stone-700 rounded px-1.5 py-0.5 text-[11px] text-stone-700 dark:text-stone-300"
                >
                  <option value="all">All Categories</option>
                  <option value="Transition Metal">Transition Metal</option>
                  <option value="Nonmetal">Nonmetal</option>
                  <option value="Noble Gas">Noble Gas</option>
                  <option value="Alkali Metal">Alkali Metal</option>
                  <option value="Alkaline Earth">Alkaline Earth</option>
                  <option value="Metalloid">Metalloid</option>
                  <option value="Halogen">Halogen</option>
                  <option value="Post-Transition Metal">Post-Transition Metal</option>
                </select>

                <button 
                  onClick={() => setSortBy(sortBy === 'number' ? 'name' : 'number')}
                  className="hover:text-indigo-600 dark:hover:text-indigo-400 flex items-center gap-1 font-medium"
                >
                  Sort: {sortBy === 'number' ? 'Atomic #' : 'Name'}
                </button>
              </div>
            )}
          </div>

          {/* List Content */}
          <div className="flex-1 overflow-y-auto p-2 custom-scrollbar space-y-1">
            
            {/* TAB: CHEMICAL ELEMENTS 1 TO 30 */}
            {libraryTab === 'elements' && (
              filteredElements.map(elem => {
                const isSelected = selectedType === 'element' && selectedElementNumber === elem.number;
                const isFav = favoriteElementNumbers.includes(elem.number);

                return (
                  <div
                    key={elem.number}
                    onClick={() => {
                      setSelectedType('element');
                      setSelectedElementNumber(elem.number);
                    }}
                    className={cn(
                      "group flex items-center justify-between p-2 rounded-lg border cursor-pointer transition-all text-xs",
                      isSelected 
                        ? "bg-indigo-50 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800 shadow-xs" 
                        : "bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700"
                    )}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div 
                        className="w-8 h-8 rounded-md flex flex-col items-center justify-center font-bold text-white shrink-0 shadow-xs"
                        style={{ backgroundColor: elem.colorHex }}
                      >
                        <span className="text-[9px] leading-none opacity-80">{elem.number}</span>
                        <span className="text-xs leading-none">{elem.symbol}</span>
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-stone-900 dark:text-stone-100 truncate flex items-center gap-1.5">
                          <span>{elem.name}</span>
                          <span className="text-[10px] text-stone-400 font-mono font-normal">{elem.mass.toFixed(2)}</span>
                        </div>
                        <div className="text-[10px] text-stone-500 truncate">{elem.category}</div>
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(elem.number);
                      }}
                      className={cn(
                        "p-1 rounded hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors",
                        isFav ? "text-amber-500" : "text-stone-300 dark:text-stone-600 opacity-0 group-hover:opacity-100"
                      )}
                      title="Toggle Favorite"
                    >
                      <Star className={cn("w-3.5 h-3.5", isFav && "fill-amber-500")} />
                    </button>
                  </div>
                );
              })
            )}

            {/* TAB: USER IMPORTED 3D MODELS */}
            {libraryTab === 'userModels' && (
              userModels.length === 0 ? (
                <div className="text-center py-10 px-4 text-stone-400">
                  <Box className="w-8 h-8 mx-auto mb-2 text-stone-300 dark:text-stone-700" />
                  <div className="font-semibold text-xs text-stone-700 dark:text-stone-300 mb-1">No custom models imported</div>
                  <p className="text-[11px] text-stone-500 max-w-[200px] mx-auto mb-4">
                    Import local OBJ, STL, GLB, or GLTF files from your disk to inspect in offline 3D.
                  </p>
                  <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 text-white rounded text-xs font-semibold">
                    <Upload className="w-3 h-3" /> Browse Files
                    <input 
                      type="file" 
                      accept=".obj,.stl,.glb,.gltf" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileImport(file);
                      }} 
                    />
                  </label>
                </div>
              ) : (
                userModels.map(model => {
                  const isSelected = selectedType === 'userModel' && selectedUserModelId === model.id;

                  return (
                    <div
                      key={model.id}
                      onClick={() => {
                        setSelectedType('userModel');
                        setSelectedUserModelId(model.id!);
                      }}
                      className={cn(
                        "group flex items-center justify-between p-2 rounded-lg border cursor-pointer transition-all text-xs",
                        isSelected 
                          ? "bg-indigo-50 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800 shadow-xs" 
                          : "bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-800 hover:border-stone-300 dark:hover:border-stone-700"
                      )}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-7 h-7 rounded bg-sky-100 dark:bg-sky-950/50 text-sky-600 flex items-center justify-center font-bold text-[10px] shrink-0 uppercase">
                          {model.fileType}
                        </div>
                        <div className="min-w-0">
                          <div className="font-semibold text-stone-900 dark:text-stone-100 truncate">{model.name}</div>
                          <div className="text-[10px] text-stone-400">
                            {(model.fileSize / 1024).toFixed(1)} KB • {new Date(model.importedAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteUserModel(model.id!, model.name);
                        }}
                        className="p-1 text-stone-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete Model"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })
              )
            )}

            {/* TAB: PRESET DEMO MODELS */}
            <div className="pt-3 border-t border-stone-200 dark:border-stone-800 mt-3">
              <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-2 py-1">
                Structural Presets
              </div>
              <div className="space-y-1">
                <button
                  onClick={() => {
                    setSelectedType('preset');
                    setSelectedPreset('dna');
                  }}
                  className={cn(
                    "w-full text-left p-2 rounded text-xs flex items-center justify-between",
                    selectedType === 'preset' && selectedPreset === 'dna'
                      ? "bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-semibold"
                      : "hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300"
                  )}
                >
                  <span>DNA Double Helix</span>
                  <span className="text-[10px] text-stone-400">Biology</span>
                </button>
                <button
                  onClick={() => {
                    setSelectedType('preset');
                    setSelectedPreset('solenoid');
                  }}
                  className={cn(
                    "w-full text-left p-2 rounded text-xs flex items-center justify-between",
                    selectedType === 'preset' && selectedPreset === 'solenoid'
                      ? "bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 font-semibold"
                      : "hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300"
                  )}
                >
                  <span>Solenoid Magnetic Coil</span>
                  <span className="text-[10px] text-stone-400">Physics</span>
                </button>
              </div>
            </div>

          </div>
        </aside>

        {/* ======================================================== */}
        {/* COLUMN 2: 3D WEBGL VIEWPORT & CONTROLS TOOLBAR           */}
        {/* ======================================================== */}
        <main className="flex-1 flex flex-col relative h-full min-w-0 bg-stone-900 overflow-hidden">
          
          {/* Top Viewport Floating Controls */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10 pointer-events-none">
            
            {/* Left Controls: Wireframe, Grid, Axes, Background */}
            <div className="pointer-events-auto flex items-center gap-1.5 bg-stone-900/85 backdrop-blur border border-stone-800/80 rounded-lg p-1 text-xs text-stone-300 shadow-lg">
              <button
                onClick={() => setWireframe(!wireframe)}
                className={cn(
                  "px-2.5 py-1 rounded transition-colors flex items-center gap-1",
                  wireframe ? "bg-indigo-600 text-white font-semibold" : "hover:bg-stone-800 text-stone-400"
                )}
                title="Toggle Wireframe Mode"
              >
                <Layers className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Wireframe</span>
              </button>

              <button
                onClick={() => setShowGrid(!showGrid)}
                className={cn(
                  "p-1.5 rounded transition-colors",
                  showGrid ? "bg-stone-700 text-white" : "hover:bg-stone-800 text-stone-400"
                )}
                title="Toggle Coordinate Grid"
              >
                <Grid className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={() => setShowAxes(!showAxes)}
                className={cn(
                  "p-1.5 rounded transition-colors",
                  showAxes ? "bg-stone-700 text-white" : "hover:bg-stone-800 text-stone-400"
                )}
                title="Toggle XYZ Axes"
              >
                <Compass className="w-3.5 h-3.5" />
              </button>

              <div className="h-3.5 w-px bg-stone-700 mx-1" />

              {/* Background Theme Selector */}
              <select
                value={bgTheme}
                onChange={(e) => setBgTheme(e.target.value as BackgroundTheme)}
                className="bg-stone-800 border-none rounded px-2 py-0.5 text-[11px] text-stone-300 cursor-pointer"
                title="Change Viewer Background"
              >
                <option value="dark">Slate Dark</option>
                <option value="black">Deep Black</option>
                <option value="gray">Studio Gray</option>
                <option value="light">Lab Light</option>
              </select>
            </div>

            {/* Right Controls: Auto-Rotate, Reset Camera, Fullscreen */}
            <div className="pointer-events-auto flex items-center gap-1.5 bg-stone-900/85 backdrop-blur border border-stone-800/80 rounded-lg p-1 text-xs text-stone-300 shadow-lg">
              <button
                onClick={() => setAutoRotate(!autoRotate)}
                className={cn(
                  "px-2.5 py-1 rounded transition-colors flex items-center gap-1",
                  autoRotate ? "bg-emerald-600 text-white font-semibold" : "hover:bg-stone-800 text-stone-400"
                )}
                title="Toggle Auto-Rotation"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Rotate</span>
              </button>

              <button
                onClick={handleResetCamera}
                className="p-1.5 hover:bg-stone-800 text-stone-400 hover:text-white rounded transition-colors"
                title="Reset Camera View"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={toggleFullscreen}
                className="p-1.5 hover:bg-stone-800 text-stone-400 hover:text-white rounded transition-colors"
                title="Toggle Viewport Fullscreen"
              >
                {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* 3D Canvas Mount Point */}
          <div 
            ref={containerRef} 
            className="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing outline-hidden"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              const file = e.dataTransfer.files?.[0];
              if (file) handleFileImport(file);
            }}
          />

          {/* Educational Disclaimer Pill (Requirement 15) */}
          {selectedType === 'element' && (
            <div className="absolute bottom-3 left-3 bg-stone-900/80 backdrop-blur border border-stone-800 text-stone-400 text-[10px] px-2.5 py-1 rounded-md pointer-events-none">
              Educational visualization model • Orbit distances not to physical scale
            </div>
          )}

          {/* Error Overlay if Model fails to load */}
          {loadError && (
            <div className="absolute inset-0 bg-stone-950/90 backdrop-blur-sm flex items-center justify-center p-6 z-30">
              <div className="max-w-md w-full bg-stone-900 border border-stone-800 rounded-xl p-6 shadow-2xl text-stone-100">
                <div className="flex items-center gap-3 text-rose-500 mb-3">
                  <FileX className="w-7 h-7 shrink-0" />
                  <div>
                    <h3 className="font-bold text-sm">{loadError.message}</h3>
                    <p className="text-xs text-stone-500">Failed to render geometry</p>
                  </div>
                </div>

                <div className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-2">
                  Possible Causes
                </div>
                <ul className="text-xs text-stone-400 space-y-1 list-disc list-inside mb-4 bg-stone-950 p-3 rounded-lg border border-stone-800">
                  {loadError.causes.map((c, i) => (
                    <li key={i}>{c}</li>
                  ))}
                </ul>

                {loadError.technical && (
                  <div className="text-[10px] font-mono text-stone-500 mb-4 truncate">
                    Details: {loadError.technical}
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      if (selectedType === 'element') buildAtomModel(currentElement, modelGroupRef.current!, wireframe);
                    }}
                    className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Try Again
                  </button>

                  <label className="flex-1 py-2 border border-stone-700 hover:bg-stone-800 text-stone-300 rounded text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer text-center">
                    <Upload className="w-3.5 h-3.5" /> Import Another
                    <input 
                      type="file" 
                      accept=".obj,.stl,.glb,.gltf" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileImport(file);
                      }} 
                    />
                  </label>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* ======================================================== */}
        {/* COLUMN 3: SCIENTIFIC & EDUCATIONAL INSPECTOR PANEL       */}
        {/* ======================================================== */}
        <aside className="w-84 bg-white dark:bg-stone-900 border-l border-stone-200 dark:border-stone-800 flex flex-col shrink-0 z-10">
          
          {selectedType === 'element' ? (
            <div className="flex-1 flex flex-col h-full overflow-hidden">
              
              {/* Element Header Card */}
              <div className="p-4 border-b border-stone-200 dark:border-stone-800 bg-stone-50/70 dark:bg-stone-900/70 shrink-0">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                      Element #{currentElement.number} • Period {currentElement.period} • Group {currentElement.group}
                    </span>
                    <h2 className="text-xl font-extrabold text-stone-900 dark:text-white mt-0.5">
                      {currentElement.name}
                    </h2>
                  </div>

                  <div 
                    className="w-11 h-11 rounded-lg flex flex-col items-center justify-center text-white font-black shadow-sm"
                    style={{ backgroundColor: currentElement.colorHex }}
                  >
                    <span className="text-[10px] leading-none opacity-80">{currentElement.number}</span>
                    <span className="text-base leading-none">{currentElement.symbol}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 mt-3">
                  <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300">
                    {currentElement.category}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                    {currentElement.phase} at STP
                  </span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                    {currentElement.mass} u
                  </span>
                </div>
              </div>

              {/* View Mode Switcher Buttons (Requirement 16) */}
              <div className="p-2 border-b border-stone-200 dark:border-stone-800 flex gap-1 bg-stone-100/50 dark:bg-stone-900/50 shrink-0">
                <button
                  onClick={() => setElementViewMode('atom3d')}
                  className={cn(
                    "flex-1 py-1.5 text-xs font-semibold rounded transition-colors text-center",
                    elementViewMode === 'atom3d'
                      ? "bg-white dark:bg-stone-800 text-indigo-600 dark:text-indigo-400 shadow-xs"
                      : "text-stone-500 hover:text-stone-800 dark:hover:text-stone-200"
                  )}
                >
                  Atom Model
                </button>
                <button
                  onClick={() => setElementViewMode('config')}
                  className={cn(
                    "flex-1 py-1.5 text-xs font-semibold rounded transition-colors text-center",
                    elementViewMode === 'config'
                      ? "bg-white dark:bg-stone-800 text-indigo-600 dark:text-indigo-400 shadow-xs"
                      : "text-stone-500 hover:text-stone-800 dark:hover:text-stone-200"
                  )}
                >
                  Electrons
                </button>
                <button
                  onClick={() => setElementViewMode('info')}
                  className={cn(
                    "flex-1 py-1.5 text-xs font-semibold rounded transition-colors text-center",
                    elementViewMode === 'info'
                      ? "bg-white dark:bg-stone-800 text-indigo-600 dark:text-indigo-400 shadow-xs"
                      : "text-stone-500 hover:text-stone-800 dark:hover:text-stone-200"
                  )}
                >
                  Properties
                </button>
              </div>

              {/* Sub-View Details */}
              <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-4 text-xs">
                
                {/* SUB-VIEW 1: ATOM MODEL METRICS */}
                {elementViewMode === 'atom3d' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 rounded-lg">
                        <div className="text-[10px] text-rose-600 dark:text-rose-400 font-semibold uppercase">Protons</div>
                        <div className="text-base font-bold text-rose-700 dark:text-rose-300">{currentElement.protons}</div>
                      </div>
                      <div className="p-2.5 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-900/40 rounded-lg">
                        <div className="text-[10px] text-sky-600 dark:text-sky-400 font-semibold uppercase">Neutrons</div>
                        <div className="text-base font-bold text-sky-700 dark:text-sky-300">{currentElement.neutrons}</div>
                      </div>
                      <div className="p-2.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/40 rounded-lg">
                        <div className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold uppercase">Electrons</div>
                        <div className="text-base font-bold text-amber-700 dark:text-amber-300">{currentElement.electrons}</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-stone-700 dark:text-stone-300 mb-2">Bohr Orbital Shells</h4>
                      <div className="space-y-1.5 font-mono text-[11px]">
                        {currentElement.shells.map((count, idx) => {
                          const shellLetters = ['K', 'L', 'M', 'N'];
                          const maxCapacity = 2 * Math.pow(idx + 1, 2); // 2n^2
                          const percent = Math.round((count / maxCapacity) * 100);

                          return (
                            <div key={idx} className="bg-stone-50 dark:bg-stone-800/60 p-2 rounded border border-stone-200 dark:border-stone-800">
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-bold text-indigo-600 dark:text-indigo-400">
                                  Shell {shellLetters[idx]} (n={idx + 1}):
                                </span>
                                <span className="text-stone-600 dark:text-stone-300">
                                  {count} / {maxCapacity} electrons
                                </span>
                              </div>
                              <div className="h-1.5 w-full bg-stone-200 dark:bg-stone-700 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-amber-500 rounded-full" 
                                  style={{ width: `${percent}%` }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {/* SUB-VIEW 2: ELECTRON CONFIGURATION */}
                {elementViewMode === 'config' && (
                  <div className="space-y-4">
                    <div className="p-3 bg-stone-100 dark:bg-stone-800/80 rounded-lg border border-stone-200 dark:border-stone-700">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-1">
                        Quantum Electron Configuration
                      </div>
                      <div className="text-base font-mono font-bold text-indigo-600 dark:text-indigo-400">
                        {currentElement.electronConfig}
                      </div>
                      {currentElement.number === 24 && (
                        <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-1 leading-snug">
                          Aufbau exception: One 4s electron shifts into the 3d subshell to achieve symmetric half-filled 3d⁵ stability.
                        </p>
                      )}
                      {currentElement.number === 29 && (
                        <p className="text-[11px] text-amber-600 dark:text-amber-400 mt-1 leading-snug">
                          Aufbau exception: Promotes a 4s electron to create a fully closed, stable 3d¹⁰ d-subshell.
                        </p>
                      )}
                    </div>

                    <div>
                      <h4 className="font-semibold text-stone-700 dark:text-stone-300 mb-2">Valence Electrons</h4>
                      <p className="text-stone-500 text-[11px] leading-relaxed mb-3">
                        The outermost valence shell contains{' '}
                        <strong className="text-stone-900 dark:text-white">
                          {currentElement.shells[currentElement.shells.length - 1]} valence electron(s)
                        </strong>
                        , dictating chemical bonding behavior, oxidation states, and electronegativity.
                      </p>
                    </div>
                  </div>
                )}

                {/* SUB-VIEW 3: ELEMENT PROPERTIES & REAL-WORLD CONTEXT */}
                {elementViewMode === 'info' && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-stone-700 dark:text-stone-300 mb-1">Overview & Context</h4>
                      <p className="text-stone-600 dark:text-stone-400 leading-relaxed text-[11px]">
                        {currentElement.summary}
                      </p>
                    </div>

                    <div className="space-y-2 border-t border-stone-100 dark:border-stone-800 pt-3">
                      <div className="flex justify-between py-1 border-b border-stone-100 dark:border-stone-800">
                        <span className="text-stone-500">Atomic Mass:</span>
                        <span className="font-mono font-semibold text-stone-800 dark:text-stone-200">{currentElement.mass} amu</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-stone-100 dark:border-stone-800">
                        <span className="text-stone-500">Density:</span>
                        <span className="font-mono font-semibold text-stone-800 dark:text-stone-200">
                          {currentElement.density ? `${currentElement.density} g/cm³` : '—'}
                        </span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-stone-100 dark:border-stone-800">
                        <span className="text-stone-500">Standard Phase:</span>
                        <span className="font-semibold text-stone-800 dark:text-stone-200">{currentElement.phase}</span>
                      </div>
                    </div>
                  </div>
                )}

              </div>
            </div>
          ) : selectedType === 'userModel' ? (
            /* USER MODEL INSPECTOR */
            <div className="flex-1 flex flex-col p-4 overflow-y-auto custom-scrollbar space-y-4 text-xs">
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-sky-500">User 3D Asset</div>
                <h3 className="text-lg font-bold text-stone-900 dark:text-white mt-0.5">
                  {userModels.find(m => m.id === selectedUserModelId)?.name}
                </h3>
              </div>

              {modelStats && (
                <div className="space-y-3">
                  <div className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-lg border border-stone-200 dark:border-stone-800">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-2">
                      Geometry Diagnostics
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                      <div>
                        <span className="text-stone-500">Meshes:</span>{' '}
                        <strong className="text-stone-800 dark:text-stone-200">{modelStats.meshCount}</strong>
                      </div>
                      <div>
                        <span className="text-stone-500">Vertices:</span>{' '}
                        <strong className="text-stone-800 dark:text-stone-200">{modelStats.vertexCount.toLocaleString()}</strong>
                      </div>
                      <div>
                        <span className="text-stone-500">Triangles:</span>{' '}
                        <strong className="text-stone-800 dark:text-stone-200">{modelStats.triangleCount.toLocaleString()}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-stone-50 dark:bg-stone-800/60 rounded-lg border border-stone-200 dark:border-stone-800">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-2">
                      Bounding Box Dimensions
                    </div>
                    <div className="space-y-1 font-mono text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-stone-500">X (Width):</span>
                        <span className="text-stone-800 dark:text-stone-200">{modelStats.dimensions.x} units</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Y (Height):</span>
                        <span className="text-stone-800 dark:text-stone-200">{modelStats.dimensions.y} units</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-stone-500">Z (Depth):</span>
                        <span className="text-stone-800 dark:text-stone-200">{modelStats.dimensions.z} units</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* PRESET INSPECTOR */
            <div className="flex-1 flex flex-col p-4 overflow-y-auto space-y-4 text-xs">
              <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-500">Structural Preset</div>
              <h3 className="text-lg font-bold text-stone-900 dark:text-white capitalize">{selectedPreset} Simulation</h3>
              <p className="text-stone-500 text-xs leading-relaxed">
                {selectedPreset === 'dna' 
                  ? 'Double-stranded deoxyribonucleic acid helix featuring antiparallel sugar-phosphate backbones and complementary nitrogenous base pairs.'
                  : 'Helical copper coil generating a uniform axial magnetic field in response to direct electrical current induction.'}
              </p>
            </div>
          )}

        </aside>

      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { 
  BookOpen, ChevronRight, ChevronDown, Play, 
  CheckCircle2, Circle, MoreHorizontal, Target, BookMarked,
  Filter, Search, ArrowUpDown
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

export function Curriculum() {
  const navigate = useNavigate();
  const subjects = useLiveQuery(() => db.subjects.toArray());
  const chapters = useLiveQuery(() => db.chapters.toArray());
  const goals = useLiveQuery(() => db.goals.toArray());

  const [expandedSubject, setExpandedSubject] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleSubject = (id: number) => {
    setExpandedSubject(expandedSubject === id ? null : id);
  };

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-500">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Curriculum Management</h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400 mt-1">
            Manage your subjects, track chapter progress, and align your learning goals.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="px-4 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 text-stone-700 dark:text-zinc-300 rounded-md text-sm font-medium shadow-sm hover:bg-stone-50 dark:hover:bg-zinc-800 transition-colors">
            Curriculum Settings
          </button>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium shadow-sm hover:bg-indigo-700 transition-colors">
            Add Subject
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4 shrink-0">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input 
            type="text" 
            placeholder="Search subjects or chapters..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md text-sm text-stone-900 dark:text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          />
        </div>
        <button className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md text-sm text-stone-700 dark:text-zinc-300 hover:bg-stone-50 dark:hover:bg-zinc-800 transition-colors">
          <Filter className="w-4 h-4" /> Filter
        </button>
      </div>

      {/* Data Table Area */}
      <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex-1 min-h-0 flex flex-col overflow-hidden">
        
        {/* Table Header */}
        <div className="grid grid-cols-[auto_1fr_150px_150px_100px_80px] gap-4 px-4 py-3 border-b border-stone-200 dark:border-zinc-800 bg-stone-50/80 dark:bg-zinc-900/80 text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider shrink-0">
          <div className="w-6"></div>
          <div className="flex items-center gap-1 cursor-pointer hover:text-stone-700 dark:hover:text-zinc-200">Subject / Chapter <ArrowUpDown className="w-3 h-3" /></div>
          <div>Progress</div>
          <div>Active Goals</div>
          <div>Status</div>
          <div className="text-right">Actions</div>
        </div>

        {/* Table Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {(!subjects || subjects.length === 0) ? (
            <div className="flex flex-col items-center justify-center h-full text-stone-500 dark:text-zinc-400 py-12">
              <BookMarked className="w-12 h-12 mb-4 text-stone-300 dark:text-zinc-700" />
              <p className="text-sm font-medium text-stone-900 dark:text-white mb-1">No subjects found</p>
              <p className="text-xs">Add a subject to start building your curriculum.</p>
            </div>
          ) : (
            <div className="divide-y divide-stone-100 dark:divide-zinc-800/50">
              {subjects
                .filter(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()))
                .map(subject => {
                const isExpanded = expandedSubject === subject.id;
                const subjectChapters = chapters?.filter(c => c.subjectId === subject.id) || [];
                const subjectGoals = goals?.filter(g => g.subjectId === subject.id && !g.completed) || [];
                
                return (
                  <React.Fragment key={subject.id}>
                    {/* Subject Row (Master) */}
                    <div 
                      className={cn(
                        "grid grid-cols-[auto_1fr_150px_150px_100px_80px] gap-4 px-4 py-3 items-center group transition-colors cursor-pointer",
                        isExpanded ? "bg-stone-50 dark:bg-zinc-800/30" : "hover:bg-stone-50 dark:hover:bg-zinc-800/50 bg-white dark:bg-zinc-900"
                      )}
                      onClick={() => toggleSubject(subject.id!)}
                    >
                      <div className="w-6 flex justify-center text-stone-400">
                        {subjectChapters.length > 0 ? (
                          isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />
                        ) : <Circle className="w-2 h-2 fill-current opacity-20" />}
                      </div>
                      
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: subject.color || '#94a3b8' }} />
                        <span className="font-semibold text-stone-900 dark:text-white truncate">{subject.name}</span>
                        <span className="text-xs text-stone-400 bg-stone-100 dark:bg-zinc-800 px-1.5 py-0.5 rounded font-medium border border-stone-200 dark:border-zinc-700">
                          {subjectChapters.length} ch
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-stone-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                          <div className="h-full rounded-full bg-indigo-500" style={{ width: '15%' }}></div>
                        </div>
                        <span className="text-xs font-medium text-stone-600 dark:text-zinc-400 w-8 text-right">15%</span>
                      </div>
                      
                      <div className="flex items-center gap-1.5 text-xs text-stone-600 dark:text-zinc-400">
                        <Target className="w-3.5 h-3.5 text-orange-500" />
                        {subjectGoals.length} pending
                      </div>
                      
                      <div>
                        <span className="inline-flex items-center text-[10px] uppercase font-bold tracking-wider text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded border border-emerald-100 dark:border-emerald-800/30">
                          Active
                        </span>
                      </div>
                      
                      <div className="text-right flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          className="p-1.5 text-stone-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded transition-colors"
                          onClick={(e) => { e.stopPropagation(); navigate(`/workspace`); }}
                          title="Start Session"
                        >
                          <Play className="w-4 h-4" />
                        </button>
                        <button 
                          className="p-1.5 text-stone-400 hover:text-stone-900 dark:hover:text-white rounded transition-colors"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Chapter Rows (Detail) */}
                    {isExpanded && subjectChapters.map(chapter => {
                      const chapterGoals = subjectGoals.filter(g => g.chapterId === chapter.id);
                      return (
                        <div 
                          key={chapter.id} 
                          className="grid grid-cols-[auto_1fr_150px_150px_100px_80px] gap-4 px-4 py-2.5 items-center bg-stone-50/50 dark:bg-zinc-900/30 border-t border-stone-100 dark:border-zinc-800/50 group hover:bg-stone-100 dark:hover:bg-zinc-800/80 transition-colors"
                        >
                          <div className="w-6"></div>
                          
                          <div className="flex items-center gap-3 min-w-0 pl-6 border-l-2 border-stone-200 dark:border-zinc-700 ml-3">
                            <span className="text-sm font-medium text-stone-700 dark:text-zinc-300 truncate">{chapter.name}</span>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <CheckCircle2 className="w-3.5 h-3.5 text-stone-300 dark:text-zinc-600" />
                            <span className="text-xs text-stone-500 dark:text-zinc-500">Not started</span>
                          </div>
                          
                          <div className="text-xs text-stone-500 dark:text-zinc-400">
                            {chapterGoals.length > 0 ? `${chapterGoals.length} goals` : '-'}
                          </div>
                          
                          <div></div>
                          
                          <div className="text-right flex items-center justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                            <button className="text-[11px] font-medium text-indigo-600 dark:text-indigo-400 hover:underline">
                              View Details
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </React.Fragment>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

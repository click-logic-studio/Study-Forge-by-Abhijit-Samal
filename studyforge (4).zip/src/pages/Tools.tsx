import React, { useState, useRef, useEffect } from 'react';
import { 
  Calculator, Atom, ArrowRightLeft, TrendingUp, 
  FileText, Printer, Search, Copy, Check, RotateCcw, 
  HelpCircle, ChevronRight, BookOpen, Sparkles
} from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { cn } from '@/lib/utils';
import { useUIStore } from '@/store/uiStore';

type ActiveTool = 'formulas' | 'calculator' | 'converter' | 'grapher' | 'templates' | 'report';

export function Tools() {
  const showToast = useUIStore((state) => state.showToast);
  const [activeTool, setActiveTool] = useState<ActiveTool>('formulas');

  // FORMULA SHEET STATE
  const [formulaSearch, setFormulaSearch] = useState('');
  const [formulaSubject, setFormulaSubject] = useState<'all' | 'physics' | 'chemistry' | 'math'>('all');
  const [copiedFormula, setCopiedFormula] = useState<string | null>(null);

  // CALCULATOR STATE
  const [calcDisplay, setCalcDisplay] = useState('0');
  const [calcHistory, setCalcHistory] = useState<string[]>([]);
  const [isRad, setIsRad] = useState(true);

  // UNIT CONVERTER STATE
  const [convCategory, setConvCategory] = useState<'length' | 'mass' | 'temp' | 'pressure' | 'energy'>('length');
  const [convInput, setConvInput] = useState<number>(1);
  const [convFrom, setConvFrom] = useState<string>('meter');
  const [convTo, setConvTo] = useState<string>('kilometer');

  // GRAPHER STATE
  const [graphType, setGraphType] = useState<'linear' | 'quadratic' | 'sin'>('quadratic');
  const [coeffA, setCoeffA] = useState<number>(1);
  const [coeffB, setCoeffB] = useState<number>(0);
  const [coeffC, setCoeffC] = useState<number>(-4);
  const graphCanvasRef = useRef<HTMLCanvasElement>(null);

  // REPORT GENERATOR DATA
  const profile = useLiveQuery(() => db.profile.get(1));
  const subjects = useLiveQuery(() => db.subjects.toArray()) || [];
  const sessions = useLiveQuery(() => db.studySessions.toArray()) || [];
  const quizzes = useLiveQuery(() => db.quizAttempts.toArray()) || [];

  // COPY HELPER
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFormula(text);
    setTimeout(() => setCopiedFormula(null), 2000);
  };

  // CALCULATOR LOGIC
  const handleCalcClick = (val: string) => {
    if (val === 'C') {
      setCalcDisplay('0');
    } else if (val === 'DEL') {
      setCalcDisplay(prev => prev.length > 1 ? prev.slice(0, -1) : '0');
    } else if (val === '=') {
      try {
        let expr = calcDisplay
          .replace(/×/g, '*')
          .replace(/÷/g, '/')
          .replace(/π/g, 'Math.PI')
          .replace(/e/g, 'Math.E');

        // Handle trigs
        expr = expr.replace(/sin\(([^)]+)\)/g, (_, angle) => isRad ? `Math.sin(${angle})` : `Math.sin((${angle}) * Math.PI / 180)`);
        expr = expr.replace(/cos\(([^)]+)\)/g, (_, angle) => isRad ? `Math.cos(${angle})` : `Math.cos((${angle}) * Math.PI / 180)`);
        expr = expr.replace(/tan\(([^)]+)\)/g, (_, angle) => isRad ? `Math.tan(${angle})` : `Math.tan((${angle}) * Math.PI / 180)`);
        expr = expr.replace(/sqrt\(([^)]+)\)/g, 'Math.sqrt($1)');
        expr = expr.replace(/log\(([^)]+)\)/g, 'Math.log10($1)');
        expr = expr.replace(/ln\(([^)]+)\)/g, 'Math.log($1)');

        // Safely evaluate math expression without external dependencies
        const result = Function(`"use strict"; return (${expr})`)();
        const formatted = String(Math.round(result * 100000000) / 100000000);
        setCalcHistory(prev => [`${calcDisplay} = ${formatted}`, ...prev.slice(0, 9)]);
        setCalcDisplay(formatted);
      } catch {
        setCalcDisplay('Error');
      }
    } else {
      setCalcDisplay(prev => prev === '0' || prev === 'Error' ? val : prev + val);
    }
  };

  // UNIT CONVERSION CALCULATION
  const convertUnits = (): number => {
    const v = convInput;
    if (convCategory === 'length') {
      const toMeters: Record<string, number> = { meter: 1, kilometer: 1000, centimeter: 0.01, millimeter: 0.001, inch: 0.0254, foot: 0.3048, mile: 1609.34 };
      const meters = v * (toMeters[convFrom] || 1);
      return meters / (toMeters[convTo] || 1);
    }
    if (convCategory === 'mass') {
      const toKg: Record<string, number> = { kilogram: 1, gram: 0.001, milligram: 0.000001, pound: 0.453592, ounce: 0.0283495 };
      const kg = v * (toKg[convFrom] || 1);
      return kg / (toKg[convTo] || 1);
    }
    if (convCategory === 'temp') {
      let celsius = v;
      if (convFrom === 'fahrenheit') celsius = (v - 32) * (5 / 9);
      if (convFrom === 'kelvin') celsius = v - 273.15;
      
      if (convTo === 'celsius') return celsius;
      if (convTo === 'fahrenheit') return (celsius * 9 / 5) + 32;
      if (convTo === 'kelvin') return celsius + 273.15;
    }
    if (convCategory === 'pressure') {
      const toPascal: Record<string, number> = { pascal: 1, bar: 100000, atmosphere: 101325, mmhg: 133.322 };
      const pascals = v * (toPascal[convFrom] || 1);
      return pascals / (toPascal[convTo] || 1);
    }
    if (convCategory === 'energy') {
      const toJoule: Record<string, number> = { joule: 1, kilojoule: 1000, calorie: 4.184, kilocalorie: 4184, kilowatt_hour: 3600000, electron_volt: 1.602176634e-19 };
      const joules = v * (toJoule[convFrom] || 1);
      return joules / (toJoule[convTo] || 1);
    }
    return v;
  };

  // 2D CANVAS GRAPH PLOTTER
  useEffect(() => {
    if (activeTool !== 'grapher' || !graphCanvasRef.current) return;
    const canvas = graphCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    // Coordinate settings
    const originX = width / 2;
    const originY = height / 2;
    const scale = 24; // pixels per unit

    // Draw grid
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (let x = originX % scale; x < width; x += scale) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = originY % scale; y < height; y += scale) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Axes
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, originY);
    ctx.lineTo(width, originY);
    ctx.moveTo(originX, 0);
    ctx.lineTo(originX, height);
    ctx.stroke();

    // Plot Curve
    ctx.strokeStyle = '#4f46e5';
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    let started = false;
    for (let px = 0; px < width; px += 2) {
      const x = (px - originX) / scale;
      let y = 0;
      if (graphType === 'linear') {
        y = coeffA * x + coeffC;
      } else if (graphType === 'quadratic') {
        y = coeffA * Math.pow(x, 2) + coeffB * x + coeffC;
      } else if (graphType === 'sin') {
        y = coeffA * Math.sin(coeffB * x || x);
      }

      const py = originY - (y * scale);
      if (py >= -100 && py <= height + 100) {
        if (!started) {
          ctx.moveTo(px, py);
          started = true;
        } else {
          ctx.lineTo(px, py);
        }
      }
    }
    ctx.stroke();

  }, [activeTool, graphType, coeffA, coeffB, coeffC]);

  // NCERT Class 10 Formula Bank
  const FORMULAS = [
    { subject: 'physics', title: 'Mirror Formula', formula: '1/f = 1/v + 1/u', desc: 'Relates focal length (f), image distance (v), and object distance (u).' },
    { subject: 'physics', title: 'Magnification (Mirrors)', formula: 'm = h\'/h = -v/u', desc: 'Negative for real & inverted images, positive for virtual & erect.' },
    { subject: 'physics', title: 'Lens Formula', formula: '1/f = 1/v - 1/u', desc: 'Relates focal length to object and image distances for lenses.' },
    { subject: 'physics', title: 'Power of a Lens', formula: 'P = 1/f (in metres)', desc: 'Unit: Dioptre (D). Convex lens has +P, concave lens has -P.' },
    { subject: 'physics', title: 'Ohm\'s Law', formula: 'V = I × R', desc: 'Potential difference (V) equals Current (I) times Resistance (R).' },
    { subject: 'physics', title: 'Resistance of Conductor', formula: 'R = ρ × (l / A)', desc: 'ρ is resistivity, l is length, A is cross-sectional area.' },
    { subject: 'physics', title: 'Resistors in Series', formula: 'Rs = R1 + R2 + R3 + ...', desc: 'Current remains constant; voltages add up.' },
    { subject: 'physics', title: 'Resistors in Parallel', formula: '1/Rp = 1/R1 + 1/R2 + 1/R3 + ...', desc: 'Voltage remains constant; currents divide.' },
    { subject: 'physics', title: 'Joule\'s Law of Heating', formula: 'H = I² × R × t', desc: 'Heat produced in a resistor over time t in seconds.' },
    { subject: 'physics', title: 'Electric Power', formula: 'P = V × I = I²R = V²/R', desc: 'Unit: Watt (W). Commercial unit: 1 kWh = 3.6 × 10⁶ J.' },
    { subject: 'chemistry', title: 'Photosynthesis Reaction', formula: '6CO₂ + 12H₂O → C₆H₁₂O₆ + 6O₂ + 6H₂O', desc: 'Chlorophyll and sunlight catalyzed chemical synthesis in plants.' },
    { subject: 'chemistry', title: 'Plaster of Paris Formation', formula: 'CaSO₄·½H₂O + 1½H₂O → CaSO₄·2H₂O', desc: 'POP mixing with water hardens into Gypsum.' },
    { subject: 'chemistry', title: 'Bleaching Powder Reaction', formula: 'Ca(OH)₂ + Cl₂ → CaOCl₂ + H₂O', desc: 'Action of chlorine gas on dry slaked lime.' },
    { subject: 'chemistry', title: 'pH Definition', formula: 'pH = -log₁₀[H⁺]', desc: 'pH < 7 is acidic, pH = 7 neutral, pH > 7 basic/alkaline.' },
    { subject: 'chemistry', title: 'General Alkane Formula', formula: 'CₙH₂ₙ₊₂', desc: 'Saturated hydrocarbons (e.g. Methane CH₄, Ethane C₂H₆).' },
    { subject: 'math', title: 'Quadratic Formula', formula: 'x = (-b ± √(b² - 4ac)) / (2a)', desc: 'Roots of ax² + bx + c = 0. Discriminant D = b² - 4ac.' },
    { subject: 'math', title: 'Arithmetic Progression nth Term', formula: 'aₙ = a + (n - 1)d', desc: 'a is first term, d is common difference.' },
    { subject: 'math', title: 'AP Sum of First n Terms', formula: 'Sₙ = n/2 × [2a + (n - 1)d]', desc: 'Alternative form: Sₙ = n/2 × [a + l], where l is last term.' },
    { subject: 'math', title: 'Distance Formula', formula: 'd = √((x₂ - x₁)² + (y₂ - y₁)²)', desc: 'Distance between points (x₁, y₁) and (x₂, y₂).' },
    { subject: 'math', title: 'Section Formula', formula: 'P(x,y) = ((m₁x₂ + m₂x₁)/(m₁+m₂), (m₁y₂ + m₂y₁)/(m₁+m₂))', desc: 'Point P dividing line segment in ratio m₁:m₂ internally.' },
    { subject: 'math', title: 'Pythagorean Trig Identity', formula: 'sin²θ + cos²θ = 1', desc: 'Also: 1 + tan²θ = sec²θ and 1 + cot²θ = cosec²θ.' },
    { subject: 'math', title: 'Sphere Volume & Surface Area', formula: 'V = (4/3)πr³, A = 4πr²', desc: 'Volume and total surface area of a sphere of radius r.' },
    { subject: 'math', title: 'Cylinder Surface Area', formula: 'CSA = 2πrh, TSA = 2πr(r + h)', desc: 'Curved and total surface area of a right circular cylinder.' }
  ];

  const filteredFormulas = FORMULAS.filter(f => {
    const matchSub = formulaSubject === 'all' || f.subject === formulaSubject;
    const matchSearch = f.title.toLowerCase().includes(formulaSearch.toLowerCase()) || 
                        f.formula.toLowerCase().includes(formulaSearch.toLowerCase()) ||
                        f.desc.toLowerCase().includes(formulaSearch.toLowerCase());
    return matchSub && matchSearch;
  });

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-300 pb-10">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Academic Utilities & Tools</h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            Offline scientific calculator, Class 10 NCERT formula sheet, unit converter, and academic report generator.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 bg-stone-100 dark:bg-zinc-800/80 p-1 rounded-lg border border-stone-200 dark:border-zinc-700/80 overflow-x-auto text-xs">
          {[
            { id: 'formulas', label: 'Formula Sheet', icon: BookOpen },
            { id: 'calculator', label: 'Scientific Calculator', icon: Calculator },
            { id: 'converter', label: 'Unit Converter', icon: ArrowRightLeft },
            { id: 'grapher', label: 'Function Grapher', icon: TrendingUp },
            { id: 'templates', label: 'Study Templates', icon: FileText },
            { id: 'report', label: 'Progress Report', icon: Printer },
          ].map(t => {
            const Icon = t.icon;
            const isActive = activeTool === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTool(t.id as ActiveTool)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors",
                  isActive
                    ? "bg-white dark:bg-zinc-700 text-stone-900 dark:text-white shadow-sm"
                    : "text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white"
                )}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* TOOL 1: FORMULA SHEET */}
      {activeTool === 'formulas' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3 items-center justify-between bg-white dark:bg-zinc-900 p-3 rounded-lg border border-stone-200 dark:border-zinc-800 shadow-sm">
            <div className="relative w-full sm:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input 
                type="text"
                placeholder="Search formulas, laws, equations..."
                value={formulaSearch}
                onChange={(e) => setFormulaSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-stone-50 dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded-md text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-stone-900 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto text-xs">
              {(['all', 'physics', 'chemistry', 'math'] as const).map(sub => (
                <button
                  key={sub}
                  onClick={() => setFormulaSubject(sub)}
                  className={cn(
                    "px-3 py-1 rounded-md font-semibold capitalize transition-colors",
                    formulaSubject === sub
                      ? "bg-indigo-600 text-white"
                      : "bg-stone-100 dark:bg-zinc-800 text-stone-600 dark:text-zinc-400 hover:bg-stone-200"
                  )}
                >
                  {sub}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFormulas.map((f, i) => (
              <div 
                key={i}
                className="p-4 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl shadow-sm flex flex-col justify-between space-y-3 group hover:border-indigo-300 dark:hover:border-indigo-900/60 transition-colors"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 dark:text-zinc-500">
                      {f.subject}
                    </span>
                    <button
                      onClick={() => copyToClipboard(f.formula)}
                      className="p-1 rounded text-stone-400 hover:text-indigo-600 transition-colors"
                      title="Copy formula"
                    >
                      {copiedFormula === f.formula ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <h3 className="font-bold text-sm text-stone-900 dark:text-white mt-0.5">{f.title}</h3>
                  <div className="mt-2.5 p-2.5 bg-stone-50 dark:bg-zinc-950 rounded-md font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400 border border-stone-200/60 dark:border-zinc-800/80 break-words">
                    {f.formula}
                  </div>
                </div>
                <p className="text-[11px] text-stone-500 dark:text-zinc-400 leading-snug">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TOOL 2: SCIENTIFIC CALCULATOR */}
      {activeTool === 'calculator' && (
        <div className="max-w-2xl mx-auto w-full bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm overflow-hidden flex flex-col">
          
          {/* Display Header */}
          <div className="p-6 bg-stone-50 dark:bg-zinc-950 border-b border-stone-200 dark:border-zinc-800 flex flex-col items-end justify-center min-h-[120px]">
            <div className="flex items-center justify-between w-full mb-2 text-xs text-stone-400">
              <button 
                onClick={() => setIsRad(!isRad)}
                className="px-2 py-0.5 bg-stone-200 dark:bg-zinc-800 rounded font-mono text-[10px] font-bold text-stone-700 dark:text-zinc-300"
              >
                {isRad ? 'RAD' : 'DEG'}
              </button>
              <span className="font-mono text-[11px] truncate max-w-xs">{calcHistory[0] || 'Ready'}</span>
            </div>
            <div className="text-3xl font-mono font-bold text-stone-900 dark:text-white tracking-tight break-all">
              {calcDisplay}
            </div>
          </div>

          {/* Keypad Grid */}
          <div className="p-6 grid grid-cols-5 gap-2.5 bg-white dark:bg-zinc-900 text-sm font-semibold select-none">
            {/* Row 1: Scientific functions */}
            {['sin(', 'cos(', 'tan(', 'sqrt(', 'C'].map(k => (
              <button 
                key={k} 
                onClick={() => handleCalcClick(k)}
                className="py-3 rounded-lg bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 hover:bg-stone-200 dark:hover:bg-zinc-700 font-mono text-xs transition-colors"
              >
                {k}
              </button>
            ))}

            {/* Row 2 */}
            {['log(', 'ln(', '^', 'π', 'DEL'].map(k => (
              <button 
                key={k} 
                onClick={() => handleCalcClick(k === '^' ? '**' : k)}
                className="py-3 rounded-lg bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 hover:bg-stone-200 dark:hover:bg-zinc-700 font-mono text-xs transition-colors"
              >
                {k}
              </button>
            ))}

            {/* Row 3 */}
            {['(', ')', '÷', '×', '-'].map(k => (
              <button 
                key={k} 
                onClick={() => handleCalcClick(k)}
                className="py-3 rounded-lg bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300 hover:bg-stone-200 dark:hover:bg-zinc-700 font-mono transition-colors"
              >
                {k}
              </button>
            ))}

            {/* Row 4 */}
            {['7', '8', '9', '+', 'e'].map(k => (
              <button 
                key={k} 
                onClick={() => handleCalcClick(k)}
                className="py-3 rounded-lg bg-stone-50 dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 text-stone-900 dark:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 font-mono text-base transition-colors"
              >
                {k}
              </button>
            ))}

            {/* Row 5 */}
            {['4', '5', '6', '1', '2'].map(k => (
              <button 
                key={k} 
                onClick={() => handleCalcClick(k)}
                className="py-3 rounded-lg bg-stone-50 dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 text-stone-900 dark:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 font-mono text-base transition-colors"
              >
                {k}
              </button>
            ))}

            {/* Row 6 */}
            {['3', '0', '.', '00', '='].map(k => (
              <button 
                key={k} 
                onClick={() => handleCalcClick(k)}
                className={cn(
                  "py-3 rounded-lg font-mono text-base transition-colors",
                  k === '=' 
                    ? "bg-indigo-600 text-white hover:bg-indigo-700 font-bold col-span-1 shadow-sm" 
                    : "bg-stone-50 dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 text-stone-900 dark:text-white hover:bg-stone-100 dark:hover:bg-zinc-800"
                )}
              >
                {k}
              </button>
            ))}
          </div>

          {/* History */}
          {calcHistory.length > 0 && (
            <div className="p-4 border-t border-stone-100 dark:border-zinc-800/80 bg-stone-50/50 dark:bg-zinc-950/40 text-xs">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block mb-1">Recent Calculations</span>
              <div className="space-y-1 font-mono text-stone-600 dark:text-zinc-400">
                {calcHistory.slice(0, 3).map((h, i) => (
                  <div key={i} className="truncate">{h}</div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* TOOL 3: UNIT CONVERTER */}
      {activeTool === 'converter' && (
        <div className="max-w-2xl mx-auto w-full bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-stone-900 dark:text-white">Physical Quantity Converter</h2>
            <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">High-precision conversions for physics & chemistry problem sets.</p>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2 border-b border-stone-200 dark:border-zinc-800 text-xs font-semibold">
            {(['length', 'mass', 'temp', 'pressure', 'energy'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => {
                  setConvCategory(cat);
                  if (cat === 'length') { setConvFrom('meter'); setConvTo('kilometer'); }
                  if (cat === 'mass') { setConvFrom('kilogram'); setConvTo('gram'); }
                  if (cat === 'temp') { setConvFrom('celsius'); setConvTo('fahrenheit'); }
                  if (cat === 'pressure') { setConvFrom('pascal'); setConvTo('atmosphere'); }
                  if (cat === 'energy') { setConvFrom('joule'); setConvTo('calorie'); }
                }}
                className={cn(
                  "px-3 py-1.5 rounded-md capitalize transition-colors",
                  convCategory === cat 
                    ? "bg-indigo-600 text-white" 
                    : "text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800"
                )}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-700 dark:text-zinc-300">From</label>
              <input 
                type="number"
                value={convInput}
                onChange={(e) => setConvInput(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded-md text-base font-mono text-stone-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <select
                value={convFrom}
                onChange={(e) => setConvFrom(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white capitalize"
              >
                {convCategory === 'length' && ['meter', 'kilometer', 'centimeter', 'millimeter', 'inch', 'foot', 'mile'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'mass' && ['kilogram', 'gram', 'milligram', 'pound', 'ounce'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'temp' && ['celsius', 'fahrenheit', 'kelvin'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'pressure' && ['pascal', 'bar', 'atmosphere', 'mmhg'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'energy' && ['joule', 'kilojoule', 'calorie', 'kilocalorie', 'kilowatt_hour', 'electron_volt'].map(u => <option key={u} value={u}>{u.replace('_', ' ')}</option>)}
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-700 dark:text-zinc-300">To (Result)</label>
              <div className="w-full px-3 py-2 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900/40 rounded-md text-base font-mono font-bold text-indigo-700 dark:text-indigo-300">
                {String(Math.round(convertUnits() * 1000000) / 1000000)}
              </div>
              <select
                value={convTo}
                onChange={(e) => setConvTo(e.target.value)}
                className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white capitalize"
              >
                {convCategory === 'length' && ['meter', 'kilometer', 'centimeter', 'millimeter', 'inch', 'foot', 'mile'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'mass' && ['kilogram', 'gram', 'milligram', 'pound', 'ounce'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'temp' && ['celsius', 'fahrenheit', 'kelvin'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'pressure' && ['pascal', 'bar', 'atmosphere', 'mmhg'].map(u => <option key={u} value={u}>{u}</option>)}
                {convCategory === 'energy' && ['joule', 'kilojoule', 'calorie', 'kilocalorie', 'kilowatt_hour', 'electron_volt'].map(u => <option key={u} value={u}>{u.replace('_', ' ')}</option>)}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* TOOL 4: 2D FUNCTION GRAPHER */}
      {activeTool === 'grapher' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-4 flex flex-col items-center">
            <canvas 
              ref={graphCanvasRef} 
              width={640} 
              height={440} 
              className="w-full max-w-[640px] aspect-[4/3] bg-stone-50 dark:bg-zinc-950 rounded-lg border border-stone-200 dark:border-zinc-800"
            />
          </div>

          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-5 space-y-5">
            <div>
              <h3 className="font-bold text-sm text-stone-900 dark:text-white">Function Controls</h3>
              <p className="text-xs text-stone-500 mt-0.5">Visualize Class 10 curves and polynomials</p>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-stone-700 dark:text-zinc-300">Curve Type</label>
              <div className="grid grid-cols-3 gap-1.5 text-xs font-semibold">
                <button
                  onClick={() => setGraphType('linear')}
                  className={cn("py-1.5 rounded border text-center transition-colors", graphType === 'linear' ? "bg-indigo-600 text-white border-indigo-600" : "border-stone-200 dark:border-zinc-800")}
                >
                  Linear
                </button>
                <button
                  onClick={() => setGraphType('quadratic')}
                  className={cn("py-1.5 rounded border text-center transition-colors", graphType === 'quadratic' ? "bg-indigo-600 text-white border-indigo-600" : "border-stone-200 dark:border-zinc-800")}
                >
                  Parabola
                </button>
                <button
                  onClick={() => setGraphType('sin')}
                  className={cn("py-1.5 rounded border text-center transition-colors", graphType === 'sin' ? "bg-indigo-600 text-white border-indigo-600" : "border-stone-200 dark:border-zinc-800")}
                >
                  Sine Wave
                </button>
              </div>
            </div>

            <div className="space-y-4 pt-2 text-xs">
              <div>
                <div className="flex justify-between font-mono mb-1">
                  <span>Coefficient A:</span>
                  <span className="font-bold">{coeffA}</span>
                </div>
                <input 
                  type="range" min={-5} max={5} step={0.5} 
                  value={coeffA} onChange={(e) => setCoeffA(parseFloat(e.target.value))}
                  className="w-full accent-indigo-600"
                />
              </div>

              {graphType !== 'linear' && (
                <div>
                  <div className="flex justify-between font-mono mb-1">
                    <span>Coefficient B:</span>
                    <span className="font-bold">{coeffB}</span>
                  </div>
                  <input 
                    type="range" min={-5} max={5} step={0.5} 
                    value={coeffB} onChange={(e) => setCoeffB(parseFloat(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>
              )}

              {graphType !== 'sin' && (
                <div>
                  <div className="flex justify-between font-mono mb-1">
                    <span>Constant C:</span>
                    <span className="font-bold">{coeffC}</span>
                  </div>
                  <input 
                    type="range" min={-10} max={10} step={1} 
                    value={coeffC} onChange={(e) => setCoeffC(parseFloat(e.target.value))}
                    className="w-full accent-indigo-600"
                  />
                </div>
              )}
            </div>

            <div className="p-3 bg-stone-50 dark:bg-zinc-950 rounded border border-stone-200 dark:border-zinc-800 font-mono text-xs text-indigo-600 dark:text-indigo-400 text-center font-bold">
              {graphType === 'linear' && `y = ${coeffA}x ${coeffC >= 0 ? '+' : '-'} ${Math.abs(coeffC)}`}
              {graphType === 'quadratic' && `y = ${coeffA}x² ${coeffB >= 0 ? '+' : '-'} ${Math.abs(coeffB)}x ${coeffC >= 0 ? '+' : '-'} ${Math.abs(coeffC)}`}
              {graphType === 'sin' && `y = ${coeffA} · sin(${coeffB}x)`}
            </div>
          </div>
        </div>
      )}

      {/* TOOL 5: STUDY TEMPLATES */}
      {activeTool === 'templates' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm flex flex-col justify-between space-y-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">Structured Note-Taking</div>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">Cornell Method Template</h3>
              <p className="text-xs text-stone-500 mt-2 leading-relaxed">
                Standard academic layout featuring left-hand cue margin for key questions, right-hand lecture notes, and a bottom summary block.
              </p>
            </div>
            <button 
              onClick={async () => {
                await db.notes.add({
                  title: 'Cornell Notes: [Insert Topic]',
                  content: '# Cornell Notes Template\n\n## Cues & Keywords\n- Concept 1:\n- Formula:\n\n## Core Notes\n- Detailed explanations here...\n\n## Summary\n- In 2-3 sentences, what is the core takeaway?',
                  tags: ['cornell', 'template'],
                  isPinned: false,
                  templateType: 'cornell',
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                });
                showToast('Cornell Notes template saved to your Notes library.', 'success');
              }}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-semibold shadow-sm transition-colors"
            >
              Instantiate in Notes
            </button>
          </div>

          <div className="p-5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm flex flex-col justify-between space-y-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Conceptual Mastery</div>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">Feynman Technique Sheet</h3>
              <p className="text-xs text-stone-500 mt-2 leading-relaxed">
                Step-by-step framework to explain any complex physics or chemistry law as if teaching a 10-year-old child to expose knowledge gaps.
              </p>
            </div>
            <button 
              onClick={async () => {
                await db.notes.add({
                  title: 'Feynman Technique: [Insert Concept]',
                  content: '# Feynman Technique Sheet\n\n### 1. Concept to Master\n[e.g. Electromagnetic Induction]\n\n### 2. Simple Explanation (Zero Jargon)\nExplain in plain words as if teaching a beginner...\n\n### 3. Pinpoint Gaps in Logic\nWhere did you get stuck or need to look up a formula?\n\n### 4. Simplified Analogy\nCreate a real-world metaphor.',
                  tags: ['feynman', 'template'],
                  isPinned: false,
                  templateType: 'feynman',
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                });
                showToast('Feynman Technique template saved to your Notes library.', 'success');
              }}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-semibold shadow-sm transition-colors"
            >
              Instantiate in Notes
            </button>
          </div>

          <div className="p-5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm flex flex-col justify-between space-y-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">Exam Preparation</div>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">Active Recall 3-Pass Grid</h3>
              <p className="text-xs text-stone-500 mt-2 leading-relaxed">
                Three-tiered revision review: Pass 1 (immediate recall), Pass 2 (3-day interval), Pass 3 (7-day pre-exam verification).
              </p>
            </div>
            <button 
              onClick={async () => {
                await db.notes.add({
                  title: 'Active Recall 3-Pass Checklist',
                  content: '# Active Recall 3-Pass Checklist\n\n- [ ] Pass 1: Closed-book diagram drawing\n- [ ] Pass 2: Formula derivation from first principles\n- [ ] Pass 3: 5 Past-year CBSE questions under timed condition',
                  tags: ['active_recall', 'template'],
                  isPinned: false,
                  templateType: 'active_recall',
                  createdAt: Date.now(),
                  updatedAt: Date.now()
                });
                showToast('Active Recall template saved to your Notes library.', 'success');
              }}
              className="w-full py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-md text-xs font-semibold shadow-sm transition-colors"
            >
              Instantiate in Notes
            </button>
          </div>
        </div>
      )}

      {/* TOOL 6: PRINTABLE STUDY REPORT */}
      {activeTool === 'report' && (
        <div className="max-w-3xl mx-auto w-full space-y-4">
          <div className="flex justify-end">
            <button 
              onClick={() => window.print()}
              className="px-4 py-2 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md text-xs font-semibold flex items-center gap-2 shadow-sm hover:opacity-90"
            >
              <Printer className="w-4 h-4" />
              <span>Print Official Report</span>
            </button>
          </div>

          <div className="p-8 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm space-y-6 text-stone-900 dark:text-zinc-100 print:border-none print:shadow-none">
            <div className="border-b border-stone-200 dark:border-zinc-800 pb-4 flex justify-between items-start">
              <div>
                <h2 className="text-xl font-bold tracking-tight">StudyForge Academic Progress Report</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">Verified Local Academic Dossier</p>
              </div>
              <div className="text-right text-xs font-mono text-stone-500">
                <div>Date: {new Date().toLocaleDateString()}</div>
                <div>Status: Air-Gapped Verified</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 p-4 bg-stone-50 dark:bg-zinc-800/40 rounded-lg text-xs font-mono">
              <div>
                <span className="font-sans text-[10px] font-bold uppercase text-stone-400 block">Candidate</span>
                <span className="font-bold text-sm">{profile?.name || 'Self-Directed Scholar'}</span>
              </div>
              <div>
                <span className="font-sans text-[10px] font-bold uppercase text-stone-400 block">Target Examination</span>
                <span className="font-bold">{profile?.examName || 'CBSE Class 10'}</span>
              </div>
              <div>
                <span className="font-sans text-[10px] font-bold uppercase text-stone-400 block">Total Study Time</span>
                <span className="font-bold text-sm">
                  {Math.round(sessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0) / 60 * 10) / 10} Hours
                </span>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-3">Enrolled Curriculum Subjects</h4>
              <div className="border border-stone-200 dark:border-zinc-800 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-stone-50 dark:bg-zinc-800 border-b border-stone-200 dark:border-zinc-800 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-3">Subject</th>
                      <th className="p-3">Code</th>
                      <th className="p-3 text-right">Registered Sessions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-zinc-800">
                    {subjects.map(s => {
                      const count = sessions.filter(sess => sess.subjectId === s.id).length;
                      return (
                        <tr key={s.id}>
                          <td className="p-3 font-semibold">{s.name}</td>
                          <td className="p-3 font-mono text-stone-500">{s.code || 'NCERT-10'}</td>
                          <td className="p-3 text-right font-mono">{count} sessions</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500 mb-3">Verified Assessment Attempts</h4>
              {quizzes.length === 0 ? (
                <div className="p-4 border border-dashed border-stone-200 dark:border-zinc-800 rounded-lg text-center text-xs text-stone-400">
                  No official quiz assessments submitted yet. Complete quizzes to populate this ledger.
                </div>
              ) : (
                <div className="border border-stone-200 dark:border-zinc-800 rounded-lg overflow-hidden text-xs font-mono">
                  {quizzes.map((q, idx) => (
                    <div key={idx} className="p-3 flex justify-between border-b border-stone-100 dark:border-zinc-800 last:border-b-0">
                      <span className="font-sans font-medium">{q.quizTitle}</span>
                      <span className="font-bold">{q.score} / {q.totalQuestions} ({q.percentage}%)</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

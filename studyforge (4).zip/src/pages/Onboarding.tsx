import React, { useState } from 'react';
import { db } from '@/db/db';
import { Hash, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function Onboarding() {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [nickname, setNickname] = useState('');
  const [theme, setTheme] = useState('Paper');
  const [curriculum, setCurriculum] = useState('None');
  
  const handleComplete = async () => {
    if (!name.trim()) return;
    
    await db.profile.put({
      id: 1,
      name,
      nickname: nickname || name.split(' ')[0],
      theme,
      performanceMode: false,
      onboarded: true,
      accentColor: '#4f46e5', // indigo-600
      curriculum,
    });

    if (curriculum === 'Class 10 - CBSE/NCERT') {
      // Seed some subjects
      await db.subjects.bulkAdd([
        { name: 'Physics (Class 10)', color: '#3b82f6', icon: 'Atom', createdAt: Date.now() },
        { name: 'Chemistry (Class 10)', color: '#ec4899', icon: 'FlaskConical', createdAt: Date.now() },
        { name: 'Biology (Class 10)', color: '#22c55e', icon: 'Leaf', createdAt: Date.now() },
        { name: 'Mathematics (Class 10)', color: '#f97316', icon: 'Calculator', createdAt: Date.now() },
      ]);
    }
    
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-zinc-950 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-8 pb-6 border-b border-stone-100 dark:border-zinc-800 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mb-4">
            <Hash className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-stone-900 dark:text-zinc-100">Welcome to StudyForge</h1>
          <p className="text-stone-500 dark:text-zinc-400 mt-2 text-sm">Your personal academic command center. Let's set up your local profile. Data stays on your device.</p>
        </div>
        
        <div className="p-8 space-y-5">
          <div>
            <label className="block text-sm font-medium text-stone-700 dark:text-zinc-300 mb-1">Full Name</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 border border-stone-300 dark:border-zinc-700 rounded-lg bg-stone-50 dark:bg-zinc-950 text-stone-900 dark:text-zinc-100 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              placeholder="e.g. Alex Rivera"
              autoFocus
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-stone-700 dark:text-zinc-300 mb-1">Nickname (Optional)</label>
            <input 
              type="text"
              value={nickname}
              onChange={(e) => setNickname(e.target.value)}
              className="w-full px-4 py-2 border border-stone-300 dark:border-zinc-700 rounded-lg bg-stone-50 dark:bg-zinc-950 text-stone-900 dark:text-zinc-100 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
              placeholder="What should we call you?"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 dark:text-zinc-300 mb-2">Curriculum</label>
            <select
              value={curriculum}
              onChange={(e) => setCurriculum(e.target.value)}
              className="w-full px-4 py-2 border border-stone-300 dark:border-zinc-700 rounded-lg bg-stone-50 dark:bg-zinc-950 text-stone-900 dark:text-zinc-100 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            >
              <option value="None">None / General</option>
              <option value="Class 10 - CBSE/NCERT">Class 10 — CBSE/NCERT</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 dark:text-zinc-300 mb-2">Preferred Theme</label>
            <div className="grid grid-cols-2 gap-3">
              {['Paper', 'Forge Dark', 'Midnight', 'Arctic'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTheme(t)}
                  className={`px-4 py-3 border rounded-lg text-sm font-medium transition-all ${
                    theme === t 
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 dark:bg-indigo-900/30 dark:border-indigo-400 dark:text-indigo-300' 
                      : 'border-stone-200 dark:border-zinc-700 text-stone-600 dark:text-zinc-400 hover:border-stone-300 dark:hover:border-zinc-600'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="p-6 bg-stone-50 dark:bg-zinc-950/50 border-t border-stone-100 dark:border-zinc-800 flex justify-end">
          <button 
            onClick={handleComplete}
            disabled={!name.trim()}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-stone-300 disabled:dark:bg-zinc-700 disabled:cursor-not-allowed text-white px-6 py-2.5 rounded-lg font-medium transition-all"
          >
            Enter StudyForge <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

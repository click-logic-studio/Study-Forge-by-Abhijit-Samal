import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { Plus, Search, FileText, Trash2, Edit3 } from 'lucide-react';
import { format } from 'date-fns';

export function Notes() {
  const [search, setSearch] = useState('');
  const [activeNoteId, setActiveNoteId] = useState<number | null>(null);
  
  const notes = useLiveQuery(() => 
    db.notes.filter(n => n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase())).toArray()
  , [search]);

  const activeNote = notes?.find(n => n.id === activeNoteId) || null;

  const handleCreateNote = async () => {
    const id = await db.notes.add({
      title: 'Untitled Note',
      content: '',
      tags: [],
      isPinned: false,
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
    setActiveNoteId(id as number);
  };

  const handleUpdateNote = async (id: number, changes: Partial<typeof activeNote>) => {
    await db.notes.update(id, { ...changes, updatedAt: Date.now() });
  };

  const handleDeleteNote = async (id: number) => {
    await db.notes.delete(id);
    if (activeNoteId === id) setActiveNoteId(null);
  };

  return (
    <div className="flex h-[calc(100vh-6rem)] gap-6">
      {/* Sidebar List */}
      <div className="w-80 flex flex-col bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl overflow-hidden shrink-0">
        <div className="p-4 border-b border-stone-200 dark:border-zinc-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-lg">My Notes</h2>
            <button 
              onClick={handleCreateNote}
              className="p-1.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input 
              type="text" 
              placeholder="Search notes..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-stone-100 dark:bg-zinc-800 border-none rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
          {notes?.length === 0 ? (
            <div className="text-center p-4 text-stone-500 text-sm">No notes found.</div>
          ) : (
            notes?.map(note => (
              <button
                key={note.id}
                onClick={() => setActiveNoteId(note.id as number)}
                className={`w-full text-left p-3 rounded-lg transition-colors ${
                  activeNoteId === note.id 
                    ? 'bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800/50' 
                    : 'hover:bg-stone-50 dark:hover:bg-zinc-800 border border-transparent'
                }`}
              >
                <div className="font-medium text-stone-900 dark:text-zinc-100 truncate">{note.title || 'Untitled'}</div>
                <div className="text-xs text-stone-500 dark:text-zinc-500 mt-1 flex justify-between">
                  <span>{format(note.updatedAt, 'MMM d, yy')}</span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl overflow-hidden flex flex-col">
        {activeNote ? (
          <>
            <div className="p-4 border-b border-stone-200 dark:border-zinc-800 flex items-center justify-between">
              <input
                type="text"
                value={activeNote.title}
                onChange={e => handleUpdateNote(activeNote.id as number, { title: e.target.value })}
                className="text-xl font-bold bg-transparent border-none outline-none focus:ring-0 text-stone-900 dark:text-zinc-100 w-full"
                placeholder="Note Title"
              />
              <button 
                onClick={() => handleDeleteNote(activeNote.id as number)}
                className="p-2 text-stone-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 rounded-lg transition-colors ml-4"
                title="Delete note"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 p-0 flex">
              <textarea
                value={activeNote.content}
                onChange={e => handleUpdateNote(activeNote.id as number, { content: e.target.value })}
                className="w-full h-full p-6 bg-transparent border-none outline-none resize-none custom-scrollbar text-stone-800 dark:text-zinc-200 leading-relaxed font-mono text-sm"
                placeholder="Start typing your note here (Markdown supported)..."
              />
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-stone-400">
            <FileText className="w-16 h-16 mb-4 text-stone-200 dark:text-zinc-800" />
            <p>Select a note or create a new one.</p>
          </div>
        )}
      </div>
    </div>
  );
}

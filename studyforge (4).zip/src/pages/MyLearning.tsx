import React from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { BookOpen, Target, Clock, ArrowRight, Play, FileText, Bookmark, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

export function MyLearning() {
  const navigate = useNavigate();
  const subjects = useLiveQuery(() => db.subjects.toArray());
  const sessions = useLiveQuery(() => db.studySessions.orderBy('startTime').reverse().toArray());
  const goals = useLiveQuery(() => db.goals.filter(g => !g.completed).toArray());
  const recentFiles = useLiveQuery(async () => {
    const files = await db.library.toArray();
    return files.sort((a, b) => b.createdAt - a.createdAt).slice(0, 4);
  });

  return (
    <div className="flex flex-col gap-6 w-full max-w-[1600px] mx-auto pb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      <header className="mb-2">
        <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">My Learning</h1>
        <p className="text-sm text-stone-500 dark:text-zinc-400">Track your progress and pick up where you left off.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          
          {/* Continue Learning */}
          <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm">
            <div className="border-b border-stone-200 dark:border-zinc-800 px-5 py-4 bg-stone-50/50 dark:bg-zinc-900/50">
              <h2 className="text-sm font-semibold text-stone-900 dark:text-white">Jump Back In</h2>
            </div>
            <div className="p-5">
              {(!sessions || sessions.length === 0) ? (
                <div className="text-center py-6">
                  <p className="text-sm text-stone-500 dark:text-zinc-400">No recent study sessions found.</p>
                  <button onClick={() => navigate('/workspace')} className="mt-3 text-indigo-600 font-medium text-sm">Start Studying</button>
                </div>
              ) : (
                <div className="flex items-center justify-between p-4 border border-indigo-100 dark:border-indigo-900/30 bg-indigo-50/50 dark:bg-indigo-900/10 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/50 rounded-lg flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                      <Play className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-0.5">Last Session</p>
                      <h3 className="font-bold text-stone-900 dark:text-white">
                        {subjects?.find(s => s.id === sessions[0].subjectId)?.name || 'General Study'}
                      </h3>
                      <p className="text-sm text-stone-500 dark:text-zinc-400">
                        {format(sessions[0].startTime, 'MMM d, h:mm a')} • {sessions[0].durationMinutes} mins
                      </p>
                    </div>
                  </div>
                  <button onClick={() => navigate('/workspace')} className="px-4 py-2 bg-indigo-600 text-white font-medium text-sm rounded-md shadow-sm hover:bg-indigo-700 transition-colors">
                    Continue
                  </button>
                </div>
              )}
            </div>
          </section>

          {/* Enrolled Subjects Table */}
          <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col">
            <div className="border-b border-stone-200 dark:border-zinc-800 px-5 py-4 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-stone-900 dark:text-white">Enrolled Subjects</h2>
              <button onClick={() => navigate('/curriculum')} className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline">Manage Curriculum</button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-stone-500 dark:text-zinc-400 uppercase bg-stone-50 dark:bg-zinc-900 border-b border-stone-200 dark:border-zinc-800">
                  <tr>
                    <th className="px-5 py-3 font-medium">Subject</th>
                    <th className="px-5 py-3 font-medium">Progress</th>
                    <th className="px-5 py-3 font-medium">Time Invested</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 dark:divide-zinc-800">
                  {(!subjects || subjects.length === 0) ? (
                    <tr>
                      <td colSpan={4} className="px-5 py-8 text-center text-stone-500">
                        No subjects enrolled.
                      </td>
                    </tr>
                  ) : (
                    subjects.map(sub => {
                      const subjectSessions = sessions?.filter(s => s.subjectId === sub.id) || [];
                      const totalMins = subjectSessions.reduce((acc, s) => acc + (s.durationMinutes || 0), 0);
                      
                      return (
                        <tr key={sub.id} className="hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors group cursor-pointer" onClick={() => navigate(`/curriculum?subjectId=${sub.id}`)}>
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: sub.color || '#94a3b8' }}></div>
                              <span className="font-semibold text-stone-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{sub.name}</span>
                            </div>
                          </td>
                          <td className="px-5 py-4 w-48">
                            <div className="flex items-center gap-2">
                              <div className="flex-1 h-1.5 bg-stone-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                                <div className="h-full rounded-full" style={{ width: '15%', backgroundColor: sub.color || '#94a3b8' }}></div>
                              </div>
                              <span className="text-xs text-stone-500">15%</span>
                            </div>
                          </td>
                          <td className="px-5 py-4 text-stone-500 dark:text-zinc-400">
                            {Math.floor(totalMins / 60)}h {totalMins % 60}m
                          </td>
                          <td className="px-5 py-4">
                            <span className="inline-flex items-center text-[10px] uppercase font-bold tracking-wider text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded">
                              Active
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        {/* Right Column */}
        <div className="flex flex-col gap-6">
          
          {/* Recent Resources */}
          <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm">
            <div className="border-b border-stone-200 dark:border-zinc-800 px-5 py-4">
              <h2 className="text-sm font-semibold text-stone-900 dark:text-white">Recently Accessed</h2>
            </div>
            <div className="p-4">
              {(!recentFiles || recentFiles.length === 0) ? (
                <div className="text-center py-4">
                  <p className="text-xs text-stone-500">No resources accessed yet.</p>
                </div>
              ) : (
                <ul className="space-y-3">
                  {recentFiles.map(file => (
                    <li key={file.id} className="flex items-start gap-3 group cursor-pointer" onClick={() => navigate('/workspace')}>
                      <div className="w-8 h-8 rounded bg-stone-100 dark:bg-zinc-800 flex items-center justify-center shrink-0">
                        {file.type === 'pdf' ? <FileText className="w-4 h-4 text-blue-500" /> : <Play className="w-4 h-4 text-rose-500" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-stone-900 dark:text-white group-hover:text-indigo-600 transition-colors line-clamp-1">{file.title}</p>
                        <p className="text-xs text-stone-500">{format(file.createdAt, 'MMM d')}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>

          {/* Pending Goals Summary */}
          <section className="bg-stone-100 dark:bg-zinc-900/50 border border-stone-200 dark:border-zinc-800 rounded-lg p-5">
            <h2 className="text-sm font-semibold text-stone-900 dark:text-white mb-4">Pending Learning Goals</h2>
            {(!goals || goals.length === 0) ? (
              <p className="text-sm text-stone-500">No pending goals.</p>
            ) : (
              <div className="space-y-3">
                {goals.slice(0,4).map(goal => (
                  <div key={goal.id} className="flex items-start gap-2 bg-white dark:bg-zinc-800 p-3 rounded shadow-sm border border-stone-100 dark:border-zinc-700">
                    <Target className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                    <p className="text-sm font-medium text-stone-800 dark:text-zinc-200">{goal.title}</p>
                  </div>
                ))}
              </div>
            )}
          </section>

        </div>
      </div>
    </div>
  );
}
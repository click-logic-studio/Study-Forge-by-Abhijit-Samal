import React, { useState, useEffect } from 'react';
import { db } from '@/db/db';
import { Play, Pause, RotateCcw, Volume2, VolumeX, CheckCircle2 } from 'lucide-react';
import { useUIStore } from '@/store/uiStore';

export function FocusRoom() {
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes default
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'pomodoro' | 'shortBreak' | 'longBreak'>('pomodoro');
  const [goal, setGoal] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(false);
  const { performanceMode } = useUIStore();

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(time => time - 1);
      }, 1000);
    } else if (isActive && timeLeft === 0) {
      handleComplete();
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const handleComplete = async () => {
    setIsActive(false);
    if (soundEnabled) {
      // Audio notification placeholder
    }
    if (mode === 'pomodoro') {
      await db.focusSessions.add({
        durationMinutes: 25,
        completedAt: Date.now()
      });
    }
  };

  const toggleTimer = () => setIsActive(!isActive);
  
  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'pomodoro' ? 25 * 60 : mode === 'shortBreak' ? 5 * 60 : 15 * 60);
  };

  const setTimerMode = (m: 'pomodoro' | 'shortBreak' | 'longBreak') => {
    setMode(m);
    setIsActive(false);
    setTimeLeft(m === 'pomodoro' ? 25 * 60 : m === 'shortBreak' ? 5 * 60 : 15 * 60);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'pomodoro' 
    ? ((25 * 60 - timeLeft) / (25 * 60)) * 100 
    : mode === 'shortBreak' 
      ? ((5 * 60 - timeLeft) / (5 * 60)) * 100 
      : ((15 * 60 - timeLeft) / (15 * 60)) * 100;

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-8rem)]">
      <div className="w-full max-w-2xl bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-3xl shadow-xl overflow-hidden">
        
        {/* Top bar */}
        <div className="flex justify-between items-center p-6 border-b border-stone-100 dark:border-zinc-800">
          <h2 className="text-xl font-bold text-stone-800 dark:text-zinc-200">Focus Room</h2>
          <button 
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 text-stone-400 hover:bg-stone-100 dark:hover:bg-zinc-800 rounded-full transition-colors"
            title={soundEnabled ? "Mute ambient sounds" : "Enable ambient sounds"}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>

        <div className="p-10 flex flex-col items-center">
          {/* Mode Selector */}
          <div className="flex bg-stone-100 dark:bg-zinc-800 p-1.5 rounded-full mb-12">
            {[
              { id: 'pomodoro', label: 'Pomodoro (25m)' },
              { id: 'shortBreak', label: 'Short Break (5m)' },
              { id: 'longBreak', label: 'Long Break (15m)' }
            ].map(m => (
              <button
                key={m.id}
                onClick={() => setTimerMode(m.id as any)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  mode === m.id 
                    ? 'bg-white dark:bg-zinc-700 text-stone-900 dark:text-white shadow-sm' 
                    : 'text-stone-500 hover:text-stone-700 dark:hover:text-stone-300'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* Timer Display */}
          <div className="relative flex items-center justify-center w-64 h-64 mb-10">
            {/* Minimalist Progress Ring */}
            <svg className="absolute w-full h-full transform -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="120"
                fill="none"
                stroke="currentColor"
                className="text-stone-100 dark:text-zinc-800"
                strokeWidth="6"
              />
              <circle
                cx="128"
                cy="128"
                r="120"
                fill="none"
                stroke="currentColor"
                className={`${mode === 'pomodoro' ? 'text-indigo-500' : 'text-emerald-500'} ${!performanceMode && 'transition-all duration-1000 ease-linear'}`}
                strokeWidth="6"
                strokeLinecap="round"
                strokeDasharray="753.98"
                strokeDashoffset={753.98 - (753.98 * progress) / 100}
              />
            </svg>
            <span className="text-6xl font-bold font-mono tracking-tighter text-stone-800 dark:text-zinc-100">
              {formatTime(timeLeft)}
            </span>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-6 mb-10">
            <button 
              onClick={toggleTimer}
              className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-lg transition-transform ${!performanceMode && 'hover:scale-105 active:scale-95'} ${
                isActive ? 'bg-stone-800 dark:bg-zinc-700' : mode === 'pomodoro' ? 'bg-indigo-600' : 'bg-emerald-600'
              }`}
            >
              {isActive ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8 ml-1" />}
            </button>
            <button 
              onClick={resetTimer}
              className="p-3 text-stone-400 hover:bg-stone-100 dark:hover:bg-zinc-800 rounded-full transition-colors"
              title="Reset Timer"
            >
              <RotateCcw className="w-6 h-6" />
            </button>
          </div>

          {/* Goal Input */}
          <div className="w-full max-w-sm">
            <input
              type="text"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              placeholder="What are you focusing on?"
              className="w-full bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-800 text-center px-4 py-3 rounded-xl text-stone-800 dark:text-zinc-200 placeholder-stone-400 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  PlaySquare, FileText, Plus, Maximize2, Minimize2, Settings2, 
  Layout, Video, X, RotateCcw, Volume2, VolumeX, FastForward, 
  FolderOpen, Bookmark, Clock, CheckCircle2, ChevronDown, Split
} from 'lucide-react';
import { PdfViewer } from '@/components/workspace/PdfViewer';
import { db, LibraryFile } from '@/db/db';
import { useLiveQuery } from 'dexie-react-hooks';
import { useUIStore } from '@/store/uiStore';
import { cn } from '@/lib/utils';

export function Workspace() {
  const { showToast } = useUIStore();
  
  // Persisted view mode and split ratio
  const [viewMode, setViewMode] = useState<'pdf' | 'video' | 'split'>(() => {
    return (localStorage.getItem('studyforge_workspace_mode') as 'pdf' | 'video' | 'split') || 'split';
  });
  
  const [splitRatio, setSplitRatio] = useState<number>(() => {
    const saved = localStorage.getItem('studyforge_workspace_splitRatio');
    return saved ? Math.max(20, Math.min(80, parseFloat(saved))) : 50;
  });

  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const workspaceContainerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Active files state
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [pdfName, setPdfName] = useState<string>('');
  const [videoName, setVideoName] = useState<string>('');

  // Drag and drop highlights
  const [pdfDragOver, setPdfDragOver] = useState(false);
  const [videoDragOver, setVideoDragOver] = useState(false);

  // Video playback controls
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [videoTime, setVideoTime] = useState<number>(0);
  const [videoDuration, setVideoDuration] = useState<number>(0);

  // Workspace Fullscreen
  const [isWorkspaceFullscreen, setIsWorkspaceFullscreen] = useState(false);

  // Library picker dropdown state
  const [showLibraryPicker, setShowLibraryPicker] = useState<'pdf' | 'video' | null>(null);

  // Study Session Tracker inside Workspace
  const [isTracking, setIsTracking] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [activeSubjectId, setActiveSubjectId] = useState<number>(0);
  const [sessionGoal, setSessionGoal] = useState<string>('');

  const subjects = useLiveQuery(() => db.subjects.toArray()) || [];
  const libraryFiles = useLiveQuery(() => db.library.toArray()) || [];

  const pdfLibraryFiles = libraryFiles.filter(f => f.type === 'pdf');
  const videoLibraryFiles = libraryFiles.filter(f => f.type === 'video');

  // Save layout preference
  useEffect(() => {
    localStorage.setItem('studyforge_workspace_mode', viewMode);
  }, [viewMode]);

  useEffect(() => {
    localStorage.setItem('studyforge_workspace_splitRatio', String(splitRatio));
  }, [splitRatio]);

  // Session timer
  useEffect(() => {
    let timer: any = null;
    if (isTracking) {
      timer = setInterval(() => {
        setSessionSeconds(s => s + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isTracking]);

  // Clean up object URLs on component unmount
  useEffect(() => {
    return () => {
      if (pdfUrl) {
        try { URL.revokeObjectURL(pdfUrl); } catch {}
      }
      if (videoUrl) {
        try { URL.revokeObjectURL(videoUrl); } catch {}
      }
    };
  }, [pdfUrl, videoUrl]);

  // Divider resize drag handler
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.max(20, Math.min(80, (x / rect.width) * 100));
      setSplitRatio(percentage);
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  // PDF Loaders
  const loadPdfFile = useCallback((file: File) => {
    if (!file.type.includes('pdf') && !file.name.toLowerCase().endsWith('.pdf')) {
      showToast('Selected file is not a valid PDF document.', 'error');
      return;
    }
    if (pdfUrl) {
      try { URL.revokeObjectURL(pdfUrl); } catch {}
    }
    const newUrl = URL.createObjectURL(file);
    setPdfUrl(newUrl);
    setPdfName(file.name);
    showToast(`Loaded ${file.name}`, 'info');
  }, [pdfUrl, showToast]);

  const loadPdfFromLibrary = (item: LibraryFile) => {
    if (!item.fileData) return;
    if (pdfUrl) {
      try { URL.revokeObjectURL(pdfUrl); } catch {}
    }
    const newUrl = URL.createObjectURL(item.fileData);
    setPdfUrl(newUrl);
    setPdfName(item.title);
    setShowLibraryPicker(null);
    showToast(`Loaded ${item.title} from Library`, 'info');
  };

  const handleClosePdf = () => {
    if (pdfUrl) {
      try { URL.revokeObjectURL(pdfUrl); } catch {}
    }
    setPdfUrl(null);
    setPdfName('');
    showToast('Closed PDF', 'info');
  };

  // Video Loaders
  const loadVideoFile = useCallback((file: File) => {
    if (!file.type.includes('video') && !file.name.match(/\.(mp4|webm|ogg|mov|mkv)$/i)) {
      showToast('Selected file is not a supported video file.', 'error');
      return;
    }
    if (videoUrl) {
      try { URL.revokeObjectURL(videoUrl); } catch {}
    }
    const newUrl = URL.createObjectURL(file);
    setVideoUrl(newUrl);
    setVideoName(file.name);
    showToast(`Loaded ${file.name}`, 'info');
  }, [videoUrl, showToast]);

  const loadVideoFromLibrary = (item: LibraryFile) => {
    if (!item.fileData) return;
    if (videoUrl) {
      try { URL.revokeObjectURL(videoUrl); } catch {}
    }
    const newUrl = URL.createObjectURL(item.fileData);
    setVideoUrl(newUrl);
    setVideoName(item.title);
    setShowLibraryPicker(null);
    showToast(`Loaded ${item.title} from Library`, 'info');
  };

  const handleCloseVideo = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.src = '';
    }
    if (videoUrl) {
      try { URL.revokeObjectURL(videoUrl); } catch {}
    }
    setVideoUrl(null);
    setVideoName('');
    showToast('Closed Video', 'info');
  };

  // Workspace Preset Helpers
  const applyPreset = (preset: 'balanced' | 'pdfFocus' | 'videoFocus') => {
    if (preset === 'balanced') {
      setViewMode('split');
      setSplitRatio(50);
    } else if (preset === 'pdfFocus') {
      setViewMode('split');
      setSplitRatio(70);
    } else if (preset === 'videoFocus') {
      setViewMode('split');
      setSplitRatio(30);
    }
  };

  const toggleWorkspaceFullscreen = () => {
    if (!workspaceContainerRef.current) return;
    if (!document.fullscreenElement) {
      workspaceContainerRef.current.requestFullscreen?.()
        .then(() => setIsWorkspaceFullscreen(true))
        .catch(() => {});
    } else {
      document.exitFullscreen?.()
        .then(() => setIsWorkspaceFullscreen(false))
        .catch(() => {});
    }
  };

  // Format Timer
  const formatTime = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div 
      ref={workspaceContainerRef} 
      className="flex flex-col h-full w-full max-w-[1900px] mx-auto animate-in fade-in duration-300 pb-2 select-none"
    >
      {/* Workspace Desktop Header Bar */}
      <header className="h-12 flex items-center justify-between gap-4 mb-2 shrink-0 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-lg px-3 shadow-sm">
        
        {/* Left: Mode Selection & Presets */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 border-r border-stone-200 dark:border-stone-800 pr-3">
            <div className="w-7 h-7 bg-indigo-100 dark:bg-indigo-950/60 rounded flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Layout className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="text-xs font-bold leading-none text-stone-900 dark:text-white">Workspace</div>
              <div className="text-[10px] text-stone-400">Offline Dual Station</div>
            </div>
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center bg-stone-100 dark:bg-stone-800/80 p-0.5 rounded-md border border-stone-200 dark:border-stone-700">
            <button 
              onClick={() => setViewMode('pdf')}
              className={cn(
                "px-2.5 py-1 text-xs font-medium rounded transition-all flex items-center gap-1.5", 
                viewMode === 'pdf' 
                  ? "bg-white dark:bg-stone-700 shadow-xs text-stone-900 dark:text-white font-semibold" 
                  : "text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white"
              )}
              title="PDF View Only"
            >
              <FileText className="w-3.5 h-3.5" /> PDF Only
            </button>
            <button 
              onClick={() => setViewMode('video')}
              className={cn(
                "px-2.5 py-1 text-xs font-medium rounded transition-all flex items-center gap-1.5", 
                viewMode === 'video' 
                  ? "bg-white dark:bg-stone-700 shadow-xs text-stone-900 dark:text-white font-semibold" 
                  : "text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white"
              )}
              title="Video View Only"
            >
              <Video className="w-3.5 h-3.5" /> Video Only
            </button>
            <button 
              onClick={() => setViewMode('split')}
              className={cn(
                "px-2.5 py-1 text-xs font-medium rounded transition-all flex items-center gap-1.5", 
                viewMode === 'split' 
                  ? "bg-white dark:bg-stone-700 shadow-xs text-stone-900 dark:text-white font-semibold" 
                  : "text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-white"
              )}
              title="Side-by-Side Split View"
            >
              <Split className="w-3.5 h-3.5" /> Split View
            </button>
          </div>

          {/* Presets when in split mode */}
          {viewMode === 'split' && (
            <div className="hidden lg:flex items-center gap-1 border-l border-stone-200 dark:border-stone-800 pl-3">
              <span className="text-[10px] text-stone-400 font-semibold uppercase tracking-wider mr-1">Ratio:</span>
              <button 
                onClick={() => applyPreset('pdfFocus')} 
                className={cn("px-2 py-0.5 text-[11px] rounded transition-colors", splitRatio === 70 ? "bg-stone-200 dark:bg-stone-700 font-semibold text-stone-900 dark:text-white" : "text-stone-500 hover:bg-stone-100 dark:hover:bg-stone-800")}
              >
                70/30 PDF
              </button>
              <button 
                onClick={() => applyPreset('balanced')} 
                className={cn("px-2 py-0.5 text-[11px] rounded transition-colors", splitRatio === 50 ? "bg-stone-200 dark:bg-stone-700 font-semibold text-stone-900 dark:text-white" : "text-stone-500 hover:bg-stone-100 dark:hover:bg-stone-800")}
              >
                50/50
              </button>
              <button 
                onClick={() => applyPreset('videoFocus')} 
                className={cn("px-2 py-0.5 text-[11px] rounded transition-colors", splitRatio === 30 ? "bg-stone-200 dark:bg-stone-700 font-semibold text-stone-900 dark:text-white" : "text-stone-500 hover:bg-stone-100 dark:hover:bg-stone-800")}
              >
                30/70 Video
              </button>
            </div>
          )}
        </div>

        {/* Right: Study Session Tracker & Workspace Fullscreen */}
        <div className="flex items-center gap-2">
          {/* Integrated Study Tracker */}
          <div className="flex items-center bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-md px-2.5 py-1 gap-2 text-xs">
            <Clock className={cn("w-3.5 h-3.5", isTracking ? "text-emerald-500 animate-pulse" : "text-stone-400")} />
            <span className="font-mono font-semibold text-stone-800 dark:text-stone-200">{formatTime(sessionSeconds)}</span>
            <button
              onClick={() => {
                if (isTracking) {
                  setIsTracking(false);
                  showToast(`Session paused at ${formatTime(sessionSeconds)}`, 'info');
                } else {
                  setIsTracking(true);
                  showToast('Study session tracking started', 'success');
                }
              }}
              className={cn(
                "px-2 py-0.5 text-[11px] font-semibold rounded transition-colors",
                isTracking 
                  ? "bg-amber-100 hover:bg-amber-200 text-amber-800 dark:bg-amber-950 dark:text-amber-300"
                  : "bg-emerald-600 hover:bg-emerald-700 text-white"
              )}
            >
              {isTracking ? 'Pause' : 'Start'}
            </button>
          </div>

          <button 
            onClick={toggleWorkspaceFullscreen}
            className="p-1.5 text-stone-500 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-stone-800 rounded transition-colors" 
            title="Toggle Entire Workspace Fullscreen"
          >
            {isWorkspaceFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <div 
        ref={containerRef} 
        className="flex-1 flex overflow-hidden rounded-lg border border-stone-200 dark:border-stone-800 bg-stone-100 dark:bg-stone-950 relative shadow-inner"
      >
        
        {/* PANEL 1: PDF DOCUMENT */}
        {(viewMode === 'pdf' || viewMode === 'split') && (
          <div 
            className="flex flex-col relative h-full bg-white dark:bg-stone-900 min-w-0"
            style={{ width: viewMode === 'split' ? `${splitRatio}%` : '100%' }}
            onDragOver={(e) => { e.preventDefault(); setPdfDragOver(true); }}
            onDragLeave={() => setPdfDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setPdfDragOver(false);
              const file = e.dataTransfer.files?.[0];
              if (file) loadPdfFile(file);
            }}
          >
            {/* Panel Top Header Bar */}
            <div className="h-9 flex items-center justify-between px-3 border-b border-stone-200 dark:border-stone-800 bg-stone-50/90 dark:bg-stone-900/90 shrink-0 z-10">
              <div className="flex items-center gap-2 min-w-0">
                <FileText className="w-4 h-4 text-indigo-500 shrink-0" />
                <span className="text-xs font-medium text-stone-700 dark:text-stone-300 truncate" title={pdfName}>
                  {pdfName || 'Document Reader (No PDF active)'}
                </span>
              </div>

              <div className="flex items-center gap-1 relative">
                {/* Pick from Library Button */}
                {pdfLibraryFiles.length > 0 && (
                  <button 
                    onClick={() => setShowLibraryPicker(showLibraryPicker === 'pdf' ? null : 'pdf')}
                    className="p-1 hover:bg-stone-200 dark:hover:bg-stone-800 rounded text-stone-600 dark:text-stone-400 text-xs flex items-center gap-1 transition-colors"
                    title="Open from Library"
                  >
                    <FolderOpen className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline text-[11px]">Library</span>
                  </button>
                )}

                {/* Local Windows File Picker */}
                <label 
                  className="cursor-pointer p-1 hover:bg-stone-200 dark:hover:bg-stone-800 rounded text-stone-600 dark:text-stone-400 text-xs flex items-center gap-1 transition-colors" 
                  title="Choose local PDF from disk"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline text-[11px]">Browse</span>
                  <input 
                    type="file" 
                    accept="application/pdf" 
                    className="hidden" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) loadPdfFile(file);
                    }} 
                  />
                </label>

                {pdfUrl && (
                  <button
                    onClick={handleClosePdf}
                    className="p-1 hover:bg-rose-100 dark:hover:bg-rose-950/40 text-stone-400 hover:text-rose-500 rounded transition-colors"
                    title="Close PDF"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Library Dropdown Popover */}
                {showLibraryPicker === 'pdf' && (
                  <div className="absolute top-8 right-0 w-64 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-lg shadow-xl p-2 z-50 text-xs">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-2 py-1 mb-1">
                      StudyForge PDF Library
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-1">
                      {pdfLibraryFiles.map(file => (
                        <button
                          key={file.id}
                          onClick={() => loadPdfFromLibrary(file)}
                          className="w-full text-left p-1.5 rounded hover:bg-stone-100 dark:hover:bg-stone-800 truncate text-stone-700 dark:text-stone-200 block"
                        >
                          {file.title}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Content View or Dropzone */}
            {!pdfUrl ? (
              <div 
                className={cn(
                  "flex-1 flex flex-col items-center justify-center p-6 text-center transition-colors",
                  pdfDragOver ? "bg-indigo-50/50 dark:bg-indigo-950/20 border-2 border-dashed border-indigo-400" : "bg-stone-50/40 dark:bg-stone-900/20"
                )}
              >
                <div className="w-14 h-14 rounded-2xl bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 flex items-center justify-center mb-3 shadow-xs">
                  <FileText className="w-7 h-7 text-indigo-500" />
                </div>
                <h3 className="text-sm font-semibold text-stone-900 dark:text-white mb-1">
                  Offline PDF Document Reader
                </h3>
                <p className="text-xs text-stone-500 dark:text-stone-400 mb-5 max-w-xs leading-relaxed">
                  Drag and drop a local textbook, paper, or syllabus PDF here, or select from your local drive.
                </p>
                
                <div className="flex items-center gap-2">
                  <label className="cursor-pointer bg-indigo-600 hover:bg-indigo-700 text-white transition-colors px-4 py-2 rounded-md text-xs font-semibold shadow-xs flex items-center gap-1.5">
                    <Plus className="w-3.5 h-3.5" /> Open Local PDF
                    <input 
                      type="file" 
                      accept="application/pdf" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) loadPdfFile(file);
                      }} 
                    />
                  </label>

                  {pdfLibraryFiles.length > 0 && (
                    <button
                      onClick={() => setShowLibraryPicker('pdf')}
                      className="border border-stone-300 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors px-3 py-2 rounded-md text-xs font-medium flex items-center gap-1.5"
                    >
                      <FolderOpen className="w-3.5 h-3.5" /> From Library ({pdfLibraryFiles.length})
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <PdfViewer 
                fileUrl={pdfUrl} 
                fileName={pdfName}
                onClose={handleClosePdf}
                onChooseAnotherFile={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'application/pdf';
                  input.onchange = (e: any) => {
                    const file = e.target?.files?.[0];
                    if (file) loadPdfFile(file);
                  };
                  input.click();
                }}
              />
            )}
          </div>
        )}

        {/* RESIZABLE DIVIDER (Split mode only) */}
        {viewMode === 'split' && (
          <div 
            className={cn(
              "w-2 bg-stone-200 dark:bg-stone-800 hover:bg-indigo-500 dark:hover:bg-indigo-500 cursor-col-resize transition-all z-20 flex flex-col justify-center items-center group shrink-0 select-none",
              isDragging && "bg-indigo-600 dark:bg-indigo-600 w-2.5"
            )}
            onMouseDown={() => setIsDragging(true)}
            title="Drag to resize panels"
          >
            <div className="w-1 h-8 bg-stone-400 dark:bg-stone-600 rounded-full group-hover:bg-white transition-colors" />
          </div>
        )}

        {/* PANEL 2: VIDEO LECTURE */}
        {(viewMode === 'video' || viewMode === 'split') && (
          <div 
            className="flex flex-col relative h-full bg-stone-950 min-w-0"
            style={{ width: viewMode === 'split' ? `${100 - splitRatio}%` : '100%' }}
            onDragOver={(e) => { e.preventDefault(); setVideoDragOver(true); }}
            onDragLeave={() => setVideoDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setVideoDragOver(false);
              const file = e.dataTransfer.files?.[0];
              if (file) loadVideoFile(file);
            }}
          >
            {/* Video Top Header Bar */}
            <div className="h-9 flex items-center justify-between px-3 border-b border-stone-800 bg-stone-900/90 shrink-0 z-10 text-stone-200">
              <div className="flex items-center gap-2 min-w-0">
                <Video className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="text-xs font-medium truncate" title={videoName}>
                  {videoName || 'Offline Media Player (No video active)'}
                </span>
              </div>

              <div className="flex items-center gap-1 relative">
                {videoLibraryFiles.length > 0 && (
                  <button 
                    onClick={() => setShowLibraryPicker(showLibraryPicker === 'video' ? null : 'video')}
                    className="p-1 hover:bg-stone-800 rounded text-stone-300 text-xs flex items-center gap-1 transition-colors"
                    title="Open from Video Library"
                  >
                    <FolderOpen className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline text-[11px]">Library</span>
                  </button>
                )}

                <label 
                  className="cursor-pointer p-1 hover:bg-stone-800 rounded text-stone-300 text-xs flex items-center gap-1 transition-colors" 
                  title="Choose local video file from disk"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline text-[11px]">Browse</span>
                  <input 
                    type="file" 
                    accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-matroska" 
                    className="hidden" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) loadVideoFile(file);
                    }} 
                  />
                </label>

                {videoUrl && (
                  <button
                    onClick={handleCloseVideo}
                    className="p-1 hover:bg-rose-950/60 text-stone-400 hover:text-rose-400 rounded transition-colors"
                    title="Close Video"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}

                {/* Video Library Dropdown */}
                {showLibraryPicker === 'video' && (
                  <div className="absolute top-8 right-0 w-64 bg-stone-900 border border-stone-800 rounded-lg shadow-xl p-2 z-50 text-xs text-stone-100">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 px-2 py-1 mb-1">
                      StudyForge Video Library
                    </div>
                    <div className="max-h-48 overflow-y-auto space-y-1">
                      {videoLibraryFiles.map(file => (
                        <button
                          key={file.id}
                          onClick={() => loadVideoFromLibrary(file)}
                          className="w-full text-left p-1.5 rounded hover:bg-stone-800 truncate text-stone-200 block"
                        >
                          {file.title}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Video View or Dropzone */}
            {!videoUrl ? (
              <div 
                className={cn(
                  "flex-1 flex flex-col items-center justify-center p-6 text-center transition-colors",
                  videoDragOver ? "bg-rose-950/20 border-2 border-dashed border-rose-500" : "bg-stone-950"
                )}
              >
                <div className="w-14 h-14 rounded-2xl bg-stone-900 border border-stone-800 flex items-center justify-center mb-3 shadow-xs">
                  <PlaySquare className="w-7 h-7 text-rose-500" />
                </div>
                <h3 className="text-sm font-semibold text-stone-200 mb-1">
                  Local Video Player
                </h3>
                <p className="text-xs text-stone-400 mb-5 max-w-xs leading-relaxed">
                  Drag and drop a recorded lecture or educational video, or select a file from your computer.
                </p>

                <div className="flex items-center gap-2">
                  <label className="cursor-pointer bg-rose-600 hover:bg-rose-700 text-white transition-colors px-4 py-2 rounded-md text-xs font-semibold shadow-xs flex items-center gap-1.5">
                    <Plus className="w-3.5 h-3.5" /> Open Local Video
                    <input 
                      type="file" 
                      accept="video/mp4,video/webm,video/ogg,video/quicktime,video/x-matroska" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) loadVideoFile(file);
                      }} 
                    />
                  </label>

                  {videoLibraryFiles.length > 0 && (
                    <button
                      onClick={() => setShowLibraryPicker('video')}
                      className="border border-stone-700 hover:bg-stone-800 text-stone-300 transition-colors px-3 py-2 rounded-md text-xs font-medium flex items-center gap-1.5"
                    >
                      <FolderOpen className="w-3.5 h-3.5" /> From Library ({videoLibraryFiles.length})
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex-1 relative bg-black flex flex-col justify-between overflow-hidden">
                <video 
                  ref={videoRef}
                  src={videoUrl} 
                  controls 
                  playsInline
                  className="w-full h-full object-contain"
                  onTimeUpdate={() => {
                    if (videoRef.current) {
                      setVideoTime(videoRef.current.currentTime);
                      setVideoDuration(videoRef.current.duration || 0);
                    }
                  }}
                />

                {/* Floating Speed Bar */}
                <div className="absolute bottom-16 right-4 bg-stone-900/80 backdrop-blur border border-stone-800 rounded-lg p-1 flex items-center gap-1 text-[11px] text-stone-300 z-10 shadow-lg">
                  <span className="text-[10px] text-stone-400 px-1 font-semibold">Speed:</span>
                  {[0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => {
                        setPlaybackRate(rate);
                        if (videoRef.current) videoRef.current.playbackRate = rate;
                      }}
                      className={cn(
                        "px-1.5 py-0.5 rounded transition-colors font-mono",
                        playbackRate === rate ? "bg-rose-600 text-white font-bold" : "hover:bg-stone-800"
                      )}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
}

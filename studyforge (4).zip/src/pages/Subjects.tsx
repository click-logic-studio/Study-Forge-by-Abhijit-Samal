import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { useUIStore } from '@/store/uiStore';
import { Plus, Folder, Trash2, Edit3, X } from 'lucide-react';

export function Subjects() {
  const askConfirmation = useUIStore((state) => state.askConfirmation);
  const showToast = useUIStore((state) => state.showToast);
  const subjects = useLiveQuery(() => db.subjects.toArray());
  const [isAdding, setIsAdding] = useState(false);
  const [newSubject, setNewSubject] = useState({ name: '', color: '#4f46e5' });

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.name.trim()) return;
    
    await db.subjects.add({
      name: newSubject.name,
      color: newSubject.color,
      icon: 'Folder',
      createdAt: Date.now()
    });
    setNewSubject({ name: '', color: '#4f46e5' });
    setIsAdding(false);
    showToast('Subject created successfully.', 'success');
  };

  const handleDelete = (id: number) => {
    askConfirmation({
      title: 'Delete Subject',
      message: 'Delete this subject? This will not delete associated notes or tasks.',
      confirmLabel: 'Delete',
      isDestructive: true,
      onConfirm: async () => {
        await db.subjects.delete(id);
        showToast('Subject deleted.', 'info');
      }
    });
  };

  const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4', '#3b82f6', '#4f46e5', '#a855f7', '#ec4899', '#64748b'];

  return (
    <div className="max-w-5xl mx-auto w-full">
      <header className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-stone-900 dark:text-zinc-100">Subjects</h1>
          <p className="text-stone-500 dark:text-zinc-400 mt-1">Organize your academic materials.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" /> New Subject
        </button>
      </header>

      {isAdding && (
        <form onSubmit={handleAdd} className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl p-6 mb-8 shadow-sm flex flex-col gap-4">
          <div className="flex justify-between items-center mb-2">
            <h2 className="font-semibold text-lg">Add New Subject</h2>
            <button type="button" onClick={() => setIsAdding(false)} className="text-stone-400 hover:text-stone-600">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-1">Subject Name</label>
            <input 
              type="text" 
              value={newSubject.name}
              onChange={e => setNewSubject({ ...newSubject, name: e.target.value })}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-300 dark:border-zinc-700 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
              placeholder="e.g. Advanced Calculus"
              autoFocus
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Subject Color</label>
            <div className="flex flex-wrap gap-3">
              {colors.map(c => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setNewSubject({ ...newSubject, color: c })}
                  className={`w-8 h-8 rounded-full transition-all ${newSubject.color === c ? 'ring-2 ring-offset-2 ring-stone-400 dark:ring-offset-zinc-900 scale-110' : 'hover:scale-110'}`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>
          
          <div className="flex justify-end mt-2">
            <button type="submit" disabled={!newSubject.name.trim()} className="bg-stone-900 dark:bg-white text-white dark:text-stone-900 px-6 py-2 rounded-lg font-medium disabled:opacity-50">
              Save Subject
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {subjects?.length === 0 && !isAdding ? (
          <div className="col-span-full text-center py-12 text-stone-500">
            No subjects created yet. Click 'New Subject' to get started.
          </div>
        ) : (
          subjects?.map(sub => (
            <div key={sub.id} className="group bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm hover:shadow-md transition-all relative overflow-hidden">
              {/* Top Accent Line */}
              <div className="absolute top-0 left-0 w-full h-1" style={{ backgroundColor: sub.color }} />
              
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 rounded-xl bg-stone-50 dark:bg-zinc-800/50" style={{ color: sub.color }}>
                  <Folder className="w-6 h-6" />
                </div>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => handleDelete(sub.id as number)} className="p-1.5 text-stone-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/30 rounded-lg">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              
              <h3 className="font-bold text-lg text-stone-900 dark:text-zinc-100 mb-1 truncate">{sub.name}</h3>
              <p className="text-sm text-stone-500 dark:text-zinc-400">0 Resources</p>
              
              <div className="mt-6 flex gap-2">
                <button className="flex-1 py-1.5 text-xs font-medium text-stone-600 bg-stone-100 hover:bg-stone-200 dark:text-zinc-300 dark:bg-zinc-800 dark:hover:bg-zinc-700 rounded-md transition-colors">
                  Open
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

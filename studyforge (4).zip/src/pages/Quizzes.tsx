import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, QuizAttempt } from '@/db/db';
import { 
  Award, CheckCircle2, XCircle, Clock, Play, 
  RotateCcw, Sparkles, Filter, ChevronRight, HelpCircle, 
  BookOpen, Trophy
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface QuizBank {
  id: string;
  title: string;
  subject: string;
  durationMinutes: number;
  questions: Question[];
}

const QUIZ_BANKS: QuizBank[] = [
  {
    id: 'phy-light',
    title: 'Light – Reflection and Refraction Mastery',
    subject: 'Physics',
    durationMinutes: 10,
    questions: [
      {
        id: 1,
        question: 'An object is placed at 20 cm in front of a concave mirror of focal length 10 cm. The image formed is:',
        options: [
          'Real, inverted, and same size as object',
          'Virtual, erect, and magnified',
          'Real, inverted, and diminished',
          'Real, inverted, and highly enlarged'
        ],
        correctAnswer: 0,
        explanation: 'Since the object is at 20 cm and f = 10 cm, the object is placed at the center of curvature (C = 2f = 20 cm). At C, a concave mirror forms a real, inverted image of the same size at C.'
      },
      {
        id: 2,
        question: 'The power of a lens having focal length -50 cm is:',
        options: ['+2.0 D', '-2.0 D', '+0.5 D', '-0.5 D'],
        correctAnswer: 1,
        explanation: 'P = 1 / f(in metres). Here f = -50 cm = -0.5 m. Therefore P = 1 / (-0.5) = -2.0 D (Concave lens).'
      },
      {
        id: 3,
        question: 'Under which condition does a ray of light passing from one medium to another NOT bend?',
        options: [
          'When angle of incidence is 45°',
          'When it strikes normal to the interface (i = 0°)',
          'When light enters a optically denser medium',
          'When light enters an optically rarer medium'
        ],
        correctAnswer: 1,
        explanation: 'When incident ray is perpendicular to the boundary (i = 0°), angle of refraction is also 0°, and light proceeds without bending.'
      }
    ]
  },
  {
    id: 'phy-elec',
    title: 'Electricity & Circuits Assessment',
    subject: 'Physics',
    durationMinutes: 8,
    questions: [
      {
        id: 1,
        question: 'A wire of resistance R is cut into five equal pieces. These pieces are then connected in parallel. If the equivalent resistance is R\', the ratio R/R\' is:',
        options: ['1/25', '1/5', '5', '25'],
        correctAnswer: 3,
        explanation: 'Each piece has resistance R/5. When 5 such pieces are in parallel: 1/R\' = 5 / (R/5) = 25/R => R\' = R/25. Thus R/R\' = 25.'
      },
      {
        id: 2,
        question: 'According to Joule\'s law of heating, heat produced in a resistor is proportional to:',
        options: [
          'Square of the current (I²)',
          'Inverse of resistance (1/R)',
          'Inverse of time (1/t)',
          'Square root of current (√I)'
        ],
        correctAnswer: 0,
        explanation: 'H = I²Rt. Heat produced is directly proportional to the square of current flowing through the resistor.'
      }
    ]
  },
  {
    id: 'che-reactions',
    title: 'Chemical Reactions & Equations',
    subject: 'Chemistry',
    durationMinutes: 10,
    questions: [
      {
        id: 1,
        question: 'When aqueous solutions of barium chloride and sodium sulphate react, what precipitate is formed?',
        options: [
          'Sodium chloride (NaCl)',
          'Barium sulphate (BaSO₄)',
          'Barium sulphide (BaS)',
          'Sodium oxide (Na₂O)'
        ],
        correctAnswer: 1,
        explanation: 'BaCl₂(aq) + Na₂SO₄(aq) → BaSO₄(s)↓ + 2NaCl(aq). A white precipitate of barium sulphate is formed via double displacement.'
      },
      {
        id: 2,
        question: 'The reaction of calcium oxide (quick lime) with water to form calcium hydroxide (slaked lime) is an example of:',
        options: [
          'Endothermic combination reaction',
          'Exothermic combination reaction',
          'Decomposition reaction',
          'Displacement reaction'
        ],
        correctAnswer: 1,
        explanation: 'CaO(s) + H₂O(l) → Ca(OH)₂(aq) + Heat. Two reactants combine to form a single product with massive heat release (exothermic).'
      }
    ]
  }
];

export function Quizzes() {
  const attempts = useLiveQuery(() => db.quizAttempts.toArray()) || [];
  
  // Active Quiz State
  const [activeQuiz, setActiveQuiz] = useState<QuizBank | null>(null);
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizFinished, setQuizFinished] = useState<boolean>(false);
  const [startTime, setStartTime] = useState<number>(0);

  const startQuiz = (bank: QuizBank) => {
    setActiveQuiz(bank);
    setCurrentQIndex(0);
    setSelectedAnswers({});
    setQuizFinished(false);
    setStartTime(Date.now());
  };

  const handleSelectOption = (optionIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [currentQIndex]: optionIndex
    }));
  };

  const finishQuiz = async () => {
    if (!activeQuiz) return;

    let score = 0;
    activeQuiz.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswer) {
        score++;
      }
    });

    const total = activeQuiz.questions.length;
    const percentage = Math.round((score / total) * 100);
    const durationSec = Math.round((Date.now() - startTime) / 1000);

    await db.quizAttempts.add({
      quizTitle: activeQuiz.title,
      score,
      totalQuestions: total,
      percentage,
      completedAt: Date.now(),
      timeSpentSeconds: durationSec,
      topic: activeQuiz.subject
    });

    setQuizFinished(true);
  };

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-300 pb-10">
      
      {/* Page Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white flex items-center gap-2.5">
            <Award className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>Assessments & Quizzes</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            Curriculum-aligned NCERT Class 10 timed assessments with instant rationale breakdown.
          </p>
        </div>
      </header>

      {/* QUIZ RUNNER VIEW */}
      {activeQuiz && !quizFinished && (
        <div className="max-w-3xl mx-auto w-full bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between border-b border-stone-100 dark:border-zinc-800 pb-4">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                {activeQuiz.subject} · Assessment In Progress
              </span>
              <h2 className="text-lg font-bold text-stone-900 dark:text-white mt-0.5">{activeQuiz.title}</h2>
            </div>
            <div className="px-3 py-1 bg-stone-100 dark:bg-zinc-800 rounded-full font-mono text-xs font-semibold text-stone-700 dark:text-zinc-300">
              Q {currentQIndex + 1} of {activeQuiz.questions.length}
            </div>
          </div>

          {/* Current Question */}
          <div className="space-y-4">
            <h3 className="text-base font-semibold text-stone-900 dark:text-white leading-relaxed">
              {activeQuiz.questions[currentQIndex].question}
            </h3>

            <div className="space-y-2.5 pt-2">
              {activeQuiz.questions[currentQIndex].options.map((opt, idx) => {
                const isSelected = selectedAnswers[currentQIndex] === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => handleSelectOption(idx)}
                    className={cn(
                      "w-full text-left p-4 rounded-xl border text-xs sm:text-sm transition-all flex items-center gap-3",
                      isSelected 
                        ? "border-indigo-600 bg-indigo-50/60 dark:bg-indigo-950/40 text-stone-900 dark:text-white ring-1 ring-indigo-500" 
                        : "border-stone-200 dark:border-zinc-800 hover:bg-stone-50 dark:hover:bg-zinc-800/40 text-stone-700 dark:text-zinc-300"
                    )}
                  >
                    <div className={cn(
                      "w-6 h-6 rounded-full border flex items-center justify-center text-xs font-bold shrink-0 font-mono",
                      isSelected 
                        ? "border-indigo-600 bg-indigo-600 text-white" 
                        : "border-stone-300 dark:border-zinc-700 text-stone-500"
                    )}>
                      {String.fromCharCode(65 + idx)}
                    </div>
                    <span className="font-medium leading-relaxed">{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-stone-100 dark:border-zinc-800">
            <button
              onClick={() => setCurrentQIndex(prev => Math.max(0, prev - 1))}
              disabled={currentQIndex === 0}
              className="px-4 py-2 text-xs font-medium text-stone-600 dark:text-zinc-400 disabled:opacity-30 hover:text-stone-900"
            >
              Previous
            </button>

            {currentQIndex < activeQuiz.questions.length - 1 ? (
              <button
                onClick={() => setCurrentQIndex(prev => prev + 1)}
                className="px-5 py-2 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md text-xs font-semibold hover:opacity-90"
              >
                Next Question
              </button>
            ) : (
              <button
                onClick={finishQuiz}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-semibold shadow-sm"
              >
                Submit Assessment
              </button>
            )}
          </div>
        </div>
      )}

      {/* QUIZ RESULTS VIEW */}
      {activeQuiz && quizFinished && (
        <div className="max-w-3xl mx-auto w-full bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-6 sm:p-8 space-y-6 animate-in fade-in">
          <div className="text-center space-y-2 pb-4 border-b border-stone-100 dark:border-zinc-800">
            <div className="w-14 h-14 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-2xl flex items-center justify-center mx-auto mb-2">
              <Trophy className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold text-stone-900 dark:text-white">Assessment Submitted</h2>
            <p className="text-xs text-stone-500">Your score and verified explanation review</p>
          </div>

          {/* Explanations List */}
          <div className="space-y-4">
            {activeQuiz.questions.map((q, idx) => {
              const selected = selectedAnswers[idx];
              const isCorrect = selected === q.correctAnswer;
              return (
                <div key={idx} className="p-4 rounded-xl border border-stone-200 dark:border-zinc-800 bg-stone-50/50 dark:bg-zinc-800/20 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-semibold text-xs text-stone-900 dark:text-white">
                      Q{idx + 1}. {q.question}
                    </span>
                    {isCorrect ? (
                      <span className="px-2 py-0.5 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 rounded text-[10px] font-bold shrink-0">Correct</span>
                    ) : (
                      <span className="px-2 py-0.5 bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-400 rounded text-[10px] font-bold shrink-0">Incorrect</span>
                    )}
                  </div>
                  <div className="text-xs text-stone-600 dark:text-zinc-300 font-medium">
                    Correct Answer: <span className="font-bold text-emerald-600">{q.options[q.correctAnswer]}</span>
                  </div>
                  <p className="text-[11px] text-stone-500 dark:text-zinc-400 italic pt-1 border-t border-stone-200/50 dark:border-zinc-800">
                    Rationale: {q.explanation}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={() => setActiveQuiz(null)}
              className="px-5 py-2 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md text-xs font-semibold hover:opacity-90"
            >
              Return to Assessments List
            </button>
          </div>
        </div>
      )}

      {/* CATALOG & PAST ATTEMPTS VIEW */}
      {!activeQuiz && (
        <div className="space-y-8">
          
          {/* Active Available Quizzes */}
          <div>
            <h2 className="text-base font-bold text-stone-900 dark:text-white mb-4">Official Curriculum Assessments</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {QUIZ_BANKS.map((b) => (
                <div 
                  key={b.id} 
                  className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl p-5 shadow-sm flex flex-col justify-between space-y-4 hover:border-indigo-400 dark:hover:border-indigo-600 transition-colors"
                >
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                      {b.subject}
                    </span>
                    <h3 className="font-bold text-sm text-stone-900 dark:text-white mt-1">{b.title}</h3>
                    <div className="flex items-center gap-3 text-stone-400 text-xs mt-2">
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3.5 h-3.5" />
                        {b.durationMinutes} mins
                      </span>
                      <span>·</span>
                      <span className="font-mono">{b.questions.length} questions</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => startQuiz(b)}
                    className="w-full py-2 bg-stone-900 dark:bg-white hover:bg-stone-800 text-white dark:text-stone-900 rounded-md text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Begin Quiz</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Past Assessment Attempts Table (Requirement 50: Zero Fake Data, Empty means Empty) */}
          <div>
            <h2 className="text-base font-bold text-stone-900 dark:text-white mb-4">Past Assessment Ledger</h2>
            
            {attempts.length === 0 ? (
              <div className="p-10 border border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 rounded-2xl text-center space-y-2">
                <HelpCircle className="w-8 h-8 text-stone-300 dark:text-zinc-700 mx-auto mb-1" />
                <h3 className="text-sm font-semibold text-stone-800 dark:text-zinc-200">No Assessment Records Yet</h3>
                <p className="text-xs text-stone-500 max-w-sm mx-auto">
                  Take one of the curriculum assessments above. Your scores and completion history will be logged here.
                </p>
              </div>
            ) : (
              <div className="border border-stone-200 dark:border-zinc-800 rounded-2xl bg-white dark:bg-zinc-900 overflow-hidden shadow-sm">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 dark:bg-zinc-800/60 border-b border-stone-200 dark:border-zinc-800 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                    <tr>
                      <th className="p-3.5">Assessment</th>
                      <th className="p-3.5">Subject</th>
                      <th className="p-3.5">Date</th>
                      <th className="p-3.5 text-center">Score</th>
                      <th className="p-3.5 text-right">Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-zinc-800 font-mono">
                    {attempts.map((att, i) => (
                      <tr key={i} className="hover:bg-stone-50/50 dark:hover:bg-zinc-800/30">
                        <td className="p-3.5 font-sans font-semibold text-stone-900 dark:text-white">{att.quizTitle}</td>
                        <td className="p-3.5 font-sans text-stone-500">{att.topic || 'General'}</td>
                        <td className="p-3.5 text-stone-500">{new Date(att.completedAt).toLocaleDateString()}</td>
                        <td className="p-3.5 text-center font-bold text-stone-900 dark:text-white">
                          {att.score} / {att.totalQuestions}
                        </td>
                        <td className="p-3.5 text-right font-sans">
                          <span className={cn(
                            "px-2 py-0.5 rounded text-[11px] font-bold",
                            att.percentage >= 70 ? "bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700" : "bg-amber-100 dark:bg-amber-950/40 text-amber-700"
                          )}>
                            {att.percentage}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}

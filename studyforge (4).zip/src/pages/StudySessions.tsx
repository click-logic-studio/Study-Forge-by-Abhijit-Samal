import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { 
  Play, Clock, Calendar, CheckCircle2, 
  Search, Filter, Plus, ArrowRight, Target
} from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

export function StudySessions() {
  const navigate = useNavigate();
  const sessions = useLiveQuery(() => db.studySessions.orderBy('startTime').reverse().toArray());
  const subjects = useLiveQuery(() => db.subjects.toArray());
  
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-500">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Study Sessions</h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400 mt-1">
            Log your focused study time, track topics covered, and maintain your learning streaks.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => navigate('/workspace')}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium shadow-sm hover:bg-indigo-700 transition-colors"
          >
            <Play className="w-4 h-4" /> Start New Session
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4 shrink-0">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input 
            type="text" 
            placeholder="Search sessions..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md text-sm text-stone-900 dark:text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          />
        </div>
        <button className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md text-sm text-stone-700 dark:text-zinc-300 hover:bg-stone-50 dark:hover:bg-zinc-800 transition-colors">
          <Filter className="w-4 h-4" /> Filter
        </button>
      </div>

      {/* Data Table Area */}
      <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex-1 min-h-0 flex flex-col overflow-hidden">
        
        {/* Table Header */}
        <div className="grid grid-cols-[150px_1fr_120px_150px_120px] gap-4 px-5 py-3 border-b border-stone-200 dark:border-zinc-800 bg-stone-50/80 dark:bg-zinc-900/80 text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider shrink-0">
          <div>Date & Time</div>
          <div>Subject / Topic</div>
          <div>Duration</div>
          <div>Status</div>
          <div className="text-right">Actions</div>
        </div>

        {/* Table Body */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {(!sessions || sessions.length === 0) ? (
            <div className="flex flex-col items-center justify-center h-full text-stone-500 dark:text-zinc-400 py-12">
              <Clock className="w-12 h-12 mb-4 text-stone-300 dark:text-zinc-700" />
              <p className="text-sm font-medium text-stone-900 dark:text-white mb-1">No sessions recorded</p>
              <p className="text-xs">Start your first study session to begin tracking time.</p>
              <button 
                onClick={() => navigate('/workspace')}
                className="mt-4 px-4 py-2 bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400 rounded-md text-sm font-medium hover:bg-indigo-100 dark:hover:bg-indigo-900/50 transition-colors"
              >
                Launch Workspace
              </button>
            </div>
          ) : (
            <div className="divide-y divide-stone-100 dark:divide-zinc-800/50">
              {sessions.map(session => {
                const subject = subjects?.find(s => s.id === session.subjectId);
                const isOngoing = !session.endTime;
                
                return (
                  <div key={session.id} className="grid grid-cols-[150px_1fr_120px_150px_120px] gap-4 px-5 py-4 items-center group hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors bg-white dark:bg-zinc-900">
                    
                    <div className="flex flex-col gap-0.5">
                      <span className="text-sm font-medium text-stone-900 dark:text-white">{format(session.startTime, 'MMM d, yyyy')}</span>
                      <span className="text-xs text-stone-500 dark:text-zinc-400">{format(session.startTime, 'h:mm a')}</span>
                    </div>
                    
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: subject?.color || '#94a3b8' }} />
                      <div className="flex flex-col min-w-0">
                        <span className="font-medium text-sm text-stone-900 dark:text-white truncate">{subject?.name || 'General Study'}</span>
                        {session.topic && <span className="text-xs text-stone-500 truncate">{session.topic}</span>}
                      </div>
                    </div>
                    
                    <div className="text-sm text-stone-700 dark:text-zinc-300">
                      {isOngoing ? (
                        <span className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 font-medium">
                          <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></div> Active
                        </span>
                      ) : (
                        `${Math.floor(session.durationMinutes / 60)}h ${session.durationMinutes % 60}m`
                      )}
                    </div>
                    
                    <div>
                      {isOngoing ? (
                        <span className="inline-flex items-center text-[10px] uppercase font-bold tracking-wider text-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 px-2 py-0.5 rounded border border-indigo-100 dark:border-indigo-800/30">
                          In Progress
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-[10px] uppercase font-bold tracking-wider text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 px-2 py-0.5 rounded border border-emerald-100 dark:border-emerald-800/30">
                          Completed
                        </span>
                      )}
                    </div>
                    
                    <div className="text-right flex items-center justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                      {isOngoing ? (
                        <button onClick={() => navigate('/workspace')} className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                          Resume <ArrowRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <button className="text-xs font-medium text-stone-500 hover:text-stone-900 dark:hover:text-white transition-colors">
                          View Details
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, Chapter, WeakTopic } from '@/db/db';
import { 
  RefreshCw, CheckCircle2, AlertCircle, Plus, 
  Trash2, BookOpen, Star, HelpCircle, ArrowRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

export function Revision() {
  const navigate = useNavigate();
  const subjects = useLiveQuery(() => db.subjects.toArray()) || [];
  const chapters = useLiveQuery(() => db.chapters.toArray()) || [];
  const weakTopics = useLiveQuery(() => db.weakTopics.toArray()) || [];
  const flashcards = useLiveQuery(() => db.flashcards.toArray()) || [];

  const [selectedSubjectId, setSelectedSubjectId] = useState<number | 'all'>('all');
  const [showAddWeakTopic, setShowAddWeakTopic] = useState(false);
  const [newTopicSubjectId, setNewTopicSubjectId] = useState<number>(0);
  const [newTopicChapter, setNewTopicChapter] = useState('');
  const [newTopicTitle, setNewTopicTitle] = useState('');
  const [newTopicSeverity, setNewTopicSeverity] = useState<'low' | 'medium' | 'high'>('medium');

  // Handle Confidence Level Update for Chapter
  const handleUpdateConfidence = async (chapterId: number, level: number) => {
    await db.chapters.update(chapterId, { confidenceLevel: level });
  };

  // Add Weak Topic
  const handleCreateWeakTopic = async () => {
    if (!newTopicTitle.trim()) return;
    const subId = newTopicSubjectId || (subjects[0]?.id as number);
    await db.weakTopics.add({
      subjectId: subId,
      chapterName: newTopicChapter.trim() || 'General',
      topicName: newTopicTitle.trim(),
      severity: newTopicSeverity,
      resolved: false,
      createdAt: Date.now()
    });
    setNewTopicTitle('');
    setNewTopicChapter('');
    setShowAddWeakTopic(false);
  };

  const handleToggleResolveWeakTopic = async (id: number, current: boolean) => {
    await db.weakTopics.update(id, { resolved: !current });
  };

  const handleDeleteWeakTopic = async (id: number) => {
    await db.weakTopics.delete(id);
  };

  const filteredChapters = chapters.filter(c => selectedSubjectId === 'all' || c.subjectId === selectedSubjectId);
  const filteredWeakTopics = weakTopics.filter(w => selectedSubjectId === 'all' || w.subjectId === selectedSubjectId);

  // Compute Overall Subject Confidence from Real Chapter Data
  const getSubjectConfidence = (subId: number): number => {
    const subChapters = chapters.filter(c => c.subjectId === subId);
    if (subChapters.length === 0) return 0;
    const totalScore = subChapters.reduce((acc, c) => acc + (c.confidenceLevel || 3), 0);
    return Math.round((totalScore / (subChapters.length * 5)) * 100);
  };

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-300 pb-12">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white flex items-center gap-2.5">
            <RefreshCw className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>Revision & Spaced Mastery</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            Empirical confidence tracking, active recall schedules, and targeted weak-point intervention.
          </p>
        </div>

        {/* Subject Filter Switcher */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
          <button
            onClick={() => setSelectedSubjectId('all')}
            className={cn(
              "px-3 py-1.5 rounded-md font-semibold transition-colors",
              selectedSubjectId === 'all' 
                ? "bg-indigo-600 text-white" 
                : "bg-white dark:bg-zinc-800 text-stone-600 dark:text-zinc-300 border border-stone-200 dark:border-zinc-700"
            )}
          >
            All Subjects
          </button>
          {subjects.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedSubjectId(s.id as number)}
              className={cn(
                "px-3 py-1.5 rounded-md font-semibold transition-colors truncate max-w-[140px]",
                selectedSubjectId === s.id 
                  ? "bg-indigo-600 text-white" 
                  : "bg-white dark:bg-zinc-800 text-stone-600 dark:text-zinc-300 border border-stone-200 dark:border-zinc-700"
              )}
            >
              {s.name.split(' (')[0]}
            </button>
          ))}
        </div>
      </header>

      {/* Main Grid: Subject Readiness + Chapter Confidence Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Chapter Confidence Matrix */}
        <div className="lg:col-span-2 space-y-6">
          
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-stone-900 dark:text-white">Curriculum Confidence Matrix</h2>
                <p className="text-[11px] text-stone-500">Rate your mastery from 1 to 5 to dynamically prioritize spaced recall sessions.</p>
              </div>
            </div>

            {filteredChapters.length === 0 ? (
              <div className="p-8 text-center text-xs text-stone-400">
                No chapters found. Initialize Class 10 CBSE curriculum in Settings or Curriculum tab.
              </div>
            ) : (
              <div className="divide-y divide-stone-100 dark:divide-zinc-800/80">
                {filteredChapters.map(ch => {
                  const sub = subjects.find(s => s.id === ch.subjectId);
                  return (
                    <div key={ch.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-stone-50/50 dark:hover:bg-zinc-800/30 px-2 rounded-lg transition-colors">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">{sub?.name.split(' ')[0]}</span>
                          <span className="text-stone-300">·</span>
                          <span className="text-[11px] font-mono text-stone-400">Ch. {ch.chapterNumber}</span>
                        </div>
                        <h4 className="text-xs font-semibold text-stone-900 dark:text-white truncate">{ch.name}</h4>
                      </div>

                      {/* 1 to 5 Star Rating Buttons */}
                      <div className="flex items-center gap-1 shrink-0">
                        {[1, 2, 3, 4, 5].map(lvl => (
                          <button
                            key={lvl}
                            onClick={() => ch.id && handleUpdateConfidence(ch.id, lvl)}
                            className={cn(
                              "p-1.5 rounded transition-colors",
                              (ch.confidenceLevel || 3) >= lvl 
                                ? "text-amber-500 hover:text-amber-600" 
                                : "text-stone-200 dark:text-zinc-700 hover:text-stone-400"
                            )}
                            title={`Set confidence to ${lvl}/5`}
                          >
                            <Star className="w-4 h-4 fill-current" />
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Subject Aggregate Readiness */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {subjects.map(s => {
              const conf = getSubjectConfidence(s.id as number);
              return (
                <div key={s.id} className="p-4 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-stone-900 dark:text-white">{s.name}</span>
                    <span className="font-mono font-bold text-stone-700 dark:text-zinc-300">{conf}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-stone-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                      style={{ width: `${conf}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* Right Col: Weak Topic Tracker */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-stone-900 dark:text-white">Weak-Topic Intervention</h3>
                <p className="text-[11px] text-stone-500">Flag difficult formulas or concepts for targeted drill.</p>
              </div>
              <button 
                onClick={() => setShowAddWeakTopic(!showAddWeakTopic)}
                className="p-1.5 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md hover:opacity-90"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Add Weak Topic Form */}
            {showAddWeakTopic && (
              <div className="p-3 bg-stone-50 dark:bg-zinc-800/40 border border-stone-200 dark:border-zinc-700 rounded-xl space-y-2.5 animate-in fade-in">
                <input 
                  type="text"
                  placeholder="Topic / Concept (e.g. Lens Sign Convention)"
                  value={newTopicTitle}
                  onChange={(e) => setNewTopicTitle(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-700 rounded text-xs text-stone-900 dark:text-white outline-none focus:ring-1 focus:ring-indigo-500"
                  autoFocus
                />
                <input 
                  type="text"
                  placeholder="Chapter (e.g. Light Reflection)"
                  value={newTopicChapter}
                  onChange={(e) => setNewTopicChapter(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-700 rounded text-xs text-stone-900 dark:text-white outline-none focus:ring-1 focus:ring-indigo-500"
                />
                <div className="flex justify-between items-center text-xs pt-1">
                  <div className="flex gap-1">
                    {(['low', 'medium', 'high'] as const).map(sev => (
                      <button
                        key={sev}
                        type="button"
                        onClick={() => setNewTopicSeverity(sev)}
                        className={cn(
                          "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                          newTopicSeverity === sev ? "bg-stone-900 text-white dark:bg-white dark:text-stone-900" : "bg-stone-200 text-stone-600 dark:bg-zinc-700 dark:text-zinc-300"
                        )}
                      >
                        {sev}
                      </button>
                    ))}
                  </div>
                  <button 
                    onClick={handleCreateWeakTopic}
                    className="px-3 py-1 bg-indigo-600 text-white rounded text-xs font-semibold hover:bg-indigo-700"
                  >
                    Save Topic
                  </button>
                </div>
              </div>
            )}

            {/* List of Weak Topics */}
            {filteredWeakTopics.length === 0 ? (
              <div className="py-8 text-center text-xs text-stone-400">
                No weak topics flagged. Add topics you struggle with to focus your study sessions.
              </div>
            ) : (
              <div className="space-y-2">
                {filteredWeakTopics.map(w => (
                  <div 
                    key={w.id}
                    className={cn(
                      "p-3 rounded-xl border transition-all flex items-start justify-between gap-3 text-xs",
                      w.resolved 
                        ? "border-emerald-200 bg-emerald-50/30 dark:border-emerald-900/30 dark:bg-emerald-950/10 opacity-70"
                        : "border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/40"
                    )}
                  >
                    <button 
                      onClick={() => w.id && handleToggleResolveWeakTopic(w.id, w.resolved)}
                      className="mt-0.5 text-stone-400 hover:text-emerald-600 transition-colors"
                    >
                      {w.resolved ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <div className="w-4 h-4 rounded-full border border-stone-300 dark:border-zinc-600" />}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className={cn("font-semibold text-stone-900 dark:text-white truncate", w.resolved && "line-through text-stone-400")}>
                        {w.topicName}
                      </div>
                      <div className="text-[10px] text-stone-400 mt-0.5">
                        {w.chapterName} · <span className={cn(
                          "font-bold uppercase",
                          w.severity === 'high' ? "text-red-500" : w.severity === 'medium' ? "text-amber-500" : "text-blue-500"
                        )}>{w.severity} priority</span>
                      </div>
                    </div>

                    <button 
                      onClick={() => w.id && handleDeleteWeakTopic(w.id)}
                      className="text-stone-300 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}

import React, { useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { 
  FileText, Play, Box, Folder, Search, 
  Filter, Grid, List, MoreVertical, UploadCloud,
  File, Trash2
} from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useUIStore } from '@/store/uiStore';

export function Library() {
  const navigate = useNavigate();
  const askConfirmation = useUIStore((state) => state.askConfirmation);
  const showToast = useUIStore((state) => state.showToast);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeFilter, setActiveFilter] = useState<'all' | 'pdf' | 'video' | '3d'>('all');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const files = useLiveQuery(async () => {
    const all = await db.library.toArray();
    return all.sort((a, b) => b.createdAt - a.createdAt);
  }, []);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (!selectedFiles) return;

    for (let i = 0; i < selectedFiles.length; i++) {
      const file = selectedFiles[i];
      let type: 'pdf' | 'video' | '3d' | 'other' = 'other';
      if (file.type.includes('pdf')) type = 'pdf';
      else if (file.type.includes('video')) type = 'video';
      else if (file.name.endsWith('.obj') || file.name.endsWith('.gltf') || file.name.endsWith('.glb')) type = '3d';

      await db.library.add({
        title: file.name,
        type,
        fileData: file, // Store the Blob directly in IndexedDB
        size: file.size,
        createdAt: Date.now()
      });
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    showToast('File added to StudyForge library.', 'success');
  };

  const handleDelete = (id: number) => {
    askConfirmation({
      title: 'Remove File',
      message: 'Are you sure you want to remove this file from your StudyForge library?',
      confirmLabel: 'Remove',
      isDestructive: true,
      onConfirm: async () => {
        await db.library.delete(id);
        showToast('File removed from library.', 'info');
      }
    });
  };

  const filteredFiles = files?.filter(f => {
    if (activeFilter !== 'all' && f.type !== activeFilter) return false;
    if (searchQuery && !f.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  }) || [];

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-500">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Library</h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400 mt-1">
            Manage your local PDFs, videos, and 3D models securely offline.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <input 
            type="file" 
            multiple
            ref={fileInputRef} 
            className="hidden" 
            accept="application/pdf,video/*,.obj,.gltf,.glb"
            onChange={handleFileUpload}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md text-sm font-medium shadow-sm hover:bg-indigo-700 transition-colors"
          >
            <UploadCloud className="w-4 h-4" /> Import Resource
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6 shrink-0 justify-between items-center bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg p-2 shadow-sm">
        
        <div className="flex items-center gap-1">
          <FilterButton active={activeFilter === 'all'} onClick={() => setActiveFilter('all')}>All Files</FilterButton>
          <FilterButton active={activeFilter === 'pdf'} onClick={() => setActiveFilter('pdf')} icon={FileText}>PDFs</FilterButton>
          <FilterButton active={activeFilter === 'video'} onClick={() => setActiveFilter('video')} icon={Play}>Videos</FilterButton>
          <FilterButton active={activeFilter === '3d'} onClick={() => setActiveFilter('3d')} icon={Box}>3D Models</FilterButton>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input 
              type="text" 
              placeholder="Search library..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 bg-stone-50 dark:bg-zinc-800/50 border border-transparent focus:border-stone-200 dark:focus:border-zinc-700 rounded-md text-sm text-stone-900 dark:text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all"
            />
          </div>
          
          <div className="flex items-center bg-stone-100 dark:bg-zinc-800 p-0.5 rounded-md">
            <button 
              onClick={() => setViewMode('grid')}
              className={cn("p-1.5 rounded transition-colors", viewMode === 'grid' ? "bg-white dark:bg-zinc-700 shadow-sm text-stone-900 dark:text-white" : "text-stone-500 hover:text-stone-700 dark:hover:text-zinc-300")}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setViewMode('list')}
              className={cn("p-1.5 rounded transition-colors", viewMode === 'list' ? "bg-white dark:bg-zinc-700 shadow-sm text-stone-900 dark:text-white" : "text-stone-500 hover:text-stone-700 dark:hover:text-zinc-300")}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 min-h-0 overflow-y-auto custom-scrollbar">
        {filteredFiles.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-stone-500 dark:text-zinc-400 py-12 border-2 border-dashed border-stone-200 dark:border-zinc-800 rounded-xl bg-stone-50/50 dark:bg-zinc-900/20">
            <Folder className="w-16 h-16 mb-4 text-stone-300 dark:text-zinc-700" />
            <p className="text-base font-medium text-stone-900 dark:text-white mb-1">No files found</p>
            <p className="text-sm">Import PDFs, videos, or 3D models to build your library.</p>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="mt-6 px-4 py-2 bg-white dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 text-stone-900 dark:text-white rounded-md text-sm font-medium shadow-sm hover:bg-stone-50 dark:hover:bg-zinc-700 transition-colors"
            >
              Browse Local Files
            </button>
          </div>
        ) : (
          viewMode === 'grid' ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-10">
              {filteredFiles.map(file => (
                <FileGridItem key={file.id} file={file} onDelete={() => handleDelete(file.id as number)} />
              ))}
            </div>
          ) : (
            <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col overflow-hidden">
              <div className="grid grid-cols-[auto_1fr_150px_100px_50px] gap-4 px-5 py-3 border-b border-stone-200 dark:border-zinc-800 bg-stone-50/80 dark:bg-zinc-900/80 text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider shrink-0">
                <div className="w-8">Type</div>
                <div>Name</div>
                <div>Date Added</div>
                <div>Size</div>
                <div></div>
              </div>
              <div className="divide-y divide-stone-100 dark:divide-zinc-800/50">
                {filteredFiles.map(file => (
                  <FileListRow key={file.id} file={file} onDelete={() => handleDelete(file.id as number)} />
                ))}
              </div>
            </div>
          )
        )}
      </div>
    </div>
  );
}

function FilterButton({ active, onClick, children, icon: Icon }: any) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-3 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1.5",
        active 
          ? "bg-stone-100 dark:bg-zinc-800 text-stone-900 dark:text-white" 
          : "text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800/50"
      )}
    >
      {Icon && <Icon className="w-3.5 h-3.5" />}
      {children}
    </button>
  );
}

function getFileIcon(type: string) {
  switch (type) {
    case 'pdf': return <FileText className="w-8 h-8 text-blue-500" />;
    case 'video': return <Play className="w-8 h-8 text-rose-500" />;
    case '3d': return <Box className="w-8 h-8 text-purple-500" />;
    default: return <File className="w-8 h-8 text-stone-400" />;
  }
}

function getSmallFileIcon(type: string) {
  switch (type) {
    case 'pdf': return <FileText className="w-4 h-4 text-blue-500" />;
    case 'video': return <Play className="w-4 h-4 text-rose-500" />;
    case '3d': return <Box className="w-4 h-4 text-purple-500" />;
    default: return <File className="w-4 h-4 text-stone-400" />;
  }
}

function formatBytes(bytes: number, decimals = 2) {
  if (!+bytes) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
}

function FileGridItem({ file, onDelete }: { file: any, onDelete: () => void }) {
  const navigate = useNavigate();
  return (
    <div 
      className="group flex flex-col bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer hover:border-indigo-300 dark:hover:border-indigo-700 relative"
      onClick={() => navigate('/workspace')}
    >
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
        <button 
          className="p-1.5 bg-white dark:bg-zinc-800 text-stone-400 hover:text-red-500 rounded-md shadow-sm border border-stone-100 dark:border-zinc-700" 
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
      <div className="h-32 bg-stone-50 dark:bg-zinc-800/50 flex items-center justify-center border-b border-stone-100 dark:border-zinc-800 relative">
        {getFileIcon(file.type)}
      </div>
      <div className="p-3">
        <h3 className="text-sm font-medium text-stone-900 dark:text-white truncate" title={file.title}>{file.title}</h3>
        <div className="flex items-center justify-between mt-1">
          <p className="text-xs text-stone-500 dark:text-zinc-500">{formatBytes(file.size)}</p>
          <span className="text-[10px] uppercase font-semibold text-stone-400 dark:text-zinc-500 tracking-wider">{file.type}</span>
        </div>
      </div>
    </div>
  );
}

function FileListRow({ file, onDelete }: { file: any, onDelete: () => void }) {
  const navigate = useNavigate();
  return (
    <div 
      className="grid grid-cols-[auto_1fr_150px_100px_50px] gap-4 px-5 py-3 items-center group hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors cursor-pointer bg-white dark:bg-zinc-900"
      onClick={() => navigate('/workspace')}
    >
      <div className="w-8 flex justify-center">
        {getSmallFileIcon(file.type)}
      </div>
      <div className="min-w-0">
        <h3 className="text-sm font-medium text-stone-900 dark:text-white truncate">{file.title}</h3>
      </div>
      <div className="text-xs text-stone-500 dark:text-zinc-400">
        {format(file.createdAt, 'MMM d, yyyy')}
      </div>
      <div className="text-xs text-stone-500 dark:text-zinc-400">
        {formatBytes(file.size)}
      </div>
      <div className="flex justify-end opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          className="p-1.5 text-stone-400 hover:text-red-500 rounded-md transition-colors" 
          onClick={(e) => { e.stopPropagation(); onDelete(); }}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

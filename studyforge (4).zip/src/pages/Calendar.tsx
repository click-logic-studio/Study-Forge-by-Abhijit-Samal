import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { format, addDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, subWeeks, addWeeks } from 'date-fns';
import { Calendar as CalIcon, Clock, ChevronLeft, ChevronRight, Filter } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Calendar() {
  const tasks = useLiveQuery(() => db.tasks.toArray());
  const sessions = useLiveQuery(() => db.studySessions.toArray());
  
  const [currentDate, setCurrentDate] = useState(new Date());

  const start = startOfWeek(currentDate, { weekStartsOn: 1 });
  const end = endOfWeek(currentDate, { weekStartsOn: 1 });
  const daysInWeek = eachDayOfInterval({ start, end });
  const today = new Date();

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-500 pb-4">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Schedule</h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400 mt-1">
            Weekly overview of your study sessions and upcoming tasks.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md p-1 shadow-sm">
          <button 
            onClick={() => setCurrentDate(subWeeks(currentDate, 1))}
            className="p-1.5 text-stone-500 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="px-3 text-sm font-semibold text-stone-700 dark:text-zinc-300 min-w-[120px] text-center">
            {format(start, 'MMM d')} - {format(end, 'MMM d, yyyy')}
          </div>
          <button 
            onClick={() => setCurrentDate(addWeeks(currentDate, 1))}
            className="p-1.5 text-stone-500 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="flex items-center justify-between mb-4 shrink-0 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg p-2 shadow-sm">
        <div className="flex items-center gap-1">
          <button className="px-3 py-1.5 rounded-md text-sm font-medium bg-stone-100 dark:bg-zinc-800 text-stone-900 dark:text-white">Week</button>
          <button className="px-3 py-1.5 rounded-md text-sm font-medium text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors">Month</button>
        </div>
        <button className="flex items-center gap-2 px-3 py-1.5 bg-stone-50 dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded-md text-sm text-stone-700 dark:text-zinc-300 hover:bg-stone-100 dark:hover:bg-zinc-700 transition-colors">
          <Filter className="w-3.5 h-3.5" /> Filters
        </button>
      </div>

      <div className="flex-1 min-h-0 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col overflow-hidden">
        {/* Weekly View Header */}
        <div className="grid grid-cols-7 border-b border-stone-200 dark:border-zinc-800 bg-stone-50/80 dark:bg-zinc-900/80 shrink-0">
          {daysInWeek.map(day => {
            const isToday = isSameDay(day, today);
            return (
              <div 
                key={day.toISOString()} 
                className={cn(
                  "px-3 py-2.5 text-center border-r last:border-r-0 border-stone-200 dark:border-zinc-800",
                  isToday ? "bg-indigo-50/50 dark:bg-indigo-900/10" : ""
                )}
              >
                <div className={cn(
                  "text-[10px] font-bold uppercase tracking-wider mb-0.5",
                  isToday ? "text-indigo-600 dark:text-indigo-400" : "text-stone-500 dark:text-zinc-400"
                )}>
                  {format(day, 'EEE')}
                </div>
                <div className={cn(
                  "text-lg font-semibold",
                  isToday ? "text-indigo-700 dark:text-indigo-300" : "text-stone-900 dark:text-zinc-100"
                )}>
                  {format(day, 'd')}
                </div>
              </div>
            );
          })}
        </div>

        {/* Weekly View Body */}
        <div className="flex-1 grid grid-cols-7 overflow-y-auto custom-scrollbar">
          {daysInWeek.map(day => {
            const isToday = isSameDay(day, today);
            const dayTasks = tasks?.filter(t => t.dueDate && isSameDay(new Date(t.dueDate), day)) || [];
            const daySessions = sessions?.filter(s => isSameDay(new Date(s.startTime), day)) || [];
            
            return (
              <div 
                key={day.toISOString()} 
                className={cn(
                  "border-r last:border-r-0 border-stone-200 dark:border-zinc-800 p-2 min-h-[200px] flex flex-col gap-1.5",
                  isToday ? "bg-indigo-50/20 dark:bg-indigo-900/5" : ""
                )}
              >
                {daySessions.map(session => (
                  <div key={`session-${session.id}`} className="px-2 py-1.5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800/30 rounded text-emerald-800 dark:text-emerald-300 text-[11px] font-medium leading-tight shadow-sm">
                    <div className="flex items-center gap-1 mb-0.5">
                      <Clock className="w-3 h-3" />
                      <span>{Math.floor(session.durationMinutes / 60)}h {session.durationMinutes % 60}m</span>
                    </div>
                    <div className="truncate opacity-80">{session.topic || 'Study Session'}</div>
                  </div>
                ))}
                
                {dayTasks.map(task => (
                  <div key={`task-${task.id}`} className="px-2 py-1.5 bg-white dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded text-stone-700 dark:text-zinc-300 text-[11px] font-medium leading-tight shadow-sm truncate">
                    {task.title}
                  </div>
                ))}
                
                {dayTasks.length === 0 && daySessions.length === 0 && (
                  <div className="flex-1 w-full flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <button className="text-[10px] uppercase font-bold tracking-wider text-stone-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors p-2">
                      + Add Item
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { format } from 'date-fns';
import { Target, Play, Clock, ArrowRight, Activity, BookOpen, PenTool, CheckCircle2, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';

export function Dashboard() {
  const profile = useLiveQuery(() => db.profile.get(1));
  const navigate = useNavigate();

  const sessions = useLiveQuery(() => db.studySessions.toArray());
  const goals = useLiveQuery(() => db.goals.filter(g => !g.completed).toArray());
  const subjects = useLiveQuery(() => db.subjects.toArray());
  const pendingTasks = useLiveQuery(() => db.tasks.filter(t => !t.completed).limit(5).toArray());

  const totalStudyMinutes = sessions?.reduce((acc, s) => acc + (s.durationMinutes || 0), 0) || 0;
  const hours = Math.floor(totalStudyMinutes / 60);
  const minutes = totalStudyMinutes % 60;

  if (profile === undefined) {
    return (
      <div className="animate-pulse space-y-8 max-w-[1400px] mx-auto w-full h-full flex flex-col">
        <div className="h-12 w-64 bg-stone-200 dark:bg-zinc-800 rounded"></div>
        <div className="h-64 bg-stone-200 dark:bg-zinc-800 rounded-xl"></div>
      </div>
    );
  }

  const greeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-[1600px] mx-auto pb-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Header Area */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-2">
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
            {greeting()}, {profile?.nickname || profile?.name || 'Student'}
          </h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400">
            {profile?.curriculum !== 'None' ? `Curriculum: ${profile?.curriculum} • ` : ''}
            {format(new Date(), 'EEEE, MMMM do, yyyy')}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate('/workspace')}
            className="flex items-center gap-2 px-4 py-2 bg-stone-900 dark:bg-white text-white dark:text-zinc-900 rounded-md text-sm font-medium shadow-sm hover:bg-stone-800 dark:hover:bg-zinc-100 transition-colors"
          >
            <Play className="w-4 h-4" />
            Resume Study Workspace
          </button>
        </div>
      </header>

      {/* Primary KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <KpiCard title="Total Study Time" value={`${hours}h ${minutes}m`} trend="+12% this week" icon={Clock} color="indigo" />
        <KpiCard title="Active Goals" value={goals?.length.toString() || "0"} trend="2 due today" icon={Target} color="orange" />
        <KpiCard title="Overall Progress" value="34%" trend="Chapter 3 pending" icon={Activity} color="emerald" />
        <KpiCard title="Revision Queue" value="12 items" trend="High priority" icon={PenTool} color="rose" />
      </div>

      {/* Main Split Content */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Left Column (2/3 width on large screens) */}
        <div className="xl:col-span-2 flex flex-col gap-6">
          
          {/* Today's Study Plan Data Table */}
          <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm overflow-hidden flex flex-col">
            <div className="border-b border-stone-200 dark:border-zinc-800 px-5 py-4 flex items-center justify-between bg-stone-50/50 dark:bg-zinc-900/50">
              <h2 className="text-base font-semibold text-stone-900 dark:text-white flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-500" /> Today's Study Plan
              </h2>
              <button className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline">View All Goals</button>
            </div>
            
            <div className="p-0 overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-stone-500 dark:text-zinc-400 uppercase bg-stone-50 dark:bg-zinc-900 border-b border-stone-200 dark:border-zinc-800">
                  <tr>
                    <th className="px-5 py-3 font-medium">Goal / Topic</th>
                    <th className="px-5 py-3 font-medium">Subject</th>
                    <th className="px-5 py-3 font-medium">Est. Time</th>
                    <th className="px-5 py-3 font-medium">Status</th>
                    <th className="px-5 py-3 text-right font-medium">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200 dark:divide-zinc-800">
                  {(!goals || goals.length === 0) ? (
                    <tr>
                      <td colSpan={5} className="px-5 py-8 text-center text-stone-500">
                        No active goals for today. Create one to stay on track.
                      </td>
                    </tr>
                  ) : (
                    goals.slice(0, 4).map(goal => {
                      const subject = subjects?.find(s => s.id === goal.subjectId);
                      return (
                        <tr key={goal.id} className="hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors group">
                          <td className="px-5 py-3 font-medium text-stone-900 dark:text-white">{goal.title}</td>
                          <td className="px-5 py-3">
                            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium bg-stone-100 dark:bg-zinc-800 text-stone-700 dark:text-zinc-300">
                              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: subject?.color || '#94a3b8' }}></span>
                              {subject?.name || 'General'}
                            </span>
                          </td>
                          <td className="px-5 py-3 text-stone-500 dark:text-zinc-400">45m</td>
                          <td className="px-5 py-3">
                            <span className="inline-flex items-center text-xs font-medium text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded">
                              Pending
                            </span>
                          </td>
                          <td className="px-5 py-3 text-right">
                            <button className="text-indigo-600 dark:text-indigo-400 font-medium text-xs hover:underline flex items-center justify-end gap-1 w-full opacity-0 group-hover:opacity-100 transition-opacity">
                              Start <ArrowRight className="w-3 h-3" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </section>

          {/* Quick Actions / Modules */}
          <section>
            <h2 className="text-sm font-semibold text-stone-900 dark:text-white mb-3 uppercase tracking-wider">Learning Modules</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <ModuleCard title="PDF Reader" desc="Read & Annotate" icon={BookOpen} path="/workspace" color="bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400" />
              <ModuleCard title="Simulations" desc="Interactive Labs" icon={Activity} path="/simulations" color="bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400" />
              <ModuleCard title="3D Viewer" desc="Spatial Models" icon={Box} path="/3d-lab" color="bg-purple-50 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400" />
              <ModuleCard title="Quizzes" desc="Test Knowledge" icon={CheckCircle2} path="/quizzes" color="bg-rose-50 text-rose-600 dark:bg-rose-900/20 dark:text-rose-400" />
            </div>
          </section>

        </div>

        {/* Right Column (1/3 width) */}
        <div className="flex flex-col gap-6">
          
          {/* Action Center */}
          <section className="bg-stone-900 text-white dark:bg-indigo-950 rounded-lg p-5 shadow-sm border border-stone-800 dark:border-indigo-900">
            <h3 className="font-semibold text-sm mb-2 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400" /> Priority Action Required
            </h3>
            <p className="text-sm text-stone-300 dark:text-indigo-200 mb-4 leading-relaxed">
              You have {pendingTasks?.length || 0} overdue tasks and 1 topic flagged for immediate revision.
            </p>
            <div className="flex flex-col gap-2">
              <button className="w-full py-2 bg-white text-stone-900 font-medium text-sm rounded hover:bg-stone-100 transition-colors text-center">
                Review Weak Topics
              </button>
            </div>
          </section>

          {/* Upcoming Tasks */}
          <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col flex-1">
            <div className="border-b border-stone-200 dark:border-zinc-800 px-5 py-4 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-stone-900 dark:text-white">Upcoming Deadlines</h2>
              <button onClick={() => navigate('/tasks')} className="text-xs text-stone-500 hover:text-stone-900 dark:hover:text-white">View All</button>
            </div>
            <div className="p-5 flex-1">
              {pendingTasks?.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center">
                  <CheckCircle2 className="w-8 h-8 text-stone-300 dark:text-zinc-700 mb-2" />
                  <p className="text-sm text-stone-500 dark:text-zinc-400">All caught up on tasks.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingTasks?.map(task => (
                    <div key={task.id} className="flex gap-3 items-start">
                      <div className="mt-0.5 w-4 h-4 rounded-full border-2 border-stone-300 dark:border-zinc-700 shrink-0"></div>
                      <div>
                        <p className="text-sm font-medium text-stone-900 dark:text-white leading-tight mb-1">{task.title}</p>
                        {task.dueDate && (
                          <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">Due {format(task.dueDate, 'MMM d')}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>

        </div>
      </div>
    </div>
  );
}

// Subcomponents

function KpiCard({ title, value, trend, icon: Icon, color }: any) {
  const colorMap: Record<string, string> = {
    indigo: "text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20",
    orange: "text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-900/20",
    emerald: "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20",
    rose: "text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-900/20",
  };

  return (
    <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg p-5 shadow-sm flex flex-col">
      <div className="flex justify-between items-start mb-2">
        <p className="text-xs font-medium text-stone-500 dark:text-zinc-400 uppercase tracking-wide">{title}</p>
        <div className={cn("p-1.5 rounded-md", colorMap[color])}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="mt-auto">
        <h3 className="text-2xl font-bold text-stone-900 dark:text-white">{value}</h3>
        <p className="text-xs text-stone-500 dark:text-zinc-500 mt-1">{trend}</p>
      </div>
    </div>
  );
}

function ModuleCard({ title, desc, icon: Icon, path, color }: any) {
  const navigate = useNavigate();
  return (
    <button 
      onClick={() => navigate(path)}
      className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg p-4 text-left hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors shadow-sm group flex flex-col h-full"
    >
      <div className={cn("w-8 h-8 rounded-md flex items-center justify-center mb-3", color)}>
        <Icon className="w-4 h-4" />
      </div>
      <h4 className="font-semibold text-sm text-stone-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">{title}</h4>
      <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">{desc}</p>
    </button>
  );
}

// Temporary Box icon for 3D Lab if not imported above
function Box(props: any) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
      <line x1="12" y1="22.08" x2="12" y2="12"></line>
    </svg>
  );
}


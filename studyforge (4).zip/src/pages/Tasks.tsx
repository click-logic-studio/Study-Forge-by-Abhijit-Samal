import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { Plus, CheckCircle2, Circle, Calendar as CalIcon, Flag, Trash2, Search, Filter } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

export function Tasks() {
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  
  const incompleteTasks = useLiveQuery(() => db.tasks.where('completed').equals(0).reverse().toArray());
  const completedTasks = useLiveQuery(() => db.tasks.where('completed').equals(1).reverse().limit(20).toArray());

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    
    await db.tasks.add({
      title: newTaskTitle.trim(),
      completed: false,
      priority: 'medium',
      createdAt: Date.now()
    });
    setNewTaskTitle('');
  };

  const toggleTask = async (task: any) => {
    await db.tasks.update(task.id, { completed: !task.completed });
  };

  const deleteTask = async (id: number) => {
    await db.tasks.delete(id);
  };

  const setPriority = async (id: number, priority: 'low' | 'medium' | 'high') => {
    await db.tasks.update(id, { priority });
  };

  const priorityColors = {
    low: 'text-stone-400 dark:text-zinc-500',
    medium: 'text-amber-500',
    high: 'text-rose-500'
  };
  
  const priorityBgColors = {
    low: 'bg-stone-100 dark:bg-zinc-800 border-stone-200 dark:border-zinc-700 text-stone-600 dark:text-zinc-400',
    medium: 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800/30 text-amber-700 dark:text-amber-500',
    high: 'bg-rose-50 dark:bg-rose-900/20 border-rose-200 dark:border-rose-800/30 text-rose-700 dark:text-rose-500'
  };

  const filteredIncomplete = incompleteTasks?.filter(t => {
    if (activeFilter !== 'all' && t.priority !== activeFilter) return false;
    if (searchQuery && !t.title.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-500">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Tasks & Actions</h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400 mt-1">
            Track study assignments, revision milestones, and to-do items.
          </p>
        </div>
      </header>

      {/* Input Row */}
      <form onSubmit={handleAddTask} className="mb-6 flex gap-3 relative shrink-0">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400">
          <Plus className="w-4 h-4" />
        </div>
        <input 
          type="text" 
          value={newTaskTitle}
          onChange={e => setNewTaskTitle(e.target.value)}
          placeholder="Enter a new task..." 
          className="flex-1 py-2 pl-9 pr-4 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md shadow-sm focus:ring-2 focus:ring-indigo-500/50 outline-none text-sm text-stone-900 dark:text-white placeholder-stone-400 transition-all"
        />
        <button 
          type="submit" 
          disabled={!newTaskTitle.trim()}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-stone-300 disabled:dark:bg-zinc-800 disabled:text-stone-500 text-white rounded-md text-sm font-medium transition-colors shadow-sm"
        >
          Add Task
        </button>
      </form>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4 shrink-0">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
          <input 
            type="text" 
            placeholder="Search tasks..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md text-sm text-stone-900 dark:text-white placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
          />
        </div>
        <div className="flex items-center gap-1 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md p-1 shadow-sm">
          <FilterButton active={activeFilter === 'all'} onClick={() => setActiveFilter('all')}>All</FilterButton>
          <FilterButton active={activeFilter === 'high'} onClick={() => setActiveFilter('high')}>High Priority</FilterButton>
          <FilterButton active={activeFilter === 'medium'} onClick={() => setActiveFilter('medium')}>Medium</FilterButton>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col gap-6 pb-10">
        
        {/* Active Tasks Table */}
        <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col overflow-hidden shrink-0">
          <div className="px-5 py-3 border-b border-stone-200 dark:border-zinc-800 bg-stone-50/80 dark:bg-zinc-900/80 flex items-center justify-between">
            <h2 className="text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider">Active Tasks ({filteredIncomplete?.length || 0})</h2>
          </div>
          
          <div className="divide-y divide-stone-100 dark:divide-zinc-800/50">
            {filteredIncomplete?.length === 0 ? (
              <div className="p-8 text-center text-stone-500 dark:text-zinc-400 text-sm">
                No active tasks found matching criteria.
              </div>
            ) : (
              filteredIncomplete?.map(task => (
                <div key={task.id} className="group flex items-center gap-4 px-5 py-3 hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors">
                  
                  <button onClick={() => toggleTask(task)} className="text-stone-300 dark:text-zinc-600 hover:text-emerald-500 transition-colors shrink-0">
                    <Circle className="w-5 h-5" />
                  </button>
                  
                  <div className="flex-1 min-w-0 flex flex-col">
                    <span className="font-medium text-sm text-stone-900 dark:text-zinc-100 truncate">{task.title}</span>
                    <span className="text-[10px] text-stone-400 dark:text-zinc-500 mt-0.5">Added {format(task.createdAt, 'MMM d, yyyy')}</span>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => setPriority(task.id as number, task.priority === 'high' ? 'low' : task.priority === 'medium' ? 'high' : 'medium')}
                      className={cn("px-2 py-0.5 rounded border text-[10px] uppercase font-bold tracking-wider", priorityBgColors[task.priority as keyof typeof priorityBgColors])}
                    >
                      {task.priority}
                    </button>
                    
                    <button 
                      onClick={() => deleteTask(task.id as number)}
                      className="p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-950/30 text-stone-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  
                </div>
              ))
            )}
          </div>
        </section>

        {/* Completed Tasks */}
        {completedTasks && completedTasks.length > 0 && (
          <section className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col overflow-hidden shrink-0 opacity-75 hover:opacity-100 transition-opacity">
            <div className="px-5 py-3 border-b border-stone-200 dark:border-zinc-800 bg-stone-50/80 dark:bg-zinc-900/80">
              <h2 className="text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider">Recently Completed</h2>
            </div>
            <div className="divide-y divide-stone-100 dark:divide-zinc-800/50">
              {completedTasks.map(task => (
                <div key={task.id} className="group flex items-center gap-4 px-5 py-2.5 hover:bg-stone-50 dark:hover:bg-zinc-800/50 transition-colors">
                  <button onClick={() => toggleTask(task)} className="text-emerald-500 shrink-0">
                    <CheckCircle2 className="w-5 h-5" />
                  </button>
                  
                  <div className="flex-1 min-w-0">
                    <span className="font-medium text-sm text-stone-500 dark:text-zinc-400 line-through truncate">{task.title}</span>
                  </div>
                  
                  <button 
                    onClick={() => deleteTask(task.id as number)}
                    className="p-1.5 rounded-md hover:bg-red-50 dark:hover:bg-red-950/30 text-stone-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </section>
        )}

      </div>
    </div>
  );
}

function FilterButton({ active, onClick, children }: any) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "px-3 py-1 rounded text-xs font-medium transition-colors",
        active 
          ? "bg-stone-100 dark:bg-zinc-800 text-stone-900 dark:text-white" 
          : "text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800/50"
      )}
    >
      {children}
    </button>
  );
}

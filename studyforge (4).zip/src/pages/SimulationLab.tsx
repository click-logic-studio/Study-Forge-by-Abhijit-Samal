import React, { useState, useRef, useEffect } from 'react';
import { 
  Microscope, Play, RotateCcw, Zap, Compass, 
  ArrowLeft, Info, HelpCircle, Activity
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useUIStore } from '@/store/uiStore';

type SimId = 'mirror' | 'circuits' | 'refraction';

export function SimulationLab() {
  const [activeSim, setActiveSim] = useState<SimId | null>(null);
  const { performanceMode } = useUIStore();

  // 1. MIRROR SIMULATION STATE
  const [mirrorType, setMirrorType] = useState<'concave' | 'convex'>('concave');
  const [objDistanceU, setObjDistanceU] = useState<number>(-35); // in cm (negative in front of mirror)
  const [focalLengthF, setFocalLengthF] = useState<number>(-15); // in cm (negative for concave, positive for convex)
  const [objHeightH, setObjHeightH] = useState<number>(10); // in cm
  const mirrorCanvasRef = useRef<HTMLCanvasElement>(null);

  // 2. CIRCUITS SIMULATION STATE
  const [voltageV, setVoltageV] = useState<number>(12); // Volts
  const [resistanceR1, setResistanceR1] = useState<number>(6); // Ohms
  const [resistanceR2, setResistanceR2] = useState<number>(6); // Ohms
  const [circuitType, setCircuitType] = useState<'single' | 'series' | 'parallel'>('series');
  const [circuitSwitch, setCircuitSwitch] = useState<boolean>(true);
  const circuitCanvasRef = useRef<HTMLCanvasElement>(null);

  // 3. REFRACTION / SNELL'S LAW STATE
  const [incidentAngle, setIncidentAngle] = useState<number>(45); // degrees
  const [n1, setN1] = useState<number>(1.0); // Air
  const [n2, setN2] = useState<number>(1.52); // Glass
  const refractionCanvasRef = useRef<HTMLCanvasElement>(null);

  // -------------------------------------------------------------
  // CANVAS DRAWING: SPHERICAL MIRRORS
  // -------------------------------------------------------------
  useEffect(() => {
    if (activeSim !== 'mirror' || !mirrorCanvasRef.current) return;
    const canvas = mirrorCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const f = mirrorType === 'concave' ? -Math.abs(focalLengthF) : Math.abs(focalLengthF);
    const u = -Math.abs(objDistanceU);
    // Mirror formula: 1/v = 1/f - 1/u => v = (f * u) / (u - f)
    const v = (u === f) ? Infinity : (f * u) / (u - f);
    const m = (u === f) ? Infinity : -v / u;
    const imgHeight = (m === Infinity) ? 0 : objHeightH * m;

    const poleX = width / 2;
    const axisY = height / 2;
    const scale = 5; // pixels per cm

    // Draw Principal Axis
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(20, axisY);
    ctx.lineTo(width - 20, axisY);
    ctx.stroke();

    // Draw Mirror Arc
    ctx.strokeStyle = '#3b82f6';
    ctx.lineWidth = 3;
    ctx.beginPath();
    if (mirrorType === 'concave') {
      ctx.arc(poleX - 80, axisY, 80, -Math.PI / 4, Math.PI / 4);
    } else {
      ctx.arc(poleX + 80, axisY, 80, 3 * Math.PI / 4, 5 * Math.PI / 4);
    }
    ctx.stroke();

    // Mark Pole (P), Focus (F), and Center (C)
    const fx = poleX + (f * scale);
    const cx = poleX + (2 * f * scale);

    const drawPoint = (x: number, label: string) => {
      ctx.fillStyle = '#64748b';
      ctx.beginPath();
      ctx.arc(x, axisY, 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.font = '11px sans-serif';
      ctx.fillText(label, x - 4, axisY + 16);
    };

    drawPoint(poleX, 'P');
    drawPoint(fx, 'F');
    drawPoint(cx, 'C');

    // Draw Object Arrow
    const objX = poleX + (u * scale);
    const objTopY = axisY - (objHeightH * scale);

    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(objX, axisY);
    ctx.lineTo(objX, objTopY);
    ctx.stroke();
    // Arrow head
    ctx.fillStyle = '#10b981';
    ctx.beginPath();
    ctx.moveTo(objX, objTopY - 4);
    ctx.lineTo(objX - 4, objTopY + 4);
    ctx.lineTo(objX + 4, objTopY + 4);
    ctx.fill();

    // Draw Image Arrow if finite
    if (isFinite(v)) {
      const imgX = poleX + (v * scale);
      const imgTopY = axisY - (imgHeight * scale);

      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(imgX, axisY);
      ctx.lineTo(imgX, imgTopY);
      ctx.stroke();

      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.moveTo(imgX, imgTopY + (imgHeight < 0 ? 4 : -4));
      ctx.lineTo(imgX - 4, imgTopY + (imgHeight < 0 ? -4 : 4));
      ctx.lineTo(imgX + 4, imgTopY + (imgHeight < 0 ? -4 : 4));
      ctx.fill();

      // Light Rays
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1.2;
      // Ray 1: Parallel to axis, passes through Focus
      ctx.beginPath();
      ctx.moveTo(objX, objTopY);
      ctx.lineTo(poleX, objTopY);
      ctx.lineTo(imgX, imgTopY);
      ctx.stroke();

      // Ray 2: Directed towards Pole
      ctx.beginPath();
      ctx.moveTo(objX, objTopY);
      ctx.lineTo(poleX, axisY);
      ctx.lineTo(imgX, imgTopY);
      ctx.stroke();
    }

  }, [activeSim, mirrorType, objDistanceU, focalLengthF, objHeightH]);

  // -------------------------------------------------------------
  // CANVAS DRAWING: OHM'S LAW & CIRCUIT
  // -------------------------------------------------------------
  useEffect(() => {
    if (activeSim !== 'circuits' || !circuitCanvasRef.current) return;
    const canvas = circuitCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let offset = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Equivalent Resistance Calculation
      let req = resistanceR1;
      if (circuitType === 'series') req = resistanceR1 + resistanceR2;
      if (circuitType === 'parallel') req = (resistanceR1 * resistanceR2) / (resistanceR1 + resistanceR2);

      const currentI = circuitSwitch ? (voltageV / req) : 0;

      // Draw Wire Bounds
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      ctx.strokeRect(60, 50, width - 120, height - 100);

      // Battery at Left
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(50, height / 2 - 30, 20, 60);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(55, height / 2 - 20, 10, 4);
      ctx.fillRect(52, height / 2 - 6, 16, 4);
      ctx.fillRect(55, height / 2 + 8, 10, 4);
      ctx.fillRect(52, height / 2 + 22, 16, 4);
      ctx.font = '11px monospace';
      ctx.fillText(`${voltageV}V Battery`, 10, height / 2 + 45);

      // Switch at Bottom
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(width / 2 - 30, height - 55, 60, 10);
      ctx.strokeStyle = circuitSwitch ? '#10b981' : '#ef4444';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(width / 2 - 25, height - 50);
      ctx.lineTo(width / 2 + (circuitSwitch ? 25 : 15), height - (circuitSwitch ? 50 : 65));
      ctx.stroke();
      ctx.fillStyle = '#64748b';
      ctx.fillText(`Switch (${circuitSwitch ? 'Closed' : 'Open'})`, width / 2 - 35, height - 25);

      // Resistors at Top
      if (circuitType === 'single') {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(width / 2 - 35, 40, 70, 20);
        ctx.strokeStyle = '#4f46e5';
        ctx.lineWidth = 3;
        ctx.strokeRect(width / 2 - 35, 40, 70, 20);
        ctx.fillStyle = '#4f46e5';
        ctx.fillText(`R = ${resistanceR1} Ω`, width / 2 - 22, 54);
      } else if (circuitType === 'series') {
        // Resistor 1
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(width / 2 - 110, 40, 65, 20);
        ctx.strokeStyle = '#4f46e5';
        ctx.lineWidth = 3;
        ctx.strokeRect(width / 2 - 110, 40, 65, 20);
        ctx.fillStyle = '#4f46e5';
        ctx.fillText(`R1=${resistanceR1}Ω`, width / 2 - 100, 54);

        // Resistor 2
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(width / 2 + 45, 40, 65, 20);
        ctx.strokeRect(width / 2 + 45, 40, 65, 20);
        ctx.fillText(`R2=${resistanceR2}Ω`, width / 2 + 55, 54);
      } else {
        // Parallel layout
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(width / 2 - 40, 30, 80, 18);
        ctx.strokeRect(width / 2 - 40, 30, 80, 18);
        ctx.fillStyle = '#4f46e5';
        ctx.fillText(`R1 = ${resistanceR1} Ω`, width / 2 - 25, 43);

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(width / 2 - 40, 65, 80, 18);
        ctx.strokeRect(width / 2 - 40, 65, 80, 18);
        ctx.fillStyle = '#4f46e5';
        ctx.fillText(`R2 = ${resistanceR2} Ω`, width / 2 - 25, 78);
      }

      // Live Current Electron Particles Animation
      if (circuitSwitch && currentI > 0 && !performanceMode) {
        offset = (offset + currentI * 0.8) % 30;
        ctx.fillStyle = '#f59e0b';
        // Top edge
        for (let x = 60 + offset; x < width - 60; x += 30) {
          ctx.beginPath();
          ctx.arc(x, 50, 3, 0, Math.PI * 2);
          ctx.fill();
        }
        // Right edge
        for (let y = 50 + offset; y < height - 50; y += 30) {
          ctx.beginPath();
          ctx.arc(width - 60, y, 3, 0, Math.PI * 2);
          ctx.fill();
        }
        // Bottom edge
        for (let x = width - 60 - offset; x > 60; x -= 30) {
          ctx.beginPath();
          ctx.arc(x, height - 50, 3, 0, Math.PI * 2);
          ctx.fill();
        }
        // Left edge
        for (let y = height - 50 - offset; y > 50; y -= 30) {
          ctx.beginPath();
          ctx.arc(60, y, 3, 0, Math.PI * 2);
          ctx.fill();
        }

        animId = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [activeSim, voltageV, resistanceR1, resistanceR2, circuitType, circuitSwitch, performanceMode]);

  // -------------------------------------------------------------
  // CANVAS DRAWING: SNELL'S LAW & REFRACTION
  // -------------------------------------------------------------
  useEffect(() => {
    if (activeSim !== 'refraction' || !refractionCanvasRef.current) return;
    const canvas = refractionCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const interfaceY = height / 2;
    const centerX = width / 2;

    // Fill Mediums
    ctx.fillStyle = '#f8fafc'; // Medium 1
    ctx.fillRect(0, 0, width, interfaceY);
    ctx.fillStyle = '#e0f2fe'; // Medium 2
    ctx.fillRect(0, interfaceY, width, height - interfaceY);

    // Labels
    ctx.fillStyle = '#475569';
    ctx.font = '12px sans-serif';
    ctx.fillText(`Medium 1 (n₁ = ${n1})`, 20, 30);
    ctx.fillText(`Medium 2 (n₂ = ${n2})`, 20, interfaceY + 30);

    // Boundary Line
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, interfaceY);
    ctx.lineTo(width, interfaceY);
    ctx.stroke();

    // Normal Line (dashed)
    ctx.strokeStyle = '#94a3b8';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(centerX, 20);
    ctx.lineTo(centerX, height - 20);
    ctx.stroke();
    ctx.setLineDash([]);

    // Incident Ray
    const theta1Rad = (incidentAngle * Math.PI) / 180;
    const rayLength = 160;
    const startX = centerX - rayLength * Math.sin(theta1Rad);
    const startY = interfaceY - rayLength * Math.cos(theta1Rad);

    ctx.strokeStyle = '#dc2626';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(startX, startY);
    ctx.lineTo(centerX, interfaceY);
    ctx.stroke();

    // Snell's Law: n1 * sin(theta1) = n2 * sin(theta2)
    const sinTheta2 = (n1 / n2) * Math.sin(theta1Rad);
    const isTIR = sinTheta2 > 1; // Total Internal Reflection

    if (!isTIR) {
      const theta2Rad = Math.asin(sinTheta2);
      const endX = centerX + rayLength * Math.sin(theta2Rad);
      const endY = interfaceY + rayLength * Math.cos(theta2Rad);

      ctx.strokeStyle = '#2563eb';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(centerX, interfaceY);
      ctx.lineTo(endX, endY);
      ctx.stroke();
    } else {
      // Reflected ray
      const endX = centerX + rayLength * Math.sin(theta1Rad);
      const endY = interfaceY - rayLength * Math.cos(theta1Rad);

      ctx.strokeStyle = '#ea580c';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(centerX, interfaceY);
      ctx.lineTo(endX, endY);
      ctx.stroke();
    }

  }, [activeSim, incidentAngle, n1, n2]);

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-300 pb-10">
      
      {/* Simulation Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white flex items-center gap-2.5">
            <Microscope className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>Simulation Lab</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            Empirical Class 10 NCERT physics laboratories with live mathematical computation.
          </p>
        </div>

        {activeSim && (
          <button 
            onClick={() => setActiveSim(null)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 dark:bg-zinc-800 hover:bg-stone-200 dark:hover:bg-zinc-700 text-stone-700 dark:text-zinc-300 rounded-md text-xs font-semibold transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Lab Catalog</span>
          </button>
        )}
      </header>

      {/* CATALOG VIEW (When no simulation is active) */}
      {!activeSim ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* SIM 1: SPHERICAL MIRRORS */}
          <div 
            onClick={() => setActiveSim('mirror')}
            className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-indigo-400 dark:hover:border-indigo-600 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <Compass className="w-6 h-6" />
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">Class 10 · Chapter 9</div>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">Spherical Mirror Ray Optics</h3>
              <p className="text-xs text-stone-500 dark:text-zinc-400 mt-2 leading-relaxed">
                Interactive concave & convex ray tracing. Move object distance and focal length to observe real, virtual, inverted, and magnified images.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-stone-100 dark:border-zinc-800/80 flex items-center justify-between text-xs font-semibold text-indigo-600 dark:text-indigo-400">
              <span>Launch Experiment</span>
              <Play className="w-4 h-4" />
            </div>
          </div>

          {/* SIM 2: OHM'S LAW & CIRCUITS */}
          <div 
            onClick={() => setActiveSim('circuits')}
            className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-indigo-400 dark:hover:border-indigo-600 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <Zap className="w-6 h-6" />
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">Class 10 · Chapter 11</div>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">Ohm's Law & DC Circuit Lab</h3>
              <p className="text-xs text-stone-500 dark:text-zinc-400 mt-2 leading-relaxed">
                Explore series and parallel resistances. Observe live electron flow animation, ammeter readings, and evaluate Joule heating.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-stone-100 dark:border-zinc-800/80 flex items-center justify-between text-xs font-semibold text-amber-600 dark:text-amber-400">
              <span>Launch Experiment</span>
              <Play className="w-4 h-4" />
            </div>
          </div>

          {/* SIM 3: SNELL'S LAW & REFRACTION */}
          <div 
            onClick={() => setActiveSim('refraction')}
            className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-indigo-400 dark:hover:border-indigo-600 transition-all cursor-pointer flex flex-col justify-between group"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <Activity className="w-6 h-6" />
              </div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Class 10 · Chapter 9</div>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">Snell's Law & Refraction Lab</h3>
              <p className="text-xs text-stone-500 dark:text-zinc-400 mt-2 leading-relaxed">
                Light ray bending through different refractive indices (air, water, glass, diamond). Test critical angle and total internal reflection.
              </p>
            </div>
            <div className="pt-4 mt-4 border-t border-stone-100 dark:border-zinc-800/80 flex items-center justify-between text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              <span>Launch Experiment</span>
              <Play className="w-4 h-4" />
            </div>
          </div>

        </div>
      ) : (
        /* ACTIVE EXPERIMENT WORKSPACE */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
          
          {/* Main Simulation Canvas */}
          <div className="lg:col-span-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-4 flex flex-col items-center justify-center relative min-h-[460px]">
            {activeSim === 'mirror' && (
              <canvas 
                ref={mirrorCanvasRef} 
                width={700} 
                height={420} 
                className="w-full max-w-[700px] aspect-[5/3] bg-stone-50 dark:bg-zinc-950 rounded-xl border border-stone-200 dark:border-zinc-800"
              />
            )}
            {activeSim === 'circuits' && (
              <canvas 
                ref={circuitCanvasRef} 
                width={700} 
                height={420} 
                className="w-full max-w-[700px] aspect-[5/3] bg-stone-50 dark:bg-zinc-950 rounded-xl border border-stone-200 dark:border-zinc-800"
              />
            )}
            {activeSim === 'refraction' && (
              <canvas 
                ref={refractionCanvasRef} 
                width={700} 
                height={420} 
                className="w-full max-w-[700px] aspect-[5/3] bg-stone-50 dark:bg-zinc-950 rounded-xl border border-stone-200 dark:border-zinc-800"
              />
            )}
          </div>

          {/* Interactive Parameters Controls & Readouts */}
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-5 flex flex-col justify-between space-y-6">
            
            {/* PARAMETERS FOR MIRRORS */}
            {activeSim === 'mirror' && (
              <div className="space-y-5">
                <div className="border-b border-stone-200 dark:border-zinc-800 pb-3">
                  <h3 className="font-bold text-sm text-stone-900 dark:text-white">Optics Controls</h3>
                  <p className="text-[11px] text-stone-500">Sign convention: Front is negative, behind is positive.</p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setMirrorType('concave')}
                    className={cn("flex-1 py-1.5 rounded border text-xs font-semibold", mirrorType === 'concave' ? "bg-indigo-600 text-white border-indigo-600" : "border-stone-200 dark:border-zinc-800")}
                  >
                    Concave
                  </button>
                  <button
                    onClick={() => setMirrorType('convex')}
                    className={cn("flex-1 py-1.5 rounded border text-xs font-semibold", mirrorType === 'convex' ? "bg-indigo-600 text-white border-indigo-600" : "border-stone-200 dark:border-zinc-800")}
                  >
                    Convex
                  </button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between font-mono mb-1">
                      <span>Object Distance (u):</span>
                      <span className="font-bold">{objDistanceU} cm</span>
                    </div>
                    <input 
                      type="range" min={-60} max={-5} step={1}
                      value={objDistanceU} onChange={(e) => setObjDistanceU(parseInt(e.target.value, 10))}
                      className="w-full accent-indigo-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between font-mono mb-1">
                      <span>Focal Length (f):</span>
                      <span className="font-bold">{focalLengthF} cm</span>
                    </div>
                    <input 
                      type="range" min={-40} max={-5} step={1}
                      value={focalLengthF} onChange={(e) => setFocalLengthF(parseInt(e.target.value, 10))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                </div>

                {/* Mathematical Readout */}
                <div className="p-3 bg-stone-50 dark:bg-zinc-950 rounded-lg border border-stone-200 dark:border-zinc-800 font-mono text-[11px] space-y-1">
                  <div className="text-[10px] font-sans font-bold uppercase text-stone-400">Formula Results</div>
                  <div>Image Distance (v): <span className="font-bold text-indigo-600">{Math.round(((focalLengthF * objDistanceU) / (objDistanceU - focalLengthF)) * 10) / 10} cm</span></div>
                  <div>Magnification (m): <span className="font-bold">{Math.round((-((focalLengthF * objDistanceU) / (objDistanceU - focalLengthF)) / objDistanceU) * 100) / 100}</span></div>
                </div>
              </div>
            )}

            {/* PARAMETERS FOR CIRCUITS */}
            {activeSim === 'circuits' && (
              <div className="space-y-5">
                <div className="border-b border-stone-200 dark:border-zinc-800 pb-3">
                  <h3 className="font-bold text-sm text-stone-900 dark:text-white">DC Circuit Controls</h3>
                  <p className="text-[11px] text-stone-500">Ohm's Law: V = I × R</p>
                </div>

                <div className="flex gap-2">
                  {(['single', 'series', 'parallel'] as const).map(t => (
                    <button
                      key={t}
                      onClick={() => setCircuitType(t)}
                      className={cn("flex-1 py-1.5 rounded border text-xs font-semibold capitalize", circuitType === t ? "bg-amber-600 text-white border-amber-600" : "border-stone-200 dark:border-zinc-800")}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between font-mono mb-1">
                      <span>Source Voltage (V):</span>
                      <span className="font-bold">{voltageV} V</span>
                    </div>
                    <input 
                      type="range" min={1} max={24} step={1}
                      value={voltageV} onChange={(e) => setVoltageV(parseInt(e.target.value, 10))}
                      className="w-full accent-amber-600"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between font-mono mb-1">
                      <span>Resistor 1 (R₁):</span>
                      <span className="font-bold">{resistanceR1} Ω</span>
                    </div>
                    <input 
                      type="range" min={1} max={30} step={1}
                      value={resistanceR1} onChange={(e) => setResistanceR1(parseInt(e.target.value, 10))}
                      className="w-full accent-amber-600"
                    />
                  </div>

                  {circuitType !== 'single' && (
                    <div>
                      <div className="flex justify-between font-mono mb-1">
                        <span>Resistor 2 (R₂):</span>
                        <span className="font-bold">{resistanceR2} Ω</span>
                      </div>
                      <input 
                        type="range" min={1} max={30} step={1}
                        value={resistanceR2} onChange={(e) => setResistanceR2(parseInt(e.target.value, 10))}
                        className="w-full accent-amber-600"
                      />
                    </div>
                  )}

                  <button
                    onClick={() => setCircuitSwitch(!circuitSwitch)}
                    className={cn(
                      "w-full py-2 rounded font-bold text-xs transition-colors",
                      circuitSwitch ? "bg-emerald-600 text-white hover:bg-emerald-700" : "bg-red-600 text-white hover:bg-red-700"
                    )}
                  >
                    Switch: {circuitSwitch ? 'CLOSED (Conducting)' : 'OPEN (Circuit Broken)'}
                  </button>
                </div>

                {/* Circuit Results */}
                {(() => {
                  let req = resistanceR1;
                  if (circuitType === 'series') req = resistanceR1 + resistanceR2;
                  if (circuitType === 'parallel') req = (resistanceR1 * resistanceR2) / (resistanceR1 + resistanceR2);
                  const current = circuitSwitch ? (voltageV / req) : 0;
                  const power = current * voltageV;
                  return (
                    <div className="p-3 bg-stone-50 dark:bg-zinc-950 rounded-lg border border-stone-200 dark:border-zinc-800 font-mono text-[11px] space-y-1">
                      <div>Equivalent Resistance (Req): <span className="font-bold">{Math.round(req * 100) / 100} Ω</span></div>
                      <div>Total Current (I): <span className="font-bold text-amber-600">{Math.round(current * 100) / 100} A</span></div>
                      <div>Dissipated Power (P): <span className="font-bold">{Math.round(power * 10) / 10} W</span></div>
                    </div>
                  );
                })()}
              </div>
            )}

            {/* PARAMETERS FOR REFRACTION */}
            {activeSim === 'refraction' && (
              <div className="space-y-5">
                <div className="border-b border-stone-200 dark:border-zinc-800 pb-3">
                  <h3 className="font-bold text-sm text-stone-900 dark:text-white">Refraction Parameters</h3>
                  <p className="text-[11px] text-stone-500">n₁ sin(θ₁) = n₂ sin(θ₂)</p>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <div className="flex justify-between font-mono mb-1">
                      <span>Angle of Incidence (θ₁):</span>
                      <span className="font-bold">{incidentAngle}°</span>
                    </div>
                    <input 
                      type="range" min={0} max={85} step={1}
                      value={incidentAngle} onChange={(e) => setIncidentAngle(parseInt(e.target.value, 10))}
                      className="w-full accent-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 dark:text-zinc-300 mb-1">Medium 2 Material</label>
                    <select
                      value={n2}
                      onChange={(e) => setN2(parseFloat(e.target.value))}
                      className="w-full px-3 py-1.5 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded text-xs text-stone-900 dark:text-white"
                    >
                      <option value={1.33}>Water (n = 1.33)</option>
                      <option value={1.52}>Crown Glass (n = 1.52)</option>
                      <option value={1.66}>Flint Glass (n = 1.66)</option>
                      <option value={2.42}>Diamond (n = 2.42)</option>
                    </select>
                  </div>
                </div>

                {/* Mathematical Readout */}
                {(() => {
                  const theta1Rad = (incidentAngle * Math.PI) / 180;
                  const sinTheta2 = (n1 / n2) * Math.sin(theta1Rad);
                  const isTIR = sinTheta2 > 1;
                  const theta2Deg = isTIR ? 0 : Math.round((Math.asin(sinTheta2) * 180 / Math.PI) * 10) / 10;
                  return (
                    <div className="p-3 bg-stone-50 dark:bg-zinc-950 rounded-lg border border-stone-200 dark:border-zinc-800 font-mono text-[11px] space-y-1">
                      <div>Angle of Refraction (θ₂): <span className="font-bold text-emerald-600">{isTIR ? 'TIR (Reflected)' : `${theta2Deg}°`}</span></div>
                      <div>Speed of Light in Med 2: <span className="font-bold">~{Math.round((3e8 / n2) / 1e6)} × 10⁶ m/s</span></div>
                    </div>
                  );
                })()}
              </div>
            )}

            <button 
              onClick={() => setActiveSim(null)}
              className="w-full py-2 bg-stone-100 dark:bg-zinc-800 hover:bg-stone-200 dark:hover:bg-zinc-700 text-stone-700 dark:text-zinc-300 rounded text-xs font-semibold transition-colors"
            >
              Exit to Experiments Catalog
            </button>
          </div>

        </div>
      )}

    </div>
  );
}

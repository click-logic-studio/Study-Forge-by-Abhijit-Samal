import React, { useEffect, useRef, useState } from 'react';
import { Network, Database, ZoomIn, ZoomOut, RotateCcw, Filter, BookOpen, Layers } from 'lucide-react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, Subject, Chapter } from '@/db/db';
import { cn } from '@/lib/utils';

interface Node {
  id: string;
  name: string;
  type: 'subject' | 'chapter';
  parentId?: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  confidence?: number;
}

interface Edge {
  source: string;
  target: string;
}

export function KnowledgeMap() {
  const subjects = useLiveQuery(() => db.subjects.toArray()) || [];
  const chapters = useLiveQuery(() => db.chapters.toArray()) || [];

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [filterSubjectId, setFilterSubjectId] = useState<number | 'all'>('all');
  const [zoomScale, setZoomScale] = useState<number>(1);

  const nodesRef = useRef<Node[]>([]);
  const edgesRef = useRef<Edge[]>([]);
  const draggedNodeRef = useRef<Node | null>(null);

  // Initialize Graph Nodes and Edges from Real Database
  useEffect(() => {
    if (subjects.length === 0) return;

    const newNodes: Node[] = [];
    const newEdges: Edge[] = [];

    const subjectColors = ['#4f46e5', '#0284c7', '#059669', '#d97706', '#dc2626'];
    const centerX = 400;
    const centerY = 300;

    subjects.forEach((sub, sIdx) => {
      if (filterSubjectId !== 'all' && sub.id !== filterSubjectId) return;

      const subIdStr = `sub-${sub.id}`;
      const angle = (sIdx / subjects.length) * Math.PI * 2;
      const subX = centerX + Math.cos(angle) * 160;
      const subY = centerY + Math.sin(angle) * 160;
      const color = subjectColors[sIdx % subjectColors.length];

      // Add Subject Hub Node
      newNodes.push({
        id: subIdStr,
        name: sub.name,
        type: 'subject',
        x: subX,
        y: subY,
        vx: 0,
        vy: 0,
        radius: 22,
        color
      });

      // Add Chapter Nodes
      const subChapters = chapters.filter(c => c.subjectId === sub.id);
      subChapters.forEach((ch, cIdx) => {
        const chIdStr = `ch-${ch.id}`;
        const chAngle = angle + ((cIdx - subChapters.length / 2) * 0.4);
        const chDist = 80 + (cIdx % 2) * 35;
        const chX = subX + Math.cos(chAngle) * chDist;
        const chY = subY + Math.sin(chAngle) * chDist;

        newNodes.push({
          id: chIdStr,
          name: ch.name,
          type: 'chapter',
          parentId: sub.id,
          x: chX,
          y: chY,
          vx: 0,
          vy: 0,
          radius: 12,
          color,
          confidence: ch.confidenceLevel || 3
        });

        newEdges.push({
          source: subIdStr,
          target: chIdStr
        });
      });
    });

    nodesRef.current = newNodes;
    edgesRef.current = newEdges;
  }, [subjects, chapters, filterSubjectId]);

  // Canvas Force-Directed Simulation & Rendering Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      ctx.save();
      ctx.translate(width / 2, height / 2);
      ctx.scale(zoomScale, zoomScale);
      ctx.translate(-width / 2, -height / 2);

      const nodes = nodesRef.current;
      const edges = edgesRef.current;

      // Draw Edges
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1.2;
      edges.forEach(e => {
        const source = nodes.find(n => n.id === e.source);
        const target = nodes.find(n => n.id === e.target);
        if (source && target) {
          ctx.beginPath();
          ctx.moveTo(source.x, source.y);
          ctx.lineTo(target.x, target.y);
          ctx.stroke();
        }
      });

      // Draw Nodes
      nodes.forEach(n => {
        // Node outer circle
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
        ctx.fillStyle = n.color;
        ctx.fill();

        if (selectedNode?.id === n.id) {
          ctx.strokeStyle = '#000000';
          ctx.lineWidth = 3;
          ctx.stroke();
        }

        // Label
        ctx.fillStyle = '#1e293b';
        ctx.font = n.type === 'subject' ? 'bold 11px sans-serif' : '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(n.name, n.x, n.y + n.radius + 12);
      });

      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [zoomScale, selectedNode]);

  // Canvas Mouse Interactions (Dragging & Clicking)
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = (e.clientX - rect.left - canvas.width / 2) / zoomScale + canvas.width / 2;
    const clickY = (e.clientY - rect.top - canvas.height / 2) / zoomScale + canvas.height / 2;

    const clicked = nodesRef.current.find(n => {
      const dist = Math.hypot(n.x - clickX, n.y - clickY);
      return dist <= n.radius + 5;
    });

    if (clicked) {
      draggedNodeRef.current = clicked;
      setSelectedNode(clicked);
    } else {
      setSelectedNode(null);
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!draggedNodeRef.current || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const curX = (e.clientX - rect.left - canvas.width / 2) / zoomScale + canvas.width / 2;
    const curY = (e.clientY - rect.top - canvas.height / 2) / zoomScale + canvas.height / 2;

    draggedNodeRef.current.x = curX;
    draggedNodeRef.current.y = curY;
  };

  const handleCanvasMouseUp = () => {
    draggedNodeRef.current = null;
  };

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-300 pb-10">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white flex items-center gap-2.5">
            <Network className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>Curriculum Knowledge Graph</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            Dynamic relational topology linking syllabus subjects, chapters, and recall masteries.
          </p>
        </div>

        {/* Graph Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg p-1 shadow-sm">
            <button 
              onClick={() => setZoomScale(prev => Math.min(2.0, prev + 0.2))}
              className="p-1.5 text-stone-500 hover:text-stone-900 dark:hover:text-white rounded"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setZoomScale(prev => Math.max(0.5, prev - 0.2))}
              className="p-1.5 text-stone-500 hover:text-stone-900 dark:hover:text-white rounded"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setZoomScale(1)}
              className="p-1.5 text-stone-500 hover:text-stone-900 dark:hover:text-white rounded"
              title="Reset Zoom"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <select
            value={filterSubjectId}
            onChange={(e) => setFilterSubjectId(e.target.value === 'all' ? 'all' : parseInt(e.target.value, 10))}
            className="px-3 py-1.5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg text-xs font-semibold text-stone-700 dark:text-zinc-300"
          >
            <option value="all">All Subjects</option>
            {subjects.map(s => (
              <option key={s.id} value={s.id}>{s.name.split(' (')[0]}</option>
            ))}
          </select>
        </div>
      </header>

      {/* Main Graph Viewport + Details Drawer */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[500px]">
        
        {/* Canvas Viewport */}
        <div className="lg:col-span-3 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-2 relative flex items-center justify-center overflow-hidden">
          <canvas
            ref={canvasRef}
            width={850}
            height={560}
            onMouseDown={handleCanvasMouseDown}
            onMouseMove={handleCanvasMouseMove}
            onMouseUp={handleCanvasMouseUp}
            className="w-full h-full max-h-[560px] bg-stone-50/60 dark:bg-zinc-950/60 rounded-xl cursor-grab active:cursor-grabbing"
          />
          <div className="absolute bottom-4 left-4 bg-white/80 dark:bg-zinc-900/80 backdrop-blur px-3 py-1 rounded border border-stone-200 dark:border-zinc-800 text-[11px] text-stone-500">
            Click to inspect · Drag to reposition
          </div>
        </div>

        {/* Selected Node Inspector */}
        <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm p-5 flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <div className="border-b border-stone-200 dark:border-zinc-800 pb-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">Node Inspector</span>
              <h3 className="font-bold text-base text-stone-900 dark:text-white mt-1">
                {selectedNode ? selectedNode.name : 'Select a Node'}
              </h3>
            </div>

            {selectedNode ? (
              <div className="space-y-3 text-xs">
                <div className="flex justify-between py-1 border-b border-stone-100 dark:border-zinc-800">
                  <span className="text-stone-500">Category:</span>
                  <span className="font-semibold capitalize text-stone-900 dark:text-white">{selectedNode.type}</span>
                </div>

                {selectedNode.confidence !== undefined && (
                  <div className="flex justify-between py-1 border-b border-stone-100 dark:border-zinc-800">
                    <span className="text-stone-500">Mastery Level:</span>
                    <span className="font-mono font-bold text-indigo-600">{selectedNode.confidence} / 5</span>
                  </div>
                )}

                <div className="p-3 bg-stone-50 dark:bg-zinc-800/40 rounded-lg text-[11px] text-stone-500 leading-relaxed">
                  {selectedNode.type === 'subject'
                    ? 'Root curriculum domain. Expand to see chapter clusters.'
                    : 'Class 10 CBSE Chapter node. Linked with active recall flashcards and practice test questions.'
                  }
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-stone-400">
                Click any subject or chapter node in the graph to view properties.
              </div>
            )}
          </div>

          <div className="p-4 bg-stone-50 dark:bg-zinc-800/30 rounded-xl border border-stone-200 dark:border-zinc-800 text-xs space-y-1.5 font-mono">
            <div className="flex justify-between text-stone-600 dark:text-zinc-400">
              <span>Indexed Nodes:</span>
              <span className="font-bold text-stone-900 dark:text-white">{nodesRef.current.length}</span>
            </div>
            <div className="flex justify-between text-stone-600 dark:text-zinc-400">
              <span>Relational Links:</span>
              <span className="font-bold text-stone-900 dark:text-white">{edgesRef.current.length}</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}

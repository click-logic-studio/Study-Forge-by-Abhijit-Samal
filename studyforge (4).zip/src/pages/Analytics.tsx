import React, { useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { 
  BarChart as BarChartIcon, TrendingUp, Clock, Target, Calendar,
  PieChart as PieChartIcon, Activity, ChevronDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, subDays, startOfDay, isAfter } from 'date-fns';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, 
  ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';

export function Analytics() {
  const sessions = useLiveQuery(() => db.studySessions.toArray());
  const goals = useLiveQuery(() => db.goals.toArray());
  const subjects = useLiveQuery(() => db.subjects.toArray());

  // Aggregate Data
  const { totalMins, weeklyMins, chartData, subjectData, completedGoals, activeGoals } = useMemo(() => {
    if (!sessions || !goals || !subjects) return { totalMins: 0, weeklyMins: 0, chartData: [], subjectData: [], completedGoals: 0, activeGoals: 0 };

    let total = 0;
    const now = new Date();
    const oneWeekAgo = startOfDay(subDays(now, 7));
    let weekly = 0;

    // Daily distribution (last 7 days)
    const dailyMap = new Map();
    for (let i = 6; i >= 0; i--) {
      dailyMap.set(format(subDays(now, i), 'MMM d'), 0);
    }

    // Subject distribution
    const subjMap = new Map();

    sessions.forEach(s => {
      total += s.durationMinutes;
      if (isAfter(s.startTime, oneWeekAgo)) {
        weekly += s.durationMinutes;
        const dayKey = format(s.startTime, 'MMM d');
        if (dailyMap.has(dayKey)) {
          dailyMap.set(dayKey, dailyMap.get(dayKey) + s.durationMinutes);
        }
      }
      
      const subj = subjects.find(sub => sub.id === s.subjectId);
      const subjName = subj?.name || 'Unknown';
      const subjColor = subj?.color || '#cbd5e1';
      
      if (!subjMap.has(subjName)) {
        subjMap.set(subjName, { name: subjName, value: 0, color: subjColor });
      }
      subjMap.get(subjName).value += s.durationMinutes;
    });

    const cData = Array.from(dailyMap.entries()).map(([date, mins]) => ({
      date,
      hours: +(mins / 60).toFixed(1)
    }));

    const sData = Array.from(subjMap.values()).sort((a, b) => b.value - a.value);

    const compGoals = goals.filter(g => g.completed).length;
    const actGoals = goals.length - compGoals;

    return { totalMins: total, weeklyMins: weekly, chartData: cData, subjectData: sData, completedGoals: compGoals, activeGoals: actGoals };
  }, [sessions, goals, subjects]);

  const totalHours = Math.floor(totalMins / 60);
  const weeklyHours = Math.floor(weeklyMins / 60);

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-500 pb-10">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Analytics & Insights</h1>
          <p className="text-sm text-stone-500 dark:text-zinc-400 mt-1">
            Track your study habits, identify weak points, and measure performance.
          </p>
        </div>
        <div className="flex items-center gap-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-md p-1 shadow-sm">
          <button className="px-3 py-1.5 bg-stone-100 dark:bg-zinc-800 text-stone-900 dark:text-white rounded text-sm font-medium">Last 7 Days</button>
          <button className="px-3 py-1.5 text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800 rounded text-sm font-medium transition-colors">30 Days</button>
          <button className="px-3 py-1.5 text-stone-600 dark:text-zinc-400 hover:bg-stone-50 dark:hover:bg-zinc-800 rounded text-sm font-medium transition-colors">All Time</button>
        </div>
      </header>

      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 shrink-0">
        <KpiCard icon={Clock} title="Total Study Time" value={`${totalHours}h ${totalMins % 60}m`} sub="All time" color="blue" />
        <KpiCard icon={Activity} title="Weekly Focus" value={`${weeklyHours}h ${weeklyMins % 60}m`} sub="Past 7 days" color="indigo" />
        <KpiCard icon={Target} title="Goals Completed" value={completedGoals.toString()} sub={`${activeGoals} active`} color="emerald" />
        <KpiCard icon={TrendingUp} title="Current Streak" value="3 Days" sub="Personal best: 14" color="orange" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col p-5">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-sm font-semibold text-stone-900 dark:text-white flex items-center gap-2">
              <BarChartIcon className="w-4 h-4 text-indigo-500" /> Study Time Distribution
            </h2>
          </div>
          <div className="flex-1 min-h-[300px]">
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#64748b', fontSize: 12 }} 
                    dy={10} 
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#64748b', fontSize: 12 }} 
                  />
                  <RechartsTooltip 
                    cursor={{ fill: 'rgba(99, 102, 241, 0.05)' }}
                    contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="hours" fill="#6366f1" radius={[4, 4, 0, 0]} maxBarSize={50} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-stone-400">No data for selected period</div>
            )}
          </div>
        </div>

        {/* Breakdown Panel */}
        <div className="flex flex-col gap-6">
          
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg shadow-sm flex flex-col p-5 flex-1">
            <h2 className="text-sm font-semibold text-stone-900 dark:text-white flex items-center gap-2 mb-4">
              <PieChartIcon className="w-4 h-4 text-purple-500" /> Subject Breakdown
            </h2>
            <div className="flex-1 min-h-[200px] flex items-center justify-center relative">
              {subjectData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={subjectData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {subjectData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <RechartsTooltip 
                      formatter={(value: number) => [`${Math.floor(value/60)}h ${value%60}m`, 'Time']}
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-stone-400 text-sm">No subject data</div>
              )}
            </div>
            
            <div className="mt-4 space-y-3 max-h-40 overflow-y-auto custom-scrollbar">
              {subjectData.map((s, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }}></div>
                    <span className="text-stone-700 dark:text-zinc-300 truncate max-w-[120px]">{s.name}</span>
                  </div>
                  <span className="font-medium text-stone-900 dark:text-white">{Math.floor(s.value/60)}h {s.value%60}m</span>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

function KpiCard({ icon: Icon, title, value, sub, color }: any) {
  const colors: Record<string, string> = {
    blue: "text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-900/20",
    indigo: "text-indigo-600 bg-indigo-50 dark:text-indigo-400 dark:bg-indigo-900/20",
    emerald: "text-emerald-600 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-900/20",
    orange: "text-orange-600 bg-orange-50 dark:text-orange-400 dark:bg-orange-900/20",
  };

  return (
    <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-lg p-5 shadow-sm flex items-center gap-4">
      <div className={cn("p-3 rounded-xl shrink-0", colors[color])}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <p className="text-xs font-medium text-stone-500 dark:text-zinc-400 uppercase tracking-wide mb-1">{title}</p>
        <p className="text-2xl font-bold text-stone-900 dark:text-white leading-none mb-1">{value}</p>
        <p className="text-xs text-stone-500 dark:text-zinc-500">{sub}</p>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, seedClass10Curriculum } from '@/db/db';
import { useUIStore } from '@/store/uiStore';
import { 
  User, Palette, Zap, BookOpen, HardDrive, 
  FolderArchive, Bell, Eye, Command, Lock, 
  Download, Trash2, Cpu, Check, AlertTriangle, 
  RotateCcw, RefreshCw, Upload, ShieldCheck, FileSpreadsheet
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { createFullBackup, parseAndValidateBackupFile, restoreBackup, exportAnalyticsCSV, BackupData } from '@/lib/backupService';

type SettingsSection = 
  | 'general' 
  | 'appearance' 
  | 'performance' 
  | 'curriculum' 
  | 'storage' 
  | 'library' 
  | 'notifications' 
  | 'accessibility' 
  | 'shortcuts' 
  | 'privacy' 
  | 'backup' 
  | 'data' 
  | 'advanced';

const SECTIONS = [
  { id: 'general', label: 'General', icon: User },
  { id: 'appearance', label: 'Appearance', icon: Palette },
  { id: 'performance', label: 'Performance', icon: Zap },
  { id: 'curriculum', label: 'Curriculum', icon: BookOpen },
  { id: 'storage', label: 'Storage', icon: HardDrive },
  { id: 'library', label: 'Library', icon: FolderArchive },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'accessibility', label: 'Accessibility', icon: Eye },
  { id: 'shortcuts', label: 'Keyboard Shortcuts', icon: Command },
  { id: 'privacy', label: 'Privacy', icon: Lock },
  { id: 'backup', label: 'Backup & Restore', icon: Download },
  { id: 'data', label: 'Data Management', icon: Trash2 },
  { id: 'advanced', label: 'Advanced', icon: Cpu },
] as const;

export function Settings() {
  const profile = useLiveQuery(() => db.profile.get(1));
  const { performanceMode, setPerformanceMode, askConfirmation } = useUIStore();
  const [activeSection, setActiveSection] = useState<SettingsSection>('general');

  // Form states
  const [name, setName] = useState('');
  const [nickname, setNickname] = useState('');
  const [theme, setTheme] = useState('Paper');
  const [examName, setExamName] = useState('Class 10 CBSE Board Examination');
  const [examDate, setExamDate] = useState('2026-03-01');
  const [targetDailyMinutes, setTargetDailyMinutes] = useState(120);

  // Backup & Restore states
  const [backupPending, setBackupPending] = useState<BackupData | null>(null);
  const [restoreMode, setRestoreMode] = useState<'merge' | 'replace'>('merge');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Storage estimation
  const [storageEstimate, setStorageEstimate] = useState<{ usedMB: number; quotaMB: number }>({ usedMB: 0, quotaMB: 0 });

  useEffect(() => {
    if (profile) {
      setName(profile.name || '');
      setNickname(profile.nickname || '');
      setTheme(profile.theme || 'Paper');
      if (profile.examName) setExamName(profile.examName);
      if (profile.examDate) setExamDate(profile.examDate);
      if (profile.targetDailyMinutes) setTargetDailyMinutes(profile.targetDailyMinutes);
    }
  }, [profile]);

  useEffect(() => {
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(est => {
        setStorageEstimate({
          usedMB: Math.round(((est.usage || 0) / (1024 * 1024)) * 10) / 10,
          quotaMB: Math.round(((est.quota || 0) / (1024 * 1024)) * 10) / 10
        });
      }).catch(() => {});
    }
  }, []);

  const handleSaveProfile = async () => {
    if (!profile) return;
    await db.profile.update(1, {
      name,
      nickname,
      examName,
      examDate,
      targetDailyMinutes,
      theme
    });
    showSuccess('Profile preferences saved successfully.');
  };

  const handleUpdatePerformance = async (enabled: boolean) => {
    setPerformanceMode(enabled);
    if (profile) {
      await db.profile.update(1, { performanceMode: enabled });
    }
    showSuccess(`Performance Mode ${enabled ? 'enabled' : 'disabled'}.`);
  };

  const showSuccess = (msg: string) => {
    setStatusMessage({ type: 'success', text: msg });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const showError = (msg: string) => {
    setStatusMessage({ type: 'error', text: msg });
    setTimeout(() => setStatusMessage(null), 5000);
  };

  const handleExportBackup = async () => {
    try {
      const { filename, counts } = await createFullBackup();
      showSuccess(`Backup exported to ${filename} with ${Object.values(counts).reduce((a, b) => a + b, 0)} total records.`);
    } catch (e: any) {
      showError(`Backup failed: ${e?.message || 'Unknown error'}`);
    }
  };

  const handleBackupFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const result = await parseAndValidateBackupFile(file);
    if (!result.isValid || !result.backup) {
      showError(result.error || 'Invalid backup file.');
      return;
    }

    setBackupPending(result.backup);
  };

  const handleExecuteRestore = async () => {
    if (!backupPending) return;
    try {
      const { restoredCounts } = await restoreBackup(backupPending, restoreMode);
      setBackupPending(null);
      showSuccess(`Successfully restored data (${Object.values(restoredCounts).reduce((a, b) => a + b, 0)} records restored).`);
      setTimeout(() => window.location.reload(), 1500);
    } catch (e: any) {
      showError(`Restore failed: ${e?.message || 'Transaction aborted'}`);
    }
  };

  const handleReSeedCurriculum = () => {
    askConfirmation({
      title: 'Reload Class 10 Curriculum',
      message: 'This will load the official Class 10 CBSE/NCERT subjects and chapters. Existing notes and tasks will remain safe. Proceed?',
      confirmLabel: 'Load Curriculum',
      onConfirm: async () => {
        await seedClass10Curriculum(true);
        showSuccess('Class 10 CBSE/NCERT curriculum loaded successfully.');
      }
    });
  };

  const handleFactoryReset = () => {
    askConfirmation({
      title: 'Factory Reset StudyForge',
      message: 'WARNING: This permanently removes all local databases, sessions, notes, tasks, flashcards, and files. Are you sure you want to proceed?',
      confirmLabel: 'Reset All Data',
      isDestructive: true,
      onConfirm: async () => {
        await db.delete();
        window.location.reload();
      }
    });
  };

  return (
    <div className="flex flex-col h-full w-full max-w-[1500px] mx-auto animate-in fade-in duration-300 pb-12">
      
      {/* Top Section Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">Settings Center</h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            Configure local environment preferences, low-hardware performance profiles, and database integrity.
          </p>
        </div>

        {statusMessage && (
          <div className={cn(
            "px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-2 animate-in fade-in",
            statusMessage.type === 'success' 
              ? "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800"
              : "bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800"
          )}>
            {statusMessage.type === 'success' ? <Check className="w-3.5 h-3.5" /> : <AlertTriangle className="w-3.5 h-3.5" />}
            <span>{statusMessage.text}</span>
          </div>
        )}
      </header>

      {/* Main Settings Grid: Left Sidebar Navigation + Right Content Panel */}
      <div className="flex-1 flex flex-col md:flex-row gap-6 min-h-0 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl shadow-sm overflow-hidden">
        
        {/* Navigation Tabs */}
        <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-stone-200 dark:border-zinc-800 bg-stone-50/50 dark:bg-zinc-950/40 p-3 shrink-0 overflow-y-auto custom-scrollbar">
          <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400 dark:text-zinc-500 px-3 py-2">
            System Preferences
          </div>
          <nav className="space-y-0.5">
            {SECTIONS.map((sec) => {
              const Icon = sec.icon;
              const isActive = activeSection === sec.id;
              return (
                <button
                  key={sec.id}
                  onClick={() => setActiveSection(sec.id as SettingsSection)}
                  className={cn(
                    "w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium transition-colors text-left",
                    isActive 
                      ? "bg-white dark:bg-zinc-800 text-stone-900 dark:text-white shadow-sm border border-stone-200/80 dark:border-zinc-700" 
                      : "text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800/60 hover:text-stone-900 dark:hover:text-zinc-200"
                  )}
                >
                  <Icon className={cn("w-4 h-4 shrink-0", isActive ? "text-indigo-600 dark:text-indigo-400" : "text-stone-400")} />
                  <span>{sec.label}</span>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Content Section Panel */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto custom-scrollbar">
          
          {/* SECTION 1: GENERAL */}
          {activeSection === 'general' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">General Profile & Exam Goals</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Academic identification and milestone parameters.
                </p>
              </div>

              <div className="space-y-4 pt-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1.5">Full Name</label>
                    <input 
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1.5">Preferred Alias</label>
                    <input 
                      type="text"
                      value={nickname}
                      onChange={(e) => setNickname(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1.5">Target Examination</label>
                  <input 
                    type="text"
                    value={examName}
                    onChange={(e) => setExamName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1.5">Exam Target Date</label>
                    <input 
                      type="date"
                      value={examDate}
                      onChange={(e) => setExamDate(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1.5">Daily Study Target (Minutes)</label>
                    <input 
                      type="number"
                      min={15}
                      max={720}
                      step={15}
                      value={targetDailyMinutes}
                      onChange={(e) => setTargetDailyMinutes(parseInt(e.target.value, 10) || 60)}
                      className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded-md text-xs text-stone-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200 dark:border-zinc-800 flex justify-end">
                  <button 
                    onClick={handleSaveProfile}
                    className="px-4 py-2 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md text-xs font-semibold hover:opacity-90 transition-opacity"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: APPEARANCE */}
          {activeSection === 'appearance' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Workspace Appearance</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Select a theme designed for long study sessions with balanced contrast.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {[
                  { id: 'Paper', title: 'Paper Light', desc: 'Warm ivory canvas with crisp dark slate ink' },
                  { id: 'Forge Dark', title: 'Forge Dark', desc: 'Deep zinc surfaces with minimal eye fatigue' },
                  { id: 'Midnight', title: 'Midnight Navy', desc: 'Subdued oceanic slate for late-night focus' },
                  { id: 'Arctic', title: 'Arctic Clean', desc: 'Ultra-pure minimal white aesthetic' },
                ].map((th) => (
                  <button
                    key={th.id}
                    onClick={async () => {
                      setTheme(th.id);
                      if (profile) await db.profile.update(1, { theme: th.id });
                    }}
                    className={cn(
                      "p-4 rounded-lg border text-left transition-all",
                      theme === th.id
                        ? "border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/30 text-stone-900 dark:text-white ring-1 ring-indigo-500"
                        : "border-stone-200 dark:border-zinc-800 hover:bg-stone-50 dark:hover:bg-zinc-800/40 text-stone-700 dark:text-zinc-300"
                    )}
                  >
                    <div className="font-bold text-xs">{th.title}</div>
                    <p className="text-[11px] text-stone-500 dark:text-zinc-400 mt-1">{th.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* SECTION 3: PERFORMANCE MODE (Item 30 specific requirement) */}
          {activeSection === 'performance' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Hardware & Performance Mode</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Engineered specifically for low-end hardware (e.g., Core 2 Duo, 3 GB RAM, integrated graphics).
                </p>
              </div>

              {/* Master Performance Switch */}
              <div className="p-4 bg-stone-50 dark:bg-zinc-800/40 border border-stone-200 dark:border-zinc-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm text-stone-900 dark:text-white flex items-center gap-2">
                    <Zap className={cn("w-4 h-4", performanceMode ? "text-amber-500" : "text-stone-400")} />
                    <span>Performance Mode</span>
                  </div>
                  <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1 max-w-md">
                    Drastically decreases CPU/GPU load by clamping animations, capping 3D rendering to 1× DPR, and avoiding background re-renders.
                  </p>
                </div>
                <button
                  onClick={() => handleUpdatePerformance(!performanceMode)}
                  className={cn(
                    "px-4 py-2 rounded-md text-xs font-bold uppercase tracking-wider transition-colors",
                    performanceMode 
                      ? "bg-amber-600 text-white hover:bg-amber-700" 
                      : "bg-stone-200 dark:bg-zinc-700 text-stone-700 dark:text-zinc-300 hover:bg-stone-300"
                  )}
                >
                  {performanceMode ? 'Active' : 'Off'}
                </button>
              </div>

              {/* Performance Reductions Breakdown */}
              <div className="border border-stone-200 dark:border-zinc-800 rounded-lg overflow-hidden">
                <div className="px-4 py-2 bg-stone-100 dark:bg-zinc-800 text-[10px] font-bold uppercase tracking-wider text-stone-500">
                  Performance Mode Subsystem Reductions
                </div>
                <div className="divide-y divide-stone-100 dark:divide-zinc-800/60 text-xs">
                  <div className="px-4 py-3 flex items-start justify-between gap-4">
                    <div>
                      <div className="font-semibold text-stone-900 dark:text-white">CSS Transitions & Keyframes</div>
                      <p className="text-[11px] text-stone-500">Suppresses non-essential layout and slide-in animations.</p>
                    </div>
                    <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400 font-bold shrink-0">
                      {performanceMode ? 'Disabled' : 'Enabled'}
                    </span>
                  </div>
                  <div className="px-4 py-3 flex items-start justify-between gap-4">
                    <div>
                      <div className="font-semibold text-stone-900 dark:text-white">Canvas & WebGL Pixel Ratio</div>
                      <p className="text-[11px] text-stone-500">Capped at 1.0 DPR instead of high-density retina (preserves VRAM).</p>
                    </div>
                    <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400 font-bold shrink-0">
                      {performanceMode ? '1.0x Fixed' : 'Native Device Ratio'}
                    </span>
                  </div>
                  <div className="px-4 py-3 flex items-start justify-between gap-4">
                    <div>
                      <div className="font-semibold text-stone-900 dark:text-white">Background PDF Pre-indexing</div>
                      <p className="text-[11px] text-stone-500">Limits document indexing to active pages to keep heap &lt; 80MB.</p>
                    </div>
                    <span className="font-mono text-[10px] text-emerald-600 dark:text-emerald-400 font-bold shrink-0">
                      {performanceMode ? 'Throttled' : 'Standard'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 4: CURRICULUM */}
          {activeSection === 'curriculum' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Curriculum Management</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Class 10 CBSE/NCERT syllabus standard database integration.
                </p>
              </div>

              <div className="p-4 bg-stone-50 dark:bg-zinc-800/40 border border-stone-200 dark:border-zinc-800 rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-xs text-stone-900 dark:text-white">Official Class 10 CBSE/NCERT Package</h3>
                    <p className="text-[11px] text-stone-500">Physics, Chemistry, Biology, and Mathematics chapters with complete unit breakdowns.</p>
                  </div>
                  <button 
                    onClick={handleReSeedCurriculum}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold shadow-sm transition-colors"
                  >
                    Sync / Re-seed Syllabus
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 5: STORAGE */}
          {activeSection === 'storage' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Local Storage & IndexedDB</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Inspect persistent browser disk consumption and table statistics.
                </p>
              </div>

              <div className="p-4 border border-stone-200 dark:border-zinc-800 rounded-lg space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-stone-700 dark:text-zinc-300">Total Browser Allocation</span>
                  <span className="font-mono text-stone-500">{storageEstimate.usedMB} MB used / ~{storageEstimate.quotaMB} MB available</span>
                </div>
                <div className="w-full h-2 bg-stone-100 dark:bg-zinc-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-600 rounded-full"
                    style={{ width: `${Math.max(2, Math.min(100, (storageEstimate.usedMB / (storageEstimate.quotaMB || 1000)) * 100))}%` }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* SECTION 6: LIBRARY */}
          {activeSection === 'library' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Library Preferences</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Configure local file caching, document intelligence, and indexing options.
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center gap-3 p-3 border border-stone-200 dark:border-zinc-800 rounded-lg cursor-pointer hover:bg-stone-50 dark:hover:bg-zinc-800/40">
                  <input type="checkbox" defaultChecked className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-white block">Auto-extract local keywords</span>
                    <span className="text-stone-500 text-[11px]">Computes term frequency client-side upon opening new PDF documents.</span>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-3 border border-stone-200 dark:border-zinc-800 rounded-lg cursor-pointer hover:bg-stone-50 dark:hover:bg-zinc-800/40">
                  <input type="checkbox" defaultChecked className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-white block">Remember last-read position</span>
                    <span className="text-stone-500 text-[11px]">Automatically resumes documents at the exact page you last read.</span>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* SECTION 7: NOTIFICATIONS */}
          {activeSection === 'notifications' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Notification Alarms</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Local timer chimes and study streak notifications.
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center gap-3 p-3 border border-stone-200 dark:border-zinc-800 rounded-lg cursor-pointer hover:bg-stone-50 dark:hover:bg-zinc-800/40">
                  <input type="checkbox" defaultChecked className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-white block">Pomodoro Completion Chime</span>
                    <span className="text-stone-500 text-[11px]">Plays a subtle audio cue when a 25-minute focus session concludes.</span>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-3 border border-stone-200 dark:border-zinc-800 rounded-lg cursor-pointer hover:bg-stone-50 dark:hover:bg-zinc-800/40">
                  <input type="checkbox" defaultChecked className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-white block">Daily Study Target Reminder</span>
                    <span className="text-stone-500 text-[11px]">Alerts you when you are within 30 minutes of your daily goal.</span>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* SECTION 8: ACCESSIBILITY */}
          {activeSection === 'accessibility' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Accessibility & Motion</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Ensure comfortable interaction for all visual preferences and hardware constraints.
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <label className="flex items-center gap-3 p-3 border border-stone-200 dark:border-zinc-800 rounded-lg cursor-pointer hover:bg-stone-50 dark:hover:bg-zinc-800/40">
                  <input type="checkbox" defaultChecked={performanceMode} onChange={(e) => handleUpdatePerformance(e.target.checked)} className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-white block">Respect Reduced Motion</span>
                    <span className="text-stone-500 text-[11px]">Disables sliding animations, modal pop effects, and smooth scrolls.</span>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-3 border border-stone-200 dark:border-zinc-800 rounded-lg cursor-pointer hover:bg-stone-50 dark:hover:bg-zinc-800/40">
                  <input type="checkbox" className="rounded text-indigo-600 focus:ring-indigo-500" />
                  <div>
                    <span className="font-semibold text-stone-900 dark:text-white block">Enhanced High Contrast Outlines</span>
                    <span className="text-stone-500 text-[11px]">Forces 2px solid hairline boundaries around interactive elements and buttons.</span>
                  </div>
                </label>
              </div>
            </div>
          )}

          {/* SECTION 9: KEYBOARD SHORTCUTS */}
          {activeSection === 'shortcuts' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Keyboard Shortcuts</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  High-productivity keyboard shortcuts for desktop navigation.
                </p>
              </div>

              <div className="border border-stone-200 dark:border-zinc-800 rounded-lg overflow-hidden text-xs">
                <div className="divide-y divide-stone-100 dark:divide-zinc-800/60 font-mono">
                  {[
                    { key: 'Ctrl + K', action: 'Open Global Command Palette' },
                    { key: 'Ctrl + B', action: 'Toggle Navigation Sidebar' },
                    { key: 'Ctrl + F', action: 'Search Loaded PDF Document' },
                    { key: 'Space', action: 'Pause / Resume Active Focus Timer' },
                    { key: 'Esc', action: 'Close Active Modal or Drawer' },
                    { key: 'Ctrl + S', action: 'Quick-Save Active Note' }
                  ].map((s, idx) => (
                    <div key={idx} className="px-4 py-2.5 flex items-center justify-between">
                      <span className="font-sans text-stone-700 dark:text-zinc-300">{s.action}</span>
                      <kbd className="px-2 py-0.5 bg-stone-100 dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded text-[11px] text-stone-600 dark:text-zinc-300 shadow-sm">
                        {s.key}
                      </kbd>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* SECTION 10: PRIVACY */}
          {activeSection === 'privacy' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Privacy & Air-Gap Guarantee</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  StudyForge is built with zero-telemetry, zero-cloud architecture.
                </p>
              </div>

              <div className="p-4 bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 rounded-lg space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs text-emerald-800 dark:text-emerald-300">
                  <ShieldCheck className="w-4 h-4" />
                  <span>100% Client-Side Self-Contained</span>
                </div>
                <p className="text-[11px] text-emerald-900/80 dark:text-emerald-400 leading-relaxed">
                  Your notes, goals, PDF files, simulation data, and quiz attempts are permanently stored inside your device's browser IndexedDB container. No data packets or analytics are ever dispatched to external servers.
                </p>
              </div>
            </div>
          )}

          {/* SECTION 11: BACKUP & RESTORE (Item 32 specific requirement) */}
          {activeSection === 'backup' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Backup & Recovery Center</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Safely export or restore your academic records with structured safeguards.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Export Card */}
                <div className="p-5 border border-stone-200 dark:border-zinc-800 rounded-lg bg-stone-50/40 dark:bg-zinc-800/20 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="font-bold text-sm text-stone-900 dark:text-white">BACKUP STUDYFORGE DATA</h3>
                    <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
                      Exports all notes, goals, study sessions, flashcards, and curriculum progress into a verifiable JSON archive.
                    </p>
                  </div>
                  <button 
                    onClick={handleExportBackup}
                    className="w-full py-2 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md text-xs font-semibold hover:opacity-90 transition-opacity flex items-center justify-center gap-2 shadow-sm"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download JSON Backup</span>
                  </button>
                </div>

                {/* Import Card */}
                <div className="p-5 border border-stone-200 dark:border-zinc-800 rounded-lg bg-stone-50/40 dark:bg-zinc-800/20 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="font-bold text-sm text-stone-900 dark:text-white">RESTORE BACKUP</h3>
                    <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
                      Upload an existing StudyForge JSON backup. Includes integrity validation and preview before import.
                    </p>
                  </div>
                  <label className="w-full py-2 border border-stone-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-stone-50 dark:hover:bg-zinc-700 rounded-md text-xs font-semibold text-stone-900 dark:text-white flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-colors">
                    <Upload className="w-4 h-4" />
                    <span>Select Backup File</span>
                    <input type="file" accept=".json" onChange={handleBackupFileSelect} className="hidden" />
                  </label>
                </div>
              </div>

              {/* Restore Confirmation Safeguard Dialog */}
              {backupPending && (
                <div className="p-5 border border-indigo-200 dark:border-indigo-900/50 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-xl space-y-4 animate-in fade-in">
                  <div>
                    <h4 className="font-bold text-sm text-indigo-950 dark:text-indigo-200 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-indigo-600" />
                      <span>Review Backup Before Restoring</span>
                    </h4>
                    <p className="text-xs text-stone-600 dark:text-zinc-300 mt-1">
                      Archive created on {new Date(backupPending.timestamp).toLocaleString()} ({backupPending.appName})
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-2 font-mono text-[11px] bg-white dark:bg-zinc-900 p-3 rounded border border-indigo-100 dark:border-indigo-900/40">
                    <div>Subjects: <span className="font-bold">{backupPending.data.subjects?.length || 0}</span></div>
                    <div>Chapters: <span className="font-bold">{backupPending.data.chapters?.length || 0}</span></div>
                    <div>Notes: <span className="font-bold">{backupPending.data.notes?.length || 0}</span></div>
                    <div>Sessions: <span className="font-bold">{backupPending.data.studySessions?.length || 0}</span></div>
                    <div>Tasks: <span className="font-bold">{backupPending.data.tasks?.length || 0}</span></div>
                    <div>Flashcards: <span className="font-bold">{backupPending.data.flashcards?.length || 0}</span></div>
                  </div>

                  <div className="space-y-2 text-xs">
                    <span className="font-semibold text-stone-700 dark:text-zinc-300 block">Restore Strategy:</span>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="radio" 
                          name="mode" 
                          checked={restoreMode === 'merge'} 
                          onChange={() => setRestoreMode('merge')} 
                        />
                        <span>Merge (Safe: Keep existing items and append backup)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-amber-700 dark:text-amber-400">
                        <input 
                          type="radio" 
                          name="mode" 
                          checked={restoreMode === 'replace'} 
                          onChange={() => setRestoreMode('replace')} 
                        />
                        <span>Replace (Overwrite database with backup content)</span>
                      </label>
                    </div>
                  </div>

                  <div className="flex justify-end gap-3 pt-2">
                    <button 
                      onClick={() => setBackupPending(null)}
                      className="px-3 py-1.5 text-xs text-stone-600 dark:text-zinc-400 hover:text-stone-900"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleExecuteRestore}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold shadow-sm"
                    >
                      Confirm and Restore
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* SECTION 12: DATA MANAGEMENT */}
          {activeSection === 'data' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Data Management & CSV Export</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Export structured data or wipe individual caches safely.
                </p>
              </div>

              <div className="space-y-4">
                <div className="p-4 border border-stone-200 dark:border-zinc-800 rounded-lg flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-xs text-stone-900 dark:text-white">CSV Export of Analytics & Sessions</h3>
                    <p className="text-[11px] text-stone-500">Download formatted spreadsheet for review in Microsoft Excel or Google Sheets.</p>
                  </div>
                  <button 
                    onClick={exportAnalyticsCSV}
                    className="px-3 py-1.5 border border-stone-300 dark:border-zinc-700 rounded text-xs font-semibold hover:bg-stone-50 dark:hover:bg-zinc-800 flex items-center gap-1.5 text-stone-800 dark:text-zinc-200"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>Export CSV</span>
                  </button>
                </div>

                <div className="p-4 border border-red-200 dark:border-red-900/40 rounded-lg bg-red-50/20 dark:bg-red-950/10 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-xs text-red-900 dark:text-red-300">Factory Reset Database</h3>
                    <p className="text-[11px] text-stone-500">Permanently clears local database tables and starts fresh.</p>
                  </div>
                  <button 
                    onClick={handleFactoryReset}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-semibold"
                  >
                    Wipe Database
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 13: ADVANCED */}
          {activeSection === 'advanced' && (
            <div className="space-y-6 max-w-2xl">
              <div>
                <h2 className="text-base font-bold text-stone-900 dark:text-white">Advanced Diagnostic Controls</h2>
                <p className="text-xs text-stone-500 dark:text-zinc-400 mt-0.5">
                  Database schema versioning and client inverted index management.
                </p>
              </div>

              <div className="border border-stone-200 dark:border-zinc-800 rounded-lg overflow-hidden text-xs">
                <div className="divide-y divide-stone-100 dark:divide-zinc-800/60 font-mono">
                  <div className="px-4 py-3 flex justify-between">
                    <span className="font-sans text-stone-600 dark:text-zinc-400">Database Engine</span>
                    <span className="font-bold text-stone-900 dark:text-white">Dexie.js v4.4.6 (IndexedDB)</span>
                  </div>
                  <div className="px-4 py-3 flex justify-between">
                    <span className="font-sans text-stone-600 dark:text-zinc-400">Active Schema Version</span>
                    <span className="font-bold text-stone-900 dark:text-white">Version 5 (Air-Gapped)</span>
                  </div>
                  <div className="px-4 py-3 flex justify-between">
                    <span className="font-sans text-stone-600 dark:text-zinc-400">Build Standard</span>
                    <span className="font-bold text-stone-900 dark:text-white">Class 10 CBSE/NCERT Desktop OS</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

    </div>
  );
}

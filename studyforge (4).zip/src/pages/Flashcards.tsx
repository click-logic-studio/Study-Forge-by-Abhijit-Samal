import React, { useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, Deck, Flashcard } from '@/db/db';
import { useUIStore } from '@/store/uiStore';
import { 
  BrainCircuit, Play, Plus, Search, Filter, 
  Trash2, X, RotateCcw, Check, Sparkles, BookOpen
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function Flashcards() {
  const showToast = useUIStore((state) => state.showToast);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeDeck, setActiveDeck] = useState<Deck | null>(null);
  const [showCreateDeck, setShowCreateDeck] = useState(false);
  const [showAddCard, setShowAddCard] = useState(false);
  const [selectedDeckForNewCard, setSelectedDeckForNewCard] = useState<number | null>(null);

  // Form states
  const [newDeckName, setNewDeckName] = useState('');
  const [newCardFront, setNewCardFront] = useState('');
  const [newCardBack, setNewCardBack] = useState('');

  // Study Mode State
  const [studyCards, setStudyCards] = useState<Flashcard[]>([]);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  const decks = useLiveQuery(() => db.decks.toArray()) || [];
  const allCards = useLiveQuery(() => db.flashcards.toArray()) || [];

  const handleCreateDeck = async () => {
    if (!newDeckName.trim()) return;
    await db.decks.add({
      name: newDeckName.trim(),
      color: '#4f46e5',
      createdAt: Date.now()
    });
    setNewDeckName('');
    setShowCreateDeck(false);
  };

  const handleCreateCard = async () => {
    if (!newCardFront.trim() || !newCardBack.trim() || !selectedDeckForNewCard) return;
    await db.flashcards.add({
      deckId: selectedDeckForNewCard,
      front: newCardFront.trim(),
      back: newCardBack.trim(),
      nextReview: Date.now(),
      easeFactor: 2.5,
      interval: 1,
      repetitions: 0,
      createdAt: Date.now()
    });
    setNewCardFront('');
    setNewCardBack('');
    setShowAddCard(false);
  };

  const startStudyingDeck = async (deck: Deck) => {
    if (!deck.id) return;
    const cards = await db.flashcards.where('deckId').equals(deck.id).toArray();
    if (cards.length === 0) {
      showToast('This deck has no cards yet. Add cards first to start studying.', 'warning');
      return;
    }
    setActiveDeck(deck);
    setStudyCards(cards);
    setCurrentCardIndex(0);
    setIsFlipped(false);
  };

  const handleRateCard = async (rating: 'again' | 'hard' | 'good' | 'easy') => {
    const card = studyCards[currentCardIndex];
    if (!card || !card.id) return;

    let newInterval = card.interval || 1;
    let newEase = card.easeFactor || 2.5;

    if (rating === 'again') {
      newInterval = 1;
    } else if (rating === 'hard') {
      newInterval = Math.max(1, Math.round(newInterval * 1.2));
      newEase = Math.max(1.3, newEase - 0.15);
    } else if (rating === 'good') {
      newInterval = Math.round(newInterval * newEase);
    } else if (rating === 'easy') {
      newInterval = Math.round(newInterval * newEase * 1.3);
      newEase += 0.15;
    }

    const nextReviewTimestamp = Date.now() + (newInterval * 24 * 60 * 60 * 1000);

    await db.flashcards.update(card.id, {
      interval: newInterval,
      easeFactor: newEase,
      repetitions: (card.repetitions || 0) + 1,
      nextReview: nextReviewTimestamp
    });

    if (currentCardIndex < studyCards.length - 1) {
      setCurrentCardIndex(prev => prev + 1);
      setIsFlipped(false);
    } else {
      showToast('Deck review completed! Great work on active recall.', 'success');
      setActiveDeck(null);
    }
  };

  const filteredDecks = decks.filter(d => 
    d.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full w-full max-w-[1600px] mx-auto animate-in fade-in duration-300 pb-12">
      
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6 shrink-0">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white flex items-center gap-2.5">
            <BrainCircuit className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>Spaced Flashcards & Active Recall</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-zinc-400 mt-1">
            SuperMemo SM-2 spaced repetition memory engine for formula derivations and key concepts.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowCreateDeck(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-md text-xs font-semibold shadow-sm hover:opacity-90 transition-opacity"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Deck</span>
          </button>
        </div>
      </header>

      {/* MODAL: STUDY FLASHCARD RUNNER */}
      {activeDeck && studyCards.length > 0 && (
        <div className="fixed inset-0 z-50 bg-stone-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-2xl max-w-xl w-full p-6 sm:p-8 flex flex-col space-y-6 animate-in zoom-in-95 duration-150">
            
            <div className="flex items-center justify-between border-b border-stone-100 dark:border-zinc-800 pb-3">
              <span className="font-bold text-xs uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                {activeDeck.name} · Card {currentCardIndex + 1} of {studyCards.length}
              </span>
              <button 
                onClick={() => setActiveDeck(null)}
                className="p-1 rounded text-stone-400 hover:text-stone-700 dark:hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Flashcard Body */}
            <div 
              onClick={() => setIsFlipped(!isFlipped)}
              className="min-h-[220px] bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-800 rounded-xl p-6 flex flex-col items-center justify-center text-center cursor-pointer select-none transition-all shadow-inner hover:border-indigo-300 dark:hover:border-indigo-900"
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 mb-2 block">
                {isFlipped ? 'Answer / Solution' : 'Prompt / Question (Click to flip)'}
              </span>
              <div className="text-base sm:text-lg font-semibold text-stone-900 dark:text-white leading-relaxed whitespace-pre-line">
                {isFlipped ? studyCards[currentCardIndex]?.back : studyCards[currentCardIndex]?.front}
              </div>
            </div>

            {/* Controls */}
            {!isFlipped ? (
              <button
                onClick={() => setIsFlipped(true)}
                className="w-full py-2.5 bg-stone-900 dark:bg-white text-white dark:text-stone-900 rounded-lg text-xs font-bold uppercase tracking-wider hover:opacity-90"
              >
                Reveal Answer
              </button>
            ) : (
              <div className="grid grid-cols-4 gap-2 pt-2">
                <button
                  onClick={() => handleRateCard('again')}
                  className="py-2 rounded-lg bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-300 text-xs font-bold hover:opacity-90"
                >
                  Again (1d)
                </button>
                <button
                  onClick={() => handleRateCard('hard')}
                  className="py-2 rounded-lg bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 text-xs font-bold hover:opacity-90"
                >
                  Hard
                </button>
                <button
                  onClick={() => handleRateCard('good')}
                  className="py-2 rounded-lg bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 text-xs font-bold hover:opacity-90"
                >
                  Good
                </button>
                <button
                  onClick={() => handleRateCard('easy')}
                  className="py-2 rounded-lg bg-indigo-100 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 text-xs font-bold hover:opacity-90"
                >
                  Easy
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: CREATE DECK */}
      {showCreateDeck && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-xl max-w-sm w-full p-6 space-y-4">
            <h3 className="font-bold text-sm text-stone-900 dark:text-white">Create Active Recall Deck</h3>
            <input 
              type="text"
              placeholder="e.g. Mathematics Formula Sheet"
              value={newDeckName}
              onChange={(e) => setNewDeckName(e.target.value)}
              className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-stone-900 dark:text-white"
              autoFocus
            />
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setShowCreateDeck(false)} className="px-3 py-1.5 text-xs text-stone-500">Cancel</button>
              <button onClick={handleCreateDeck} className="px-4 py-1.5 bg-indigo-600 text-white rounded text-xs font-semibold">Create Deck</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CREATE CARD */}
      {showAddCard && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="font-bold text-sm text-stone-900 dark:text-white">Add Card to Deck</h3>
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block mb-1">Front (Prompt)</label>
              <textarea 
                rows={3}
                placeholder="Question or concept prompt..."
                value={newCardFront}
                onChange={(e) => setNewCardFront(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-stone-900 dark:text-white resize-none"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-stone-400 block mb-1">Back (Explanation / Answer)</label>
              <textarea 
                rows={3}
                placeholder="Detailed answer or formula..."
                value={newCardBack}
                onChange={(e) => setNewCardBack(e.target.value)}
                className="w-full px-3 py-2 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-700 rounded text-xs focus:ring-1 focus:ring-indigo-500 outline-none text-stone-900 dark:text-white resize-none"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button onClick={() => setShowAddCard(false)} className="px-3 py-1.5 text-xs text-stone-500">Cancel</button>
              <button onClick={handleCreateCard} className="px-4 py-1.5 bg-indigo-600 text-white rounded text-xs font-semibold">Save Flashcard</button>
            </div>
          </div>
        </div>
      )}

      {/* Main Decks Grid */}
      <div className="space-y-4">
        {filteredDecks.length === 0 ? (
          <div className="p-12 border border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 rounded-2xl text-center space-y-3">
            <BrainCircuit className="w-10 h-10 text-stone-300 dark:text-zinc-700 mx-auto" />
            <h3 className="font-semibold text-sm text-stone-800 dark:text-zinc-200">No Flashcard Decks Configured</h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Initialize the Class 10 CBSE/NCERT syllabus from Settings or create your first revision deck above.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredDecks.map(deck => {
              const deckCards = allCards.filter(c => c.deckId === deck.id);
              const dueCards = deckCards.filter(c => !c.nextReview || c.nextReview <= Date.now());

              return (
                <div 
                  key={deck.id}
                  className="p-5 bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-2xl shadow-sm flex flex-col justify-between space-y-4 hover:border-indigo-300 dark:hover:border-indigo-900/60 transition-colors"
                >
                  <div>
                    <div className="flex justify-between items-start gap-2">
                      <div className="w-9 h-9 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
                        <BrainCircuit className="w-5 h-5" />
                      </div>
                      <span className="font-mono text-xs text-stone-400">
                        {deckCards.length} cards
                      </span>
                    </div>

                    <h3 className="font-bold text-base text-stone-900 dark:text-white mt-3 truncate">{deck.name}</h3>
                    <div className="text-[11px] text-stone-500 mt-1">
                      {dueCards.length > 0 ? (
                        <span className="text-amber-600 font-semibold">{dueCards.length} cards due for recall</span>
                      ) : (
                        <span>Up to date on reviews</span>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2 border-t border-stone-100 dark:border-zinc-800/80">
                    <button
                      onClick={() => {
                        setSelectedDeckForNewCard(deck.id as number);
                        setShowAddCard(true);
                      }}
                      className="px-3 py-2 border border-stone-200 dark:border-zinc-700 hover:bg-stone-50 dark:hover:bg-zinc-800 rounded-lg text-xs font-semibold text-stone-700 dark:text-zinc-300 flex items-center justify-center gap-1 flex-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Card</span>
                    </button>
                    <button
                      onClick={() => startStudyingDeck(deck)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 flex-1 shadow-sm"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Review</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}

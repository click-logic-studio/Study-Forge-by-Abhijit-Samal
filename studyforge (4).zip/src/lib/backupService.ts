import { db } from '@/db/db';

export interface BackupData {
  version: number;
  appName: string;
  timestamp: number;
  checksum: string;
  metadata: {
    exportedAt: string;
    itemCounts: Record<string, number>;
  };
  data: {
    profile?: any[];
    subjects?: any[];
    chapters?: any[];
    goals?: any[];
    studySessions?: any[];
    notes?: any[];
    tasks?: any[];
    decks?: any[];
    flashcards?: any[];
    focusSessions?: any[];
    quizAttempts?: any[];
    weakTopics?: any[];
    libraryMetadata?: any[]; // Files metadata without heavy binary blobs
  };
}

// Generate simple string checksum for validation
function generateChecksum(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16);
}

export async function createFullBackup(): Promise<{ filename: string; sizeBytes: number; counts: Record<string, number> }> {
  const profile = await db.profile.toArray();
  const subjects = await db.subjects.toArray();
  const chapters = await db.chapters.toArray();
  const goals = await db.goals.toArray();
  const studySessions = await db.studySessions.toArray();
  const notes = await db.notes.toArray();
  const tasks = await db.tasks.toArray();
  const decks = await db.decks.toArray();
  const flashcards = await db.flashcards.toArray();
  const focusSessions = await db.focusSessions.toArray();
  const quizAttempts = await db.quizAttempts.toArray();
  const weakTopics = await db.weakTopics.toArray();
  
  // Library metadata only (excluding large Blobs to keep backup portable and safe)
  const libraryFiles = await db.library.toArray();
  const libraryMetadata = libraryFiles.map(({ fileData, ...meta }) => meta);

  const counts: Record<string, number> = {
    profile: profile.length,
    subjects: subjects.length,
    chapters: chapters.length,
    goals: goals.length,
    studySessions: studySessions.length,
    notes: notes.length,
    tasks: tasks.length,
    decks: decks.length,
    flashcards: flashcards.length,
    focusSessions: focusSessions.length,
    quizAttempts: quizAttempts.length,
    weakTopics: weakTopics.length,
    libraryFiles: libraryMetadata.length,
  };

  const payload: BackupData = {
    version: 5,
    appName: 'StudyForge Academic OS',
    timestamp: Date.now(),
    checksum: '',
    metadata: {
      exportedAt: new Date().toISOString(),
      itemCounts: counts,
    },
    data: {
      profile,
      subjects,
      chapters,
      goals,
      studySessions,
      notes,
      tasks,
      decks,
      flashcards,
      focusSessions,
      quizAttempts,
      weakTopics,
      libraryMetadata,
    },
  };

  const jsonString = JSON.stringify(payload, null, 2);
  payload.checksum = generateChecksum(jsonString);

  const finalBlob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const filename = `studyforge_backup_${new Date().toISOString().slice(0, 10)}.json`;

  const url = URL.createObjectURL(finalBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);

  return { filename, sizeBytes: finalBlob.size, counts };
}

export async function parseAndValidateBackupFile(file: File): Promise<{ isValid: boolean; error?: string; backup?: BackupData }> {
  try {
    const text = await file.text();
    const parsed = JSON.parse(text) as BackupData;

    if (!parsed || typeof parsed !== 'object') {
      return { isValid: false, error: 'File is not a valid JSON document.' };
    }

    if (!parsed.appName?.includes('StudyForge') && !parsed.data) {
      return { isValid: false, error: 'Unrecognized backup structure. Expected StudyForge database schema.' };
    }

    if (!parsed.data) {
      return { isValid: false, error: 'Backup does not contain data payloads.' };
    }

    return { isValid: true, backup: parsed };
  } catch (err: any) {
    return { isValid: false, error: `JSON Parse error: ${err.message || 'Malformed file'}` };
  }
}

export async function restoreBackup(backup: BackupData, mode: 'merge' | 'replace'): Promise<{ restoredCounts: Record<string, number> }> {
  // Safeguard: Create a pre-restore backup in memory/localStorage in case user needs emergency rollback
  try {
    const preRestoreSummary = {
      timestamp: Date.now(),
      mode,
      backupSourceTime: backup.timestamp
    };
    sessionStorage.setItem('studyforge_last_restore_point', JSON.stringify(preRestoreSummary));
  } catch {
    // Non-blocking
  }

  const { data } = backup;
  const restoredCounts: Record<string, number> = {};

  await db.transaction('rw', [
    db.profile, db.subjects, db.chapters, db.goals, db.studySessions,
    db.notes, db.tasks, db.decks, db.flashcards, db.focusSessions,
    db.quizAttempts, db.weakTopics
  ], async () => {
    if (mode === 'replace') {
      await db.subjects.clear();
      await db.chapters.clear();
      await db.goals.clear();
      await db.studySessions.clear();
      await db.notes.clear();
      await db.tasks.clear();
      await db.decks.clear();
      await db.flashcards.clear();
      await db.focusSessions.clear();
      await db.quizAttempts.clear();
      await db.weakTopics.clear();
    }

    if (data.profile && data.profile.length > 0) {
      await db.profile.put(data.profile[0]);
      restoredCounts.profile = 1;
    }

    if (data.subjects && data.subjects.length > 0) {
      if (mode === 'replace') {
        await db.subjects.bulkPut(data.subjects);
      } else {
        await db.subjects.bulkAdd(data.subjects.map(({ id, ...s }) => s));
      }
      restoredCounts.subjects = data.subjects.length;
    }

    if (data.chapters && data.chapters.length > 0) {
      if (mode === 'replace') {
        await db.chapters.bulkPut(data.chapters);
      } else {
        await db.chapters.bulkAdd(data.chapters.map(({ id, ...c }) => c));
      }
      restoredCounts.chapters = data.chapters.length;
    }

    if (data.goals && data.goals.length > 0) {
      if (mode === 'replace') {
        await db.goals.bulkPut(data.goals);
      } else {
        await db.goals.bulkAdd(data.goals.map(({ id, ...g }) => g));
      }
      restoredCounts.goals = data.goals.length;
    }

    if (data.studySessions && data.studySessions.length > 0) {
      if (mode === 'replace') {
        await db.studySessions.bulkPut(data.studySessions);
      } else {
        await db.studySessions.bulkAdd(data.studySessions.map(({ id, ...s }) => s));
      }
      restoredCounts.studySessions = data.studySessions.length;
    }

    if (data.notes && data.notes.length > 0) {
      if (mode === 'replace') {
        await db.notes.bulkPut(data.notes);
      } else {
        await db.notes.bulkAdd(data.notes.map(({ id, ...n }) => n));
      }
      restoredCounts.notes = data.notes.length;
    }

    if (data.tasks && data.tasks.length > 0) {
      if (mode === 'replace') {
        await db.tasks.bulkPut(data.tasks);
      } else {
        await db.tasks.bulkAdd(data.tasks.map(({ id, ...t }) => t));
      }
      restoredCounts.tasks = data.tasks.length;
    }

    if (data.decks && data.decks.length > 0) {
      if (mode === 'replace') {
        await db.decks.bulkPut(data.decks);
      } else {
        await db.decks.bulkAdd(data.decks.map(({ id, ...d }) => d));
      }
      restoredCounts.decks = data.decks.length;
    }

    if (data.flashcards && data.flashcards.length > 0) {
      if (mode === 'replace') {
        await db.flashcards.bulkPut(data.flashcards);
      } else {
        await db.flashcards.bulkAdd(data.flashcards.map(({ id, ...f }) => f));
      }
      restoredCounts.flashcards = data.flashcards.length;
    }

    if (data.quizAttempts && data.quizAttempts.length > 0) {
      if (mode === 'replace') {
        await db.quizAttempts.bulkPut(data.quizAttempts);
      } else {
        await db.quizAttempts.bulkAdd(data.quizAttempts.map(({ id, ...q }) => q));
      }
      restoredCounts.quizAttempts = data.quizAttempts.length;
    }

    if (data.weakTopics && data.weakTopics.length > 0) {
      if (mode === 'replace') {
        await db.weakTopics.bulkPut(data.weakTopics);
      } else {
        await db.weakTopics.bulkAdd(data.weakTopics.map(({ id, ...w }) => w));
      }
      restoredCounts.weakTopics = data.weakTopics.length;
    }
  });

  return { restoredCounts };
}

export async function exportAnalyticsCSV(): Promise<void> {
  const sessions = await db.studySessions.toArray();
  const subjects = await db.subjects.toArray();
  const subjectMap = new Map(subjects.map(s => [s.id, s.name]));

  const headers = ['Session ID', 'Subject', 'Date', 'Start Time', 'Duration (Min)', 'Resource Used', 'Topic'];
  const rows = sessions.map(s => [
    s.id ?? '',
    `"${subjectMap.get(s.subjectId) || 'General'}"`,
    new Date(s.startTime).toLocaleDateString(),
    new Date(s.startTime).toLocaleTimeString(),
    s.durationMinutes,
    `"${s.resourceUsed || 'Self Study'}"`,
    `"${(s.topic || '').replace(/"/g, '""')}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `studyforge_sessions_export_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Local Document Intelligence Engine - 100% Client-Side / Zero Cloud Dependency

const ENGLISH_STOPWORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and',
  'any', 'are', 'aren\'t', 'as', 'at', 'be', 'because', 'been', 'before', 'being',
  'below', 'between', 'both', 'but', 'by', 'can', 'can\'t', 'cannot', 'could',
  'did', 'do', 'does', 'doing', 'down', 'during', 'each', 'few', 'for', 'from',
  'further', 'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers', 'herself',
  'him', 'himself', 'his', 'how', 'i', 'if', 'in', 'into', 'is', 'isn\'t', 'it',
  'its', 'itself', 'let\'s', 'me', 'more', 'most', 'my', 'myself', 'no', 'nor',
  'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours',
  'ourselves', 'out', 'over', 'own', 'same', 'she', 'should', 'so', 'some', 'such',
  'than', 'that', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there',
  'these', 'they', 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up',
  'very', 'was', 'we', 'were', 'what', 'when', 'where', 'which', 'while', 'who',
  'whom', 'why', 'with', 'would', 'you', 'your', 'yours', 'yourself', 'yourselves',
  'fig', 'figure', 'page', 'table', 'also', 'therefore', 'shown', 'given', 'example'
]);

export interface ExtractedKeywords {
  word: string;
  count: number;
  prominence: number; // 0 to 1
}

export interface DetectedChapter {
  title: string;
  pageNumber: number;
  level: number;
}

/**
 * Extracts high-value academic keywords locally using TF (Term Frequency)
 * with stopword suppression and minimum token length constraints.
 */
export function extractLocalKeywords(text: string, topN = 12): ExtractedKeywords[] {
  if (!text || text.trim().length === 0) return [];

  const tokens = text
    .toLowerCase()
    .replace(/[^\w\s-]/g, ' ')
    .split(/\s+/)
    .filter(token => token.length >= 4 && !ENGLISH_STOPWORDS.has(token) && !/^\d+$/.test(token));

  const frequencies = new Map<string, number>();
  for (const token of tokens) {
    frequencies.set(token, (frequencies.get(token) || 0) + 1);
  }

  const sorted = Array.from(frequencies.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, topN);

  const maxFreq = sorted[0]?.[1] || 1;

  return sorted.map(([word, count]) => ({
    word: word.charAt(0).toUpperCase() + word.slice(1),
    count,
    prominence: Math.round((count / maxFreq) * 100) / 100
  }));
}

/**
 * Scans extracted PDF page text for chapter markers, units, or section headings
 */
export function detectDocumentChapters(pagesText: Array<{ pageNumber: number; text: string }>): DetectedChapter[] {
  const chapters: DetectedChapter[] = [];
  const chapterRegex = /^(?:chapter|unit|section|lesson|module)\s*(\d+|[ivxlcdm]+)[:.-]?\s*(.*)$/im;
  const capitalizedHeaderRegex = /^[A-Z0-9\s,–—:-]{6,60}$/m;

  for (const { pageNumber, text } of pagesText) {
    const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
    for (const line of lines.slice(0, 10)) { // Inspect header region of page
      const match = line.match(chapterRegex);
      if (match) {
        const title = line.length > 50 ? line.slice(0, 47) + '...' : line;
        chapters.push({
          title,
          pageNumber,
          level: 1
        });
        break;
      } else if (capitalizedHeaderRegex.test(line) && line.length > 8 && !line.includes('PAGE') && !line.includes('COPYRIGHT')) {
        chapters.push({
          title: line,
          pageNumber,
          level: 2
        });
        break;
      }
    }
  }

  return chapters;
}

/**
 * Client-Side Inverted Text Index for instantaneous local document search
 */
export class ClientDocumentIndex {
  private pageMap = new Map<number, string>();
  private index = new Map<string, Set<number>>();

  public addPage(pageNumber: number, text: string) {
    this.pageMap.set(pageNumber, text);
    const words = text.toLowerCase().match(/\b[a-z0-9_-]{2,}\b/g) || [];
    for (const w of words) {
      if (!this.index.has(w)) {
        this.index.set(w, new Set());
      }
      this.index.get(w)!.add(pageNumber);
    }
  }

  public search(query: string): Array<{ pageNumber: number; snippet: string; count: number }> {
    const cleanQuery = query.toLowerCase().trim();
    if (!cleanQuery) return [];

    const queryWords = cleanQuery.match(/\b[a-z0-9_-]{2,}\b/g) || [cleanQuery];
    const candidatePages = new Set<number>();

    for (const word of queryWords) {
      const pages = this.index.get(word);
      if (pages) {
        pages.forEach(p => candidatePages.add(p));
      }
    }

    const results: Array<{ pageNumber: number; snippet: string; count: number }> = [];

    for (const pageNumber of candidatePages) {
      const pageText = this.pageMap.get(pageNumber) || '';
      const lower = pageText.toLowerCase();
      const occurrences = (lower.match(new RegExp(cleanQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi')) || []).length;

      if (occurrences > 0) {
        const firstIdx = lower.indexOf(cleanQuery);
        const start = Math.max(0, firstIdx - 40);
        const end = Math.min(pageText.length, firstIdx + cleanQuery.length + 60);
        const snippet = (start > 0 ? '...' : '') + pageText.slice(start, end).replace(/\s+/g, ' ') + (end < pageText.length ? '...' : '');

        results.push({
          pageNumber,
          snippet,
          count: occurrences
        });
      }
    }

    return results.sort((a, b) => b.count - a.count);
  }

  public clear() {
    this.pageMap.clear();
    this.index.clear();
  }
}

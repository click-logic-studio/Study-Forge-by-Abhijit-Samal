import React, { useEffect, useState } from 'react';
import { db } from '@/db/db';
import { 
  ShieldCheck, HardDrive, WifiOff, Wifi, 
  Database, Activity, RefreshCw, X, CheckCircle2, Cpu
} from 'lucide-react';
import { useUIStore } from '@/store/uiStore';

interface SystemStatusDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SystemStatusDrawer({ isOpen, onClose }: SystemStatusDrawerProps) {
  const { performanceMode } = useUIStore();
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [storageUsage, setStorageUsage] = useState<{ usedMB: number; quotaMB: number; percent: number }>({ usedMB: 0, quotaMB: 0, percent: 0 });
  const [counts, setCounts] = useState<{ subjects: number; notes: number; tasks: number; sessions: number; library: number }>({ subjects: 0, notes: 0, tasks: 0, sessions: 0, library: 0 });
  const [dbStatus, setDbStatus] = useState<'healthy' | 'checking' | 'error'>('checking');
  const [lastCheckTime, setLastCheckTime] = useState<string>(new Date().toLocaleTimeString());

  const checkHealth = async () => {
    setDbStatus('checking');
    try {
      if (navigator.storage && navigator.storage.estimate) {
        const est = await navigator.storage.estimate();
        const used = Math.round((est.usage || 0) / (1024 * 1024) * 10) / 10;
        const quota = Math.round((est.quota || 0) / (1024 * 1024) * 10) / 10;
        const pct = quota > 0 ? Math.round((used / quota) * 100) : 0;
        setStorageUsage({ usedMB: used, quotaMB: quota, percent: pct });
      }

      const subjectsCount = await db.subjects.count();
      const notesCount = await db.notes.count();
      const tasksCount = await db.tasks.count();
      const sessionsCount = await db.studySessions.count();
      const libraryCount = await db.library.count();

      setCounts({
        subjects: subjectsCount,
        notes: notesCount,
        tasks: tasksCount,
        sessions: sessionsCount,
        library: libraryCount
      });

      setDbStatus('healthy');
      setLastCheckTime(new Date().toLocaleTimeString());
    } catch (e) {
      console.error('Database health check failed:', e);
      setDbStatus('error');
    }
  };

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    if (isOpen) {
      checkHealth();
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl shadow-xl w-full max-w-md overflow-hidden flex flex-col text-stone-900 dark:text-zinc-100">
        
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-stone-200 dark:border-zinc-800 flex items-center justify-between bg-stone-50/50 dark:bg-zinc-900/50">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <div>
              <h3 className="text-sm font-bold leading-none">System Integrity & Local Status</h3>
              <p className="text-[11px] text-stone-500 dark:text-zinc-400 mt-0.5">Real-time local workspace diagnostics</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded text-stone-400 hover:text-stone-700 dark:hover:text-zinc-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-5 space-y-4 text-xs">
          
          {/* Storage & DB Status */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-stone-50 dark:bg-zinc-800/40 rounded border border-stone-200 dark:border-zinc-800 space-y-1">
              <div className="flex items-center gap-1.5 text-stone-500 dark:text-zinc-400">
                <Database className="w-3.5 h-3.5" />
                <span className="font-semibold uppercase tracking-wider text-[10px]">Database Volume</span>
              </div>
              <div className="flex items-center gap-1.5 font-bold text-sm text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>IndexedDB Online</span>
              </div>
              <p className="text-[10px] text-stone-400">Local persistent storage intact</p>
            </div>

            <div className="p-3 bg-stone-50 dark:bg-zinc-800/40 rounded border border-stone-200 dark:border-zinc-800 space-y-1">
              <div className="flex items-center gap-1.5 text-stone-500 dark:text-zinc-400">
                {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
                <span className="font-semibold uppercase tracking-wider text-[10px]">Network Isolation</span>
              </div>
              <div className="font-bold text-sm text-stone-800 dark:text-zinc-200">
                {isOnline ? 'Online (Self-Contained)' : 'Offline (Air-Gapped)'}
              </div>
              <p className="text-[10px] text-stone-400">Zero cloud API dependency</p>
            </div>
          </div>

          {/* Storage Capacity Bar */}
          <div className="p-3.5 bg-stone-50 dark:bg-zinc-800/40 rounded border border-stone-200 dark:border-zinc-800 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center gap-1.5 font-semibold text-stone-700 dark:text-zinc-300">
                <HardDrive className="w-3.5 h-3.5 text-indigo-500" />
                <span>Local Disk Allocation</span>
              </div>
              <span className="font-mono text-stone-500 dark:text-zinc-400">
                {storageUsage.usedMB} MB used / ~{storageUsage.quotaMB || 'Unlimited'} MB
              </span>
            </div>
            <div className="w-full h-1.5 bg-stone-200 dark:bg-zinc-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                style={{ width: `${Math.max(2, Math.min(100, storageUsage.percent))}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-stone-400 pt-0.5">
              <span>Indexed tables & PDF buffers</span>
              <span>Healthy</span>
            </div>
          </div>

          {/* Hardware & Resource Mode */}
          <div className="p-3.5 bg-stone-50 dark:bg-zinc-800/40 rounded border border-stone-200 dark:border-zinc-800 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="flex items-center gap-1.5 font-semibold text-stone-700 dark:text-zinc-300">
                <Cpu className="w-3.5 h-3.5 text-amber-500" />
                <span>Performance Optimization</span>
              </div>
              <p className="text-[10px] text-stone-400">
                {performanceMode ? 'Low-end hardware mode active (reduced canvas & animations)' : 'Standard desktop profile'}
              </p>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-stone-200 dark:bg-zinc-700 text-stone-700 dark:text-zinc-300">
              {performanceMode ? 'Optimized' : 'Standard'}
            </span>
          </div>

          {/* Record Count Breakdown */}
          <div className="border border-stone-200 dark:border-zinc-800 rounded overflow-hidden">
            <div className="px-3 py-1.5 bg-stone-100 dark:bg-zinc-800 text-[10px] font-bold uppercase tracking-wider text-stone-500 dark:text-zinc-400">
              Verified Local Table Entities
            </div>
            <div className="divide-y divide-stone-100 dark:divide-zinc-800/60 font-mono text-[11px]">
              <div className="px-3 py-1.5 flex justify-between">
                <span className="font-sans text-stone-600 dark:text-zinc-400">Curriculum Subjects</span>
                <span className="font-bold text-stone-900 dark:text-white">{counts.subjects}</span>
              </div>
              <div className="px-3 py-1.5 flex justify-between">
                <span className="font-sans text-stone-600 dark:text-zinc-400">Personal Notes</span>
                <span className="font-bold text-stone-900 dark:text-white">{counts.notes}</span>
              </div>
              <div className="px-3 py-1.5 flex justify-between">
                <span className="font-sans text-stone-600 dark:text-zinc-400">Active Tasks & Goals</span>
                <span className="font-bold text-stone-900 dark:text-white">{counts.tasks}</span>
              </div>
              <div className="px-3 py-1.5 flex justify-between">
                <span className="font-sans text-stone-600 dark:text-zinc-400">Completed Study Sessions</span>
                <span className="font-bold text-stone-900 dark:text-white">{counts.sessions}</span>
              </div>
              <div className="px-3 py-1.5 flex justify-between">
                <span className="font-sans text-stone-600 dark:text-zinc-400">Library Files Cached</span>
                <span className="font-bold text-stone-900 dark:text-white">{counts.library}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-stone-50 dark:bg-zinc-900 border-t border-stone-200 dark:border-zinc-800 flex items-center justify-between text-[11px] text-stone-500">
          <span>Last audit: {lastCheckTime}</span>
          <button 
            onClick={checkHealth}
            className="flex items-center gap-1 font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Re-verify</span>
          </button>
        </div>

      </div>
    </div>
  );
}

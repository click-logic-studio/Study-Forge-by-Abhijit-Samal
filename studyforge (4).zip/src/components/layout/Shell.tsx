import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useLiveQuery } from 'dexie-react-hooks';
import { db } from '@/db/db';
import { useUIStore } from '@/store/uiStore';
import { 
  Home, BookOpen, Layers, Library, 
  CheckSquare, Calendar, BrainCircuit, 
  Activity, MonitorPlay, Settings, ChevronLeft, ChevronRight, Hash, Box,
  Search, Bell, ShieldCheck, GraduationCap, PenTool, LayoutDashboard,
  Wrench, LineChart, Network, Zap, Wifi, WifiOff
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { CommandPalette } from '@/components/CommandPalette';
import { SystemStatusDrawer } from '@/components/SystemStatusDrawer';

const NAV_GROUPS = [
  {
    title: 'Learning',
    items: [
      { icon: Home, label: 'Home', path: '/' },
      { icon: GraduationCap, label: 'My Learning', path: '/learning' },
      { icon: Layers, label: 'Curriculum', path: '/curriculum' },
      { icon: Library, label: 'Library', path: '/library' },
    ]
  },
  {
    title: 'Study',
    items: [
      { icon: BookOpen, label: 'Study Workspace', path: '/workspace' },
      { icon: Activity, label: 'Sessions', path: '/sessions' },
      { icon: CheckSquare, label: 'Tasks', path: '/tasks' },
      { icon: Calendar, label: 'Calendar', path: '/calendar' },
      { icon: PenTool, label: 'Revision', path: '/revision' },
    ]
  },
  {
    title: 'Practice',
    items: [
      { icon: LayoutDashboard, label: 'Quizzes', path: '/quizzes' },
      { icon: BrainCircuit, label: 'Flashcards', path: '/flashcards' },
      { icon: MonitorPlay, label: 'Simulation Lab', path: '/simulations' },
      { icon: Box, label: '3D Lab', path: '/3d-lab' },
    ]
  },
  {
    title: 'Insights',
    items: [
      { icon: LineChart, label: 'Analytics', path: '/analytics' },
      { icon: Network, label: 'Knowledge Map', path: '/knowledge-map' },
    ]
  },
  {
    title: 'Utilities',
    items: [
      { icon: Wrench, label: 'Tools', path: '/tools' },
      { icon: Settings, label: 'Settings', path: '/settings' },
    ]
  }
];

export function Shell() {
  const { sidebarOpen, toggleSidebar, performanceMode, setPerformanceMode } = useUIStore();
  const profile = useLiveQuery(() => db.profile.get(1));
  const [statusDrawerOpen, setStatusDrawerOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const studentName = profile?.nickname || profile?.name?.split(' ')[0] || 'Scholar';
  const initial = studentName.charAt(0).toUpperCase();

  return (
    <div className={cn(
      "flex h-screen w-full bg-stone-50 dark:bg-zinc-950 text-stone-900 dark:text-zinc-100 overflow-hidden font-sans",
      performanceMode && "reduce-motion"
    )}>
      <CommandPalette />
      <SystemStatusDrawer isOpen={statusDrawerOpen} onClose={() => setStatusDrawerOpen(false)} />
      
      {/* Sidebar */}
      <aside 
        className={cn(
          "flex flex-col bg-[#18181b] dark:bg-zinc-950 text-stone-300 dark:text-zinc-400 border-r border-stone-800 dark:border-zinc-800 transition-all duration-200 relative z-20 shrink-0",
          sidebarOpen ? "w-60" : "w-[68px]",
          performanceMode && "transition-none"
        )}
      >
        {/* Brand Header */}
        <div className="h-13 flex items-center justify-between px-4 border-b border-stone-800 dark:border-zinc-900 shrink-0 bg-[#121215] dark:bg-zinc-950">
          {sidebarOpen ? (
            <div className="flex items-center gap-2.5 font-bold text-sm tracking-tight text-white">
              <div className="w-6 h-6 rounded bg-indigo-600 flex items-center justify-center text-white text-xs font-mono font-bold shadow-sm">
                SF
              </div>
              <span>StudyForge</span>
              <span className="text-[10px] font-mono text-stone-500 uppercase tracking-wider ml-auto">OS v5</span>
            </div>
          ) : (
            <div className="w-full flex justify-center">
              <div className="w-7 h-7 rounded bg-indigo-600 flex items-center justify-center text-white text-xs font-mono font-bold shadow-sm">
                SF
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-5 custom-scrollbar">
          {NAV_GROUPS.map((group, idx) => (
            <div key={idx} className="flex flex-col gap-0.5">
              {sidebarOpen && (
                <div className="text-[10px] font-bold uppercase tracking-wider text-stone-500 px-2 py-1 select-none">
                  {group.title}
                </div>
              )}
              {group.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => cn(
                    "flex items-center gap-2.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors",
                    isActive 
                      ? "bg-indigo-600 text-white shadow-sm" 
                      : "text-stone-300 hover:bg-stone-800/60 hover:text-white"
                  )}
                  title={!sidebarOpen ? item.label : undefined}
                >
                  <item.icon className="w-4 h-4 shrink-0" />
                  {sidebarOpen && <span className="truncate">{item.label}</span>}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        {/* Subtle Bottom Status Indicator inside Sidebar */}
        <div className="p-3 border-t border-stone-800 dark:border-zinc-900 text-xs">
          <button 
            onClick={() => setStatusDrawerOpen(true)}
            className="w-full flex items-center gap-2 p-1.5 rounded hover:bg-stone-800/60 transition-colors text-left"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            {sidebarOpen && (
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-semibold text-stone-300 truncate">Air-Gapped & Active</div>
                <div className="text-[10px] text-stone-500">IndexedDB Verified</div>
              </div>
            )}
          </button>
        </div>

        {/* Sidebar Collapse Toggle */}
        <button
          onClick={toggleSidebar}
          className="absolute -right-3 top-14 w-5 h-5 bg-stone-800 border border-stone-700 rounded-full flex items-center justify-center text-stone-400 hover:text-white shadow z-30"
          title={sidebarOpen ? "Collapse sidebar" : "Expand sidebar"}
        >
          {sidebarOpen ? <ChevronLeft className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </button>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative bg-stone-100/70 dark:bg-zinc-950">
        
        {/* Enterprise Top Bar */}
        <header className="h-13 bg-white dark:bg-zinc-900 border-b border-stone-200 dark:border-zinc-800 flex items-center justify-between px-4 shrink-0 z-10">
          
          {/* Left: Global Search / Command Shortcut */}
          <div className="flex-1 flex items-center max-w-md">
            <button 
              onClick={() => document.dispatchEvent(new KeyboardEvent('keydown', { key: 'k', metaKey: true }))}
              className="flex items-center gap-2.5 px-3 py-1.5 bg-stone-50 dark:bg-zinc-950 border border-stone-200 dark:border-zinc-800 rounded-md text-xs text-stone-500 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800/80 transition-colors w-full"
            >
              <Search className="w-3.5 h-3.5 text-stone-400" />
              <span>Search subjects, formulas, notes, or tools...</span>
              <kbd className="ml-auto px-1.5 py-0.5 text-[10px] font-mono bg-white dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 rounded text-stone-500 shadow-xs">Ctrl K</kbd>
            </button>
          </div>

          {/* Right: Hardware Profile, Diagnostics, & Profile */}
          <div className="flex items-center gap-3">
            
            {/* Performance Mode Quick Toggle */}
            <button
              onClick={() => setPerformanceMode(!performanceMode)}
              className={cn(
                "flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors border",
                performanceMode 
                  ? "bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800" 
                  : "bg-stone-50 dark:bg-zinc-800/40 text-stone-500 border-stone-200 dark:border-zinc-800 hover:text-stone-900"
              )}
              title="Toggle Low-End Performance Mode (Core 2 Duo / 3GB RAM)"
            >
              <Zap className={cn("w-3.5 h-3.5", performanceMode && "text-amber-500 fill-amber-500")} />
              <span className="hidden sm:inline font-mono">{performanceMode ? 'Low-End Profile' : 'Standard Profile'}</span>
            </button>

            {/* System Status Drawer Trigger */}
            <button 
              onClick={() => setStatusDrawerOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded text-xs text-stone-600 dark:text-zinc-300 hover:bg-stone-100 dark:hover:bg-zinc-800 transition-colors border border-transparent hover:border-stone-200 dark:hover:border-zinc-700"
              title="Inspect System Status"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span className="hidden md:inline font-semibold">Local Storage</span>
              <span className="text-stone-300 dark:text-zinc-600">·</span>
              <span className="text-[11px] text-stone-500">{isOnline ? 'Online' : 'Offline'}</span>
            </button>

            <div className="w-px h-4 bg-stone-200 dark:border-zinc-800" />

            {/* Student Profile Quick View */}
            <NavLink 
              to="/settings"
              className="flex items-center gap-2 p-1 pr-2 rounded-md hover:bg-stone-100 dark:hover:bg-zinc-800 transition-colors"
              title="Open Settings"
            >
              <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold shadow-xs">
                {initial}
              </div>
              <span className="text-xs font-semibold text-stone-700 dark:text-zinc-300 hidden sm:inline">
                {studentName}
              </span>
            </NavLink>
          </div>
        </header>

        {/* Dynamic Outlet */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-5 md:p-7">
          <Outlet />
        </div>
      </main>
    </div>
  );
}

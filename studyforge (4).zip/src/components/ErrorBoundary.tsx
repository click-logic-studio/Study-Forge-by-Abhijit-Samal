import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RefreshCw, Home, Database } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('StudyForge Uncaught Error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      const errorMessage = this.state.error?.message || 'An unexpected runtime state occurred';

      return (
        <div className="min-h-screen w-full flex items-center justify-center bg-stone-50 dark:bg-stone-950 p-6 text-stone-900 dark:text-stone-100">
          <div className="max-w-xl w-full bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-8 shadow-xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 rounded-xl">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-lg font-bold">StudyForge Runtime Safeguard</h1>
                <p className="text-xs text-stone-500">Local data is preserved in IndexedDB</p>
              </div>
            </div>

            <div className="bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-lg p-4 mb-6">
              <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">
                Diagnostic Output
              </div>
              <div className="text-xs font-mono text-rose-600 dark:text-rose-400 break-words mb-3">
                {errorMessage}
              </div>

              <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-1">
                Possible Causes
              </div>
              <ul className="text-xs text-stone-600 dark:text-stone-400 list-disc list-inside space-y-1">
                <li>A background worker or IndexedDB transaction encountered an unexpected abort</li>
                <li>Browser memory limit reached while handling large media or 3D assets</li>
                <li>Transient rendering lifecycle issue</li>
              </ul>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-stone-100 dark:border-stone-800">
              <div className="flex items-center gap-2">
                <button
                  onClick={this.handleReset}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors shadow-sm"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Try Again
                </button>
                <button
                  onClick={this.handleReload}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium border border-stone-300 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 rounded-lg transition-colors"
                >
                  Reload Application
                </button>
              </div>

              <button
                onClick={() => {
                  window.location.href = '/';
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 transition-colors"
              >
                <Home className="w-3.5 h-3.5" />
                Return to Dashboard
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

import React from 'react';
import { useUIStore } from '@/store/uiStore';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ToastAndConfirm() {
  const toasts = useUIStore((state) => state.toasts);
  const dismissToast = useUIStore((state) => state.dismissToast);
  const confirmDialog = useUIStore((state) => state.confirmDialog);
  const closeConfirmation = useUIStore((state) => state.closeConfirmation);

  return (
    <>
      {/* Toast notifications */}
      <div 
        aria-live="polite" 
        className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 pointer-events-none max-w-sm w-full"
      >
        {toasts.map((toast) => {
          const icons = {
            info: <Info className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />,
            success: <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />,
            warning: <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />,
            error: <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />,
          };

          return (
            <div
              key={toast.id}
              className={cn(
                "pointer-events-auto flex items-start gap-3 p-3.5 rounded-lg border shadow-lg transition-all transform animate-in slide-in-from-bottom-2",
                "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 border-stone-200 dark:border-stone-800"
              )}
            >
              {icons[toast.type]}
              <div className="flex-1 text-xs font-medium leading-relaxed">
                {toast.message}
              </div>
              <button
                onClick={() => dismissToast(toast.id)}
                className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors p-0.5"
                aria-label="Dismiss toast"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal */}
      {confirmDialog && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-150"
          role="dialog"
          aria-modal="true"
          aria-labelledby="confirm-dialog-title"
        >
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl p-5 max-w-md w-full shadow-2xl text-stone-900 dark:text-stone-100">
            <h3 id="confirm-dialog-title" className="text-base font-semibold mb-2">
              {confirmDialog.title}
            </h3>
            <p className="text-sm text-stone-600 dark:text-stone-400 mb-6 leading-relaxed">
              {confirmDialog.message}
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={closeConfirmation}
                className="px-3.5 py-1.5 text-xs font-medium rounded-md border border-stone-300 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 transition-colors"
              >
                {confirmDialog.cancelLabel || 'Cancel'}
              </button>
              <button
                type="button"
                onClick={() => {
                  confirmDialog.onConfirm();
                  closeConfirmation();
                }}
                className={cn(
                  "px-3.5 py-1.5 text-xs font-medium rounded-md text-white transition-colors shadow-sm",
                  confirmDialog.isDestructive
                    ? "bg-rose-600 hover:bg-rose-700"
                    : "bg-indigo-600 hover:bg-indigo-700"
                )}
              >
                {confirmDialog.confirmLabel || 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

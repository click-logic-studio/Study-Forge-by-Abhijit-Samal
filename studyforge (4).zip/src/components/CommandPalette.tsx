import React, { useEffect, useState } from 'react';
import { Command } from 'cmdk';
import { useNavigate } from 'react-router-dom';
import { Search, FileText, PlaySquare, BookOpen, Layers, MonitorPlay, Box, Activity, Settings, Calendar, CheckSquare, Hash } from 'lucide-react';

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };
    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  const runCommand = (command: () => void) => {
    command();
    setOpen(false);
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[15vh] bg-stone-900/50 backdrop-blur-sm px-4">
      <div className="w-full max-w-2xl bg-white dark:bg-zinc-900 rounded-xl shadow-2xl border border-stone-200 dark:border-zinc-800 overflow-hidden"
           onClick={(e) => e.stopPropagation()}
      >
        <Command label="Command Menu" className="flex flex-col w-full h-full">
          <div className="flex items-center px-4 py-3 border-b border-stone-200 dark:border-zinc-800 gap-3">
            <Search className="w-5 h-5 text-stone-400" />
            <Command.Input 
              placeholder="Type a command or search..." 
              className="flex-1 bg-transparent outline-none text-stone-900 dark:text-zinc-100 placeholder-stone-400 text-lg"
              autoFocus
            />
          </div>
          
          <Command.List className="max-h-[60vh] overflow-y-auto p-2 custom-scrollbar">
            <Command.Empty className="py-6 text-center text-sm text-stone-500">No results found.</Command.Empty>

            <Command.Group heading="Study Actions" className="px-2 py-1.5 text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider mb-1">
              <Command.Item onSelect={() => runCommand(() => navigate('/workspace'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900/30 text-stone-700 dark:text-zinc-300 aria-selected:bg-indigo-50 aria-selected:text-indigo-700 dark:aria-selected:bg-indigo-900/30 dark:aria-selected:text-indigo-300">
                <FileText className="w-4 h-4" /> Open PDF Reader
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/workspace'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900/30 text-stone-700 dark:text-zinc-300 aria-selected:bg-indigo-50 aria-selected:text-indigo-700 dark:aria-selected:bg-indigo-900/30 dark:aria-selected:text-indigo-300">
                <PlaySquare className="w-4 h-4" /> Open Video Player
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/sessions'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-indigo-50 dark:hover:bg-indigo-900/30 text-stone-700 dark:text-zinc-300 aria-selected:bg-indigo-50 aria-selected:text-indigo-700 dark:aria-selected:bg-indigo-900/30 dark:aria-selected:text-indigo-300">
                <Activity className="w-4 h-4" /> Start Study Session
              </Command.Item>
            </Command.Group>

            <Command.Group heading="Navigation" className="px-2 py-1.5 text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider mt-4 mb-1">
              <Command.Item onSelect={() => runCommand(() => navigate('/'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <Hash className="w-4 h-4" /> Go to Dashboard
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/curriculum'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <Layers className="w-4 h-4" /> Go to Curriculum
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/library'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <BookOpen className="w-4 h-4" /> Search Library
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/simulations'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <MonitorPlay className="w-4 h-4" /> Open Simulation Lab
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/3d-lab'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <Box className="w-4 h-4" /> Open 3D Lab
              </Command.Item>
              <Command.Item onSelect={() => runCommand(() => navigate('/tasks'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <CheckSquare className="w-4 h-4" /> View Tasks
              </Command.Item>
            </Command.Group>

            <Command.Group heading="Settings" className="px-2 py-1.5 text-xs font-semibold text-stone-500 dark:text-zinc-400 uppercase tracking-wider mt-4 mb-1">
              <Command.Item onSelect={() => runCommand(() => navigate('/settings'))} className="flex items-center gap-3 px-3 py-2 text-sm rounded-lg cursor-pointer hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 aria-selected:bg-stone-100 dark:aria-selected:bg-zinc-800">
                <Settings className="w-4 h-4" /> Open Settings
              </Command.Item>
            </Command.Group>
            
          </Command.List>
        </Command>
      </div>
      <div className="absolute inset-0 z-[-1]" onClick={() => setOpen(false)}></div>
    </div>
  );
}
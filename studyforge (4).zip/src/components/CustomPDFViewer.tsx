export { PdfViewer as CustomPDFViewer } from './workspace/PdfViewer';
export type { PdfViewerProps as CustomPDFViewerProps } from './workspace/PdfViewer';

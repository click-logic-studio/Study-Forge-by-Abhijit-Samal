import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
// Vite URL import bundles the worker locally as a packaged asset
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { 
  ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Search, 
  Bookmark, BookmarkPlus, Hash, ListFilter, BookOpen, 
  Info, Sparkles, Loader2, X, RotateCcw, RotateCw, Check,
  Maximize2, Minimize2, AlertTriangle, RefreshCw, UploadCloud,
  FileQuestion, FileX
} from 'lucide-react';
import { 
  extractLocalKeywords, detectDocumentChapters, 
  ClientDocumentIndex, ExtractedKeywords, DetectedChapter 
} from '@/lib/documentIntelligence';
import { useUIStore } from '@/store/uiStore';
import { cn } from '@/lib/utils';

// CONFIGURE LOCAL PDF.JS WORKER — 100% OFFLINE BUNDLED (ZERO CDN DEPENDENCY)
try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl || '/assets/pdf.worker.min.mjs';
} catch {
  pdfjsLib.GlobalWorkerOptions.workerSrc = '/assets/pdf.worker.min.mjs';
}

export interface PdfViewerProps {
  fileUrl: string | null;
  fileName?: string;
  initialPage?: number;
  onPageChange?: (page: number, totalPages: number) => void;
  onSaveBookmark?: (page: number, title: string) => void;
  onChooseAnotherFile?: () => void;
  onClose?: () => void;
}

interface LocalBookmark {
  id: string;
  page: number;
  title: string;
  timestamp: number;
}

export function PdfViewer({ 
  fileUrl, 
  fileName = 'Document.pdf', 
  initialPage = 1,
  onPageChange,
  onSaveBookmark,
  onChooseAnotherFile,
  onClose
}: PdfViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const currentRenderTask = useRef<any>(null);
  const activeDocRef = useRef<pdfjsLib.PDFDocumentProxy | null>(null);
  
  const { performanceMode, showToast } = useUIStore();

  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [pageNum, setPageNum] = useState<number>(initialPage);
  const [numPages, setNumPages] = useState<number>(0);
  const [scale, setScale] = useState<number>(1.2);
  const [rotation, setRotation] = useState<number>(0);
  const [rendering, setRendering] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  
  // Enterprise Error State
  const [loadError, setLoadError] = useState<{
    message: string;
    technicalDetails?: string;
    causes: string[];
  } | null>(null);

  // Document Intelligence & Sidebar
  const [activeTab, setActiveTab] = useState<'none' | 'outline' | 'search' | 'keywords' | 'bookmarks' | 'metadata'>('none');
  const [isIndexing, setIsIndexing] = useState<boolean>(false);
  const [extractedKeywords, setExtractedKeywords] = useState<ExtractedKeywords[]>([]);
  const [detectedChapters, setDetectedChapters] = useState<DetectedChapter[]>([]);
  const [bookmarks, setBookmarks] = useState<LocalBookmark[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchResults, setSearchResults] = useState<Array<{ pageNumber: number; snippet: string; count: number }>>([]);
  const [newBookmarkTitle, setNewBookmarkTitle] = useState<string>('');
  const [showAddBookmark, setShowAddBookmark] = useState<boolean>(false);

  // Client search index instance
  const searchIndexRef = useRef<ClientDocumentIndex>(new ClientDocumentIndex());

  // Load bookmarks from local storage
  useEffect(() => {
    if (fileName) {
      try {
        const stored = localStorage.getItem(`studyforge_bm_${fileName}`);
        if (stored) setBookmarks(JSON.parse(stored));
      } catch {
        // Safe fallback
      }
    }
  }, [fileName]);

  // Load PDF document
  const loadPdf = useCallback(() => {
    if (!fileUrl) {
      if (activeDocRef.current) {
        try { (activeDocRef.current as any)?.destroy?.(); } catch {}
        activeDocRef.current = null;
      }
      setPdfDoc(null);
      setNumPages(0);
      setLoadError(null);
      return;
    }

    setLoadError(null);
    setRendering(true);

    // Cancel any previous task
    if (currentRenderTask.current) {
      try { currentRenderTask.current.cancel(); } catch {}
      currentRenderTask.current = null;
    }

    if (activeDocRef.current) {
      try { (activeDocRef.current as any)?.destroy?.(); } catch {}
      activeDocRef.current = null;
    }

    const loadTask = pdfjsLib.getDocument({ 
      url: fileUrl,
      // Disable remote cMap fetch if offline, use standard fallbacks
      cMapUrl: undefined,
      cMapPacked: false
    });

    loadTask.promise
      .then(async (doc) => {
        activeDocRef.current = doc;
        setPdfDoc(doc);
        setNumPages(doc.numPages);
        setLoadError(null);
        
        // Restore last read page if available
        const savedPage = localStorage.getItem(`studyforge_page_${fileName}`);
        const startPage = savedPage ? parseInt(savedPage, 10) : initialPage;
        setPageNum(startPage <= doc.numPages && startPage > 0 ? startPage : 1);
        
        // Start background lightweight client indexing
        extractDocumentIntelligence(doc);
      })
      .catch((err) => {
        console.error('PDF load failure:', err);
        setLoadError({
          message: 'Unable to open this PDF document.',
          technicalDetails: err?.message || String(err),
          causes: [
            'The file may be corrupted or incompletely saved.',
            'The file format might not be a valid standard PDF/A or PDF 1.x.',
            'The file is password-protected or encrypted.',
            'The local filesystem or storage access was revoked.'
          ]
        });
        setRendering(false);
      });
  }, [fileUrl, fileName, initialPage]);

  useEffect(() => {
    loadPdf();

    return () => {
      if (currentRenderTask.current) {
        try { currentRenderTask.current.cancel(); } catch {}
      }
      if (activeDocRef.current) {
        try { (activeDocRef.current as any)?.destroy?.(); } catch {}
        activeDocRef.current = null;
      }
    };
  }, [loadPdf]);

  // Background Document Intelligence Extractor (Runs client-side)
  const extractDocumentIntelligence = async (doc: pdfjsLib.PDFDocumentProxy) => {
    setIsIndexing(true);
    searchIndexRef.current.clear();

    try {
      const pageTexts: Array<{ pageNumber: number; text: string }> = [];
      let aggregatedText = '';
      
      // Index pages prudently to prevent memory exhaustion on low-end hardware
      const maxPagesToIndex = performanceMode ? Math.min(doc.numPages, 12) : Math.min(doc.numPages, 35);

      for (let i = 1; i <= maxPagesToIndex; i++) {
        try {
          const page = await doc.getPage(i);
          const textContent = await page.getTextContent();
          const text = textContent.items
            .map((item: any) => item.str || '')
            .join(' ');
          
          pageTexts.push({ pageNumber: i, text });
          aggregatedText += ' ' + text;
          searchIndexRef.current.addPage(i, text);
          // Release page memory immediately
          page.cleanup();
        } catch {
          // Continue indexing next pages
        }
      }

      // Keyword extraction
      const keywords = extractLocalKeywords(aggregatedText, 14);
      setExtractedKeywords(keywords);

      // Outline / Chapter detection
      const nativeOutline = await doc.getOutline();
      if (nativeOutline && nativeOutline.length > 0) {
        const chapters: DetectedChapter[] = nativeOutline.map((item: any, idx: number) => ({
          title: item.title,
          pageNumber: typeof item.dest === 'number' ? item.dest : (idx + 1),
          level: 1
        }));
        setDetectedChapters(chapters);
      } else {
        const detected = detectDocumentChapters(pageTexts);
        setDetectedChapters(detected);
      }
    } catch (e) {
      console.warn('Document intelligence background indexing skipped:', e);
    } finally {
      setIsIndexing(false);
    }
  };

  // Render Page to Canvas
  const renderCurrentPage = useCallback(async () => {
    if (!pdfDoc || !canvasRef.current) return;

    if (currentRenderTask.current) {
      try {
        currentRenderTask.current.cancel();
      } catch {
        // Cancel previous in-flight task
      }
    }

    setRendering(true);

    try {
      const page = await pdfDoc.getPage(pageNum);
      const canvas = canvasRef.current;
      if (!canvas) return;

      const viewport = page.getViewport({ scale, rotation });
      const context = canvas.getContext('2d');
      if (!context) return;

      // Optimize canvas dimensions for low-end hardware
      const outputScale = performanceMode ? 1 : Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(viewport.width * outputScale);
      canvas.height = Math.floor(viewport.height * outputScale);
      canvas.style.width = Math.floor(viewport.width) + 'px';
      canvas.style.height = Math.floor(viewport.height) + 'px';

      const transform = outputScale !== 1 
        ? [outputScale, 0, 0, outputScale, 0, 0] 
        : undefined;

      const renderContext: any = {
        canvasContext: context,
        transform: transform,
        viewport: viewport
      };

      const renderTask = page.render(renderContext);
      currentRenderTask.current = renderTask;
      await renderTask.promise;
      currentRenderTask.current = null;

      // Save reading progress locally
      localStorage.setItem(`studyforge_page_${fileName}`, String(pageNum));
      if (onPageChange) onPageChange(pageNum, numPages);

      // Clean up page resources
      page.cleanup();
    } catch (err: any) {
      if (err?.name !== 'RenderingCancelledException') {
        console.error('Page render error:', err);
      }
    } finally {
      setRendering(false);
    }
  }, [pdfDoc, pageNum, scale, rotation, fileName, numPages, onPageChange, performanceMode]);

  useEffect(() => {
    renderCurrentPage();
  }, [renderCurrentPage]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        setPageNum(p => Math.min(numPages, p + 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        setPageNum(p => Math.max(1, p - 1));
      } else if (e.key === 'Home') {
        setPageNum(1);
      } else if (e.key === 'End') {
        setPageNum(numPages);
      } else if ((e.ctrlKey || e.metaKey) && (e.key === '=' || e.key === '+')) {
        e.preventDefault();
        setScale(s => Math.min(2.5, s + 0.15));
      } else if ((e.ctrlKey || e.metaKey) && e.key === '-') {
        e.preventDefault();
        setScale(s => Math.max(0.6, s - 0.15));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [numPages]);

  // Fit Width / Fit Page Calculation
  const handleFitWidth = () => {
    if (!containerRef.current || !canvasRef.current) return;
    const containerWidth = containerRef.current.clientWidth - 48; // padding
    const currentCanvasWidth = canvasRef.current.clientWidth / scale;
    if (currentCanvasWidth > 0) {
      const targetScale = Math.max(0.5, Math.min(2.5, containerWidth / currentCanvasWidth));
      setScale(targetScale);
    }
  };

  const handleFitPage = () => {
    if (!containerRef.current || !canvasRef.current) return;
    const containerHeight = containerRef.current.clientHeight - 64;
    const currentCanvasHeight = canvasRef.current.clientHeight / scale;
    if (currentCanvasHeight > 0) {
      const targetScale = Math.max(0.5, Math.min(2.0, containerHeight / currentCanvasHeight));
      setScale(targetScale);
    }
  };

  // Add Bookmark Handler
  const handleAddBookmark = () => {
    const title = newBookmarkTitle.trim() || `Page ${pageNum}`;
    const newBm: LocalBookmark = {
      id: Math.random().toString(36).substring(2, 9),
      page: pageNum,
      title,
      timestamp: Date.now()
    };
    const updated = [...bookmarks, newBm];
    setBookmarks(updated);
    localStorage.setItem(`studyforge_bm_${fileName}`, JSON.stringify(updated));
    setNewBookmarkTitle('');
    setShowAddBookmark(false);
    if (onSaveBookmark) onSaveBookmark(pageNum, title);
    showToast(`Bookmark added for page ${pageNum}`, 'success');
  };

  const handleRemoveBookmark = (id: string) => {
    const updated = bookmarks.filter(b => b.id !== id);
    setBookmarks(updated);
    localStorage.setItem(`studyforge_bm_${fileName}`, JSON.stringify(updated));
    showToast('Bookmark removed', 'info');
  };

  // Execute Search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    const results = searchIndexRef.current.search(searchQuery.trim());
    setSearchResults(results);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Error State Render (Complies strictly with Requirement 9 & 39)
  if (loadError) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-6 bg-stone-50 dark:bg-zinc-950 text-stone-900 dark:text-stone-100">
        <div className="max-w-md w-full bg-white dark:bg-zinc-900 border border-stone-200 dark:border-zinc-800 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-3 text-rose-600 dark:text-rose-400 mb-3">
            <FileX className="w-8 h-8 shrink-0" />
            <div>
              <h2 className="text-base font-bold">Unable to open this PDF</h2>
              <p className="text-xs text-stone-500 font-mono truncate max-w-[280px]">{fileName}</p>
            </div>
          </div>

          <div className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 mt-4">
            Possible Causes
          </div>
          <ul className="text-xs text-stone-600 dark:text-zinc-400 space-y-1.5 list-disc list-inside mb-4 bg-stone-50 dark:bg-zinc-950 p-3 rounded-lg border border-stone-200 dark:border-zinc-800">
            {loadError.causes.map((c, i) => (
              <li key={i}>{c}</li>
            ))}
          </ul>

          {loadError.technicalDetails && (
            <div className="mb-5 text-[11px] font-mono text-stone-500 dark:text-zinc-400 bg-stone-100 dark:bg-zinc-800/60 p-2 rounded truncate" title={loadError.technicalDetails}>
              Diagnostic: {loadError.technicalDetails}
            </div>
          )}

          <div className="flex items-center gap-3 pt-2 border-t border-stone-100 dark:border-zinc-800">
            <button
              onClick={loadPdf}
              className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Try Again
            </button>
            {onChooseAnotherFile && (
              <button
                onClick={onChooseAnotherFile}
                className="flex-1 py-2 px-3 border border-stone-300 dark:border-zinc-700 hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300 rounded-md text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <UploadCloud className="w-3.5 h-3.5" /> Open Another PDF
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef} 
      className="flex-1 flex flex-col h-full w-full bg-stone-200 dark:bg-zinc-950 select-none overflow-hidden relative"
    >
      {/* Top Compact Desktop Toolbar */}
      <div className="h-10 bg-white dark:bg-zinc-900 border-b border-stone-200 dark:border-zinc-800 flex items-center justify-between px-3 shrink-0 z-20 shadow-sm">
        
        {/* Left: Page Navigation */}
        <div className="flex items-center gap-1.5">
          <button 
            disabled={pageNum <= 1}
            onClick={() => setPageNum(p => Math.max(1, p - 1))}
            className="p-1 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded disabled:opacity-30 transition-colors"
            title="Previous Page (Left Arrow)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          <div className="flex items-center text-xs font-medium text-stone-700 dark:text-zinc-300">
            <input 
              type="number" 
              min={1} 
              max={numPages || 1}
              value={pageNum}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                if (val >= 1 && val <= numPages) setPageNum(val);
              }}
              className="w-10 text-center bg-stone-100 dark:bg-zinc-800 border border-stone-300 dark:border-zinc-700 rounded py-0.5 text-xs text-stone-900 dark:text-white"
            />
            <span className="mx-1.5 text-stone-400">/</span>
            <span>{numPages || '—'}</span>
          </div>

          <button 
            disabled={pageNum >= numPages}
            onClick={() => setPageNum(p => Math.min(numPages, p + 1))}
            className="p-1 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded disabled:opacity-30 transition-colors"
            title="Next Page (Right Arrow)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Center: Zoom and Display Controls */}
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setScale(s => Math.max(0.6, s - 0.15))}
            className="p-1 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
            title="Zoom Out (Ctrl -)"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-[11px] font-mono w-12 text-center text-stone-600 dark:text-zinc-400">
            {Math.round(scale * 100)}%
          </span>
          <button 
            onClick={() => setScale(s => Math.min(2.5, s + 0.15))}
            className="p-1 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
            title="Zoom In (Ctrl +)"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          
          <div className="h-4 w-px bg-stone-300 dark:bg-zinc-800 mx-1" />

          <button
            onClick={handleFitWidth}
            className="px-2 py-0.5 text-[10px] font-medium text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
            title="Fit to Width"
          >
            Fit Width
          </button>
          <button
            onClick={handleFitPage}
            className="px-2 py-0.5 text-[10px] font-medium text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
            title="Fit Whole Page"
          >
            Fit Page
          </button>
          <button 
            onClick={() => setRotation(r => (r + 90) % 360)}
            className="p-1 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
            title="Rotate Clockwise"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Intelligence Panels & Tools */}
        <div className="flex items-center gap-1">
          <button 
            onClick={() => setActiveTab(activeTab === 'outline' ? 'none' : 'outline')}
            className={cn(
              "px-2 py-1 text-xs font-medium rounded flex items-center gap-1 transition-colors",
              activeTab === 'outline' ? "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400" : "text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800"
            )}
            title="Chapters & Outline"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px]">Outline</span>
          </button>

          <button 
            onClick={() => setActiveTab(activeTab === 'search' ? 'none' : 'search')}
            className={cn(
              "px-2 py-1 text-xs font-medium rounded flex items-center gap-1 transition-colors",
              activeTab === 'search' ? "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400" : "text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800"
            )}
            title="Search Document Text"
          >
            <Search className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px]">Search</span>
          </button>

          <button 
            onClick={() => setActiveTab(activeTab === 'keywords' ? 'none' : 'keywords')}
            className={cn(
              "px-2 py-1 text-xs font-medium rounded flex items-center gap-1 transition-colors",
              activeTab === 'keywords' ? "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400" : "text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800"
            )}
            title="Local Document Keywords"
          >
            <Hash className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px]">Keywords</span>
          </button>

          <button 
            onClick={() => setActiveTab(activeTab === 'bookmarks' ? 'none' : 'bookmarks')}
            className={cn(
              "px-2 py-1 text-xs font-medium rounded flex items-center gap-1 transition-colors",
              activeTab === 'bookmarks' ? "bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400" : "text-stone-600 dark:text-zinc-400 hover:bg-stone-100 dark:hover:bg-zinc-800"
            )}
            title="Bookmarks"
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span className="hidden sm:inline text-[11px]">Bookmarks</span>
          </button>

          <div className="h-4 w-px bg-stone-300 dark:bg-zinc-800 mx-1" />

          <button 
            onClick={toggleFullscreen}
            className="p-1 text-stone-600 dark:text-zinc-400 hover:text-stone-900 dark:hover:text-white hover:bg-stone-100 dark:hover:bg-zinc-800 rounded transition-colors"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          {onClose && (
            <button 
              onClick={onClose}
              className="p-1 text-stone-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition-colors"
              title="Close PDF"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main View Area with Optional Intelligence Drawer */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* Document Canvas Container */}
        <div className="flex-1 overflow-auto flex items-center justify-center p-4 relative custom-scrollbar">
          {rendering && (
            <div className="absolute top-4 right-4 bg-white/90 dark:bg-zinc-800/90 backdrop-blur border border-stone-200 dark:border-zinc-700 px-3 py-1.5 rounded-full flex items-center gap-2 text-xs shadow-md z-10 text-stone-700 dark:text-stone-200">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
              <span>Rendering page {pageNum}...</span>
            </div>
          )}

          <canvas 
            ref={canvasRef} 
            className="shadow-2xl rounded bg-white transition-transform duration-100 ease-out max-w-none" 
          />
        </div>

        {/* Secondary Sliding Drawer for Document Intelligence */}
        {activeTab !== 'none' && (
          <div className="w-80 border-l border-stone-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 flex flex-col shrink-0 z-10 animate-in slide-in-from-right duration-200 shadow-xl">
            
            {/* Drawer Header */}
            <div className="h-10 px-3 border-b border-stone-200 dark:border-zinc-800 flex items-center justify-between bg-stone-50 dark:bg-zinc-900 shrink-0">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                {activeTab === 'outline' && 'Document Chapters'}
                {activeTab === 'search' && 'Search in Text'}
                {activeTab === 'keywords' && 'Extracted Concepts'}
                {activeTab === 'bookmarks' && 'Saved Bookmarks'}
              </span>
              <button 
                onClick={() => setActiveTab('none')}
                className="p-1 hover:bg-stone-200 dark:hover:bg-zinc-800 rounded text-stone-500 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Drawer Content */}
            <div className="flex-1 overflow-y-auto p-4 custom-scrollbar text-xs">
              
              {/* TAB 1: OUTLINE */}
              {activeTab === 'outline' && (
                <div className="space-y-2">
                  {detectedChapters.length === 0 ? (
                    <div className="text-center py-8 text-stone-400">
                      {isIndexing ? (
                        <div className="flex flex-col items-center gap-2">
                          <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
                          <span>Detecting document chapters...</span>
                        </div>
                      ) : (
                        <span>No outline chapters detected in this document.</span>
                      )}
                    </div>
                  ) : (
                    detectedChapters.map((ch, idx) => (
                      <button
                        key={idx}
                        onClick={() => setPageNum(ch.pageNumber)}
                        className={cn(
                          "w-full text-left p-2 rounded border border-transparent transition-colors flex items-center justify-between",
                          pageNum === ch.pageNumber 
                            ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-semibold border-indigo-200 dark:border-indigo-800" 
                            : "hover:bg-stone-100 dark:hover:bg-zinc-800 text-stone-700 dark:text-zinc-300"
                        )}
                      >
                        <span className="truncate pr-2">{ch.title}</span>
                        <span className="text-[10px] text-stone-400 shrink-0">p. {ch.pageNumber}</span>
                      </button>
                    ))
                  )}
                </div>
              )}

              {/* TAB 2: SEARCH */}
              {activeTab === 'search' && (
                <div className="space-y-4">
                  <form onSubmit={handleSearch} className="flex gap-1.5">
                    <input 
                      type="text"
                      placeholder="Find in document..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1 bg-stone-100 dark:bg-zinc-800 border border-stone-300 dark:border-zinc-700 rounded px-2.5 py-1.5 text-xs text-stone-900 dark:text-white"
                    />
                    <button 
                      type="submit"
                      className="px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold shadow-sm transition-colors"
                    >
                      Find
                    </button>
                  </form>

                  {searchResults.length > 0 && (
                    <div className="space-y-2">
                      <div className="text-[11px] text-stone-500">
                        {searchResults.reduce((a, b) => a + b.count, 0)} occurrences across {searchResults.length} pages
                      </div>
                      {searchResults.map((res, i) => (
                        <div 
                          key={i}
                          onClick={() => setPageNum(res.pageNumber)}
                          className="p-2 bg-stone-50 dark:bg-zinc-800/50 rounded border border-stone-200 dark:border-zinc-700 hover:border-indigo-400 cursor-pointer transition-colors"
                        >
                          <div className="flex items-center justify-between font-semibold text-indigo-600 dark:text-indigo-400 mb-1">
                            <span>Page {res.pageNumber}</span>
                            <span className="text-[10px] bg-indigo-100 dark:bg-indigo-900 px-1.5 py-0.5 rounded text-indigo-700 dark:text-indigo-300">{res.count} hits</span>
                          </div>
                          <p className="text-stone-600 dark:text-zinc-400 italic font-mono text-[11px] line-clamp-2">
                            "{res.snippet}"
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 3: KEYWORDS */}
              {activeTab === 'keywords' && (
                <div className="space-y-3">
                  <p className="text-stone-500 text-[11px]">
                    Client-side TF frequency extraction from document text:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {extractedKeywords.map((kw, i) => (
                      <span 
                        key={i}
                        className="px-2 py-1 bg-stone-100 dark:bg-zinc-800 border border-stone-200 dark:border-zinc-700 text-stone-800 dark:text-zinc-200 rounded text-xs font-medium"
                      >
                        {kw.word} <span className="text-stone-400 text-[10px]">({kw.count})</span>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: BOOKMARKS */}
              {activeTab === 'bookmarks' && (
                <div className="space-y-3">
                  <button 
                    onClick={() => setShowAddBookmark(true)}
                    className="w-full py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                  >
                    <BookmarkPlus className="w-3.5 h-3.5" /> Bookmark Current Page ({pageNum})
                  </button>

                  {showAddBookmark && (
                    <div className="p-3 bg-stone-50 dark:bg-zinc-800 rounded-lg border border-stone-200 dark:border-zinc-700 space-y-2">
                      <input 
                        type="text"
                        placeholder="Bookmark note / title..."
                        value={newBookmarkTitle}
                        onChange={(e) => setNewBookmarkTitle(e.target.value)}
                        className="w-full bg-white dark:bg-zinc-900 border border-stone-300 dark:border-zinc-700 rounded px-2 py-1 text-xs text-stone-900 dark:text-white"
                        autoFocus
                      />
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => setShowAddBookmark(false)}
                          className="px-2 py-1 text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 text-xs"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={handleAddBookmark}
                          className="px-3 py-1 bg-indigo-600 text-white rounded text-xs font-medium"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2 pt-2">
                    {bookmarks.length === 0 ? (
                      <div className="text-center py-6 text-stone-400">
                        No bookmarks saved for this PDF.
                      </div>
                    ) : (
                      bookmarks.map((bm) => (
                        <div 
                          key={bm.id}
                          className="p-2 bg-stone-50 dark:bg-zinc-800/60 rounded border border-stone-200 dark:border-zinc-700 flex items-center justify-between gap-2"
                        >
                          <button 
                            onClick={() => setPageNum(bm.page)}
                            className="flex-1 text-left min-w-0"
                          >
                            <div className="font-semibold text-stone-800 dark:text-stone-200 truncate">{bm.title}</div>
                            <div className="text-[10px] text-stone-500">Page {bm.page}</div>
                          </button>
                          <button 
                            onClick={() => handleRemoveBookmark(bm.id)}
                            className="text-stone-400 hover:text-rose-500 p-1"
                            title="Delete Bookmark"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
}

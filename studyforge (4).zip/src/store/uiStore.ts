import { create } from 'zustand';

export interface ToastItem {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
}

export interface ConfirmDialogParams {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  onConfirm: () => void;
}

interface UIState {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  activeWorkspaceId: string | null;
  setActiveWorkspaceId: (id: string | null) => void;
  performanceMode: boolean;
  setPerformanceMode: (enabled: boolean) => void;
  
  // Non-blocking toast notification
  toasts: ToastItem[];
  showToast: (message: string, type?: 'info' | 'success' | 'warning' | 'error') => void;
  dismissToast: (id: string) => void;

  // Accessible in-app confirmation modal (replaces native window.confirm)
  confirmDialog: ConfirmDialogParams | null;
  askConfirmation: (params: ConfirmDialogParams) => void;
  closeConfirmation: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  sidebarOpen: true,
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  activeWorkspaceId: null,
  setActiveWorkspaceId: (id) => set({ activeWorkspaceId: id }),
  performanceMode: false,
  setPerformanceMode: (enabled) => set({ performanceMode: enabled }),

  toasts: [],
  showToast: (message, type = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    set((state) => ({ toasts: [...state.toasts, { id, message, type }] }));
    setTimeout(() => {
      set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) }));
    }, 4000);
  },
  dismissToast: (id) => set((state) => ({ toasts: state.toasts.filter((t) => t.id !== id) })),

  confirmDialog: null,
  askConfirmation: (params) => set({ confirmDialog: params }),
  closeConfirmation: () => set({ confirmDialog: null }),
}));

